/** @typedef {"right" | "left"} MouthCornerLabSideId */

/**
 * Kinematics Lab 左右嘴角机构配置（复用同一套 FiveBar FK/IK，镜像由符号参数完成）。
 */
export const MOUTH_CORNER_LAB_SIDES = {
  right: {
    id: /** @type {const} */ ("right"),
    mechanismId: "rightMouthFiveBar",
    label: "Right Mouth",
    controlId: "mouth_corner_r",
    rigSideKey: "sideR",
    rigValuesKey: "mouth_corner_r",
    profileBindingPrefix: "mouth_corner_r",
    calibStorageKey: "facedev.rightMouthFivebar.calibration.v1",
    baselineStorageKey: "facedev.rightMouthFivebar.runtimeBaseline.v1",
    baselineChangedEvent: "facedev:rightMouthFivebarBaselineChanged",
    mediaPipeDriveKey: "mediaPipeRightMouthDriveEnabled",
    diagnosticsSource: "rightMouthFiveBar",
    labHwServoA: 6,
    labHwServoB: 7,
    defaultCalibration: {
      Kx: 7,
      Ky: 7,
      xSign: 1,
      ySign: 1,
      qSignA: 1,
      qSignB: 1,
      qGainA: 1,
      qGainB: 1,
      servoSwap: false,
    },
  },
  left: {
    id: /** @type {const} */ ("left"),
    mechanismId: "leftMouthFiveBar",
    label: "Left Mouth",
    controlId: "mouth_corner_l",
    rigSideKey: "sideL",
    rigValuesKey: "mouth_corner_l",
    profileBindingPrefix: "mouth_corner_l",
    calibStorageKey: "facedev.leftMouthFivebar.calibration.v1",
    baselineStorageKey: "facedev.leftMouthFivebar.runtimeBaseline.v1",
    baselineChangedEvent: "facedev:leftMouthFivebarBaselineChanged",
    mediaPipeDriveKey: "mediaPipeLeftMouthDriveEnabled",
    diagnosticsSource: "leftMouthFiveBar",
    labHwServoA: 18,
    labHwServoB: 19,
    defaultCalibration: {
      Kx: 7,
      Ky: 7,
      xSign: -1,
      ySign: 1,
      qSignA: 1,
      qSignB: 1,
      qGainA: 4,
      qGainB: 4,
      servoSwap: false,
    },
  },
}

/** @param {MouthCornerLabSideId | string} sideId */
export function getMouthCornerLabSide(sideId) {
  return MOUTH_CORNER_LAB_SIDES[sideId] || MOUTH_CORNER_LAB_SIDES.right
}
