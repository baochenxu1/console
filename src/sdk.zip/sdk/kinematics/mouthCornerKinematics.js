import { CHANNEL_X, CHANNEL_Y } from "../../core/faceRigProfile.js"
import {
  SERVO_LOGICAL_MIN_PWM,
  SERVO_LOGICAL_MAX_PWM,
  STANDARD_CENTER_PWM,
  getServoConfig,
  logicalToActualPwm,
} from "../../core/servoConfig.js"
import { clampNumber } from "../../utils/clamp.js"
import {
  createRightMouthCornerFivebarState,
  resolveRightMouthCornerFivebar,
  angleToBindingLogicalPwm,
} from "./mouthCornerFivebar.js"
import { getDefaultRightMouthRuntimeParams } from "./rightMouthFiveBarRuntime.js"
import { getMouthCornerLabSide } from "./mouthCornerFiveBarLabConfig.js"

/** 可在后续接入 UI / 全局配置；控件层 / Tracking / Keyframe 与 mapFaceRigToPose 共用 */
export const DEFAULT_FACE_RIG_KINEMATICS = {
  rightMouthCornerFiveBar: {
    enabled: true,
    /** 正式链路：qRaw→PWM，不累积 qPrev（见 computeRightMouthCornerFiveBarIk） */
    runtimeOutputMode: /** @type {"static-target" | "stateful-one-step" | "run-to-target"} */ (
      "static-target"
    ),
    Kx: 7,
    Ky: 7,
    padXCenter: 50,
    padYCenter: 50,
    maxStepDeg: 2.0,
    filterAlpha: 0.35,
  },
}

/**
 * @param {object} [rig]
 * @returns {boolean}
 */
function isRigValuesShapeForSide(rig, rigValuesKey) {
  return Boolean(rig && typeof rig === "object" && rig[rigValuesKey] && typeof rig[rigValuesKey] === "object")
}

/**
 * @param {object} rig
 * @param {import("./mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} [sideId]
 */
export function rigValuesForMouthCorner(rig, sideId = "right") {
  const side = getMouthCornerLabSide(sideId)
  if (!rig || typeof rig !== "object") {
    return { x: 50, y: 50 }
  }
  if (isRigValuesShapeForSide(rig, side.rigValuesKey)) {
    const rv = rig[side.rigValuesKey]
    const x = Number(rv.x)
    const y = Number(rv.y)
    return {
      x: Number.isFinite(x) ? x : 50,
      y: Number.isFinite(y) ? y : 50,
    }
  }
  const mouthSide = rig.mouth?.[side.rigSideKey]
  const x = Number(mouthSide?.x)
  const y = Number(mouthSide?.y)
  return {
    x: Number.isFinite(x) ? x : 50,
    y: Number.isFinite(y) ? y : 50,
  }
}

/** @param {object} rig */
export function rigValuesForRightMouthCorner(rig) {
  return rigValuesForMouthCorner(rig, "right")
}

/** @param {object} rig */
export function rigValuesForLeftMouthCorner(rig) {
  return rigValuesForMouthCorner(rig, "left")
}

/** @param {object} [userKinematics] mapFaceRigToPose(..., { kinematics }) 可为嵌套或扁平静态覆盖 */
function sliceRightMouthFiveBarKinematics(userKinematics) {
  if (!userKinematics || typeof userKinematics !== "object") {
    return {}
  }
  const inner = userKinematics.rightMouthCornerFiveBar
  return inner && typeof inner === "object" ? inner : userKinematics
}

function applyRuntimeAngleMod(qDeg, sign, gain) {
  return Number(qDeg) * Number(sign ?? 1) * Number(gain ?? 1)
}

/**
 * runtimeParams 优先级最高，其次 userKinematics，最后 runtime 模块默认。
 * @param {object} [runtimeParams]
 * @param {object} [userKinematics]
 */
export function mergeFiveBarRuntimeParams(runtimeParams, userKinematics) {
  const defaults = getDefaultRightMouthRuntimeParams()
  const u = sliceRightMouthFiveBarKinematics(userKinematics)
  const r = runtimeParams && typeof runtimeParams === "object" ? runtimeParams : {}
  return {
    ...defaults,
    ...u,
    ...r,
    Kx: r.Kx ?? u.Kx ?? defaults.Kx,
    Ky: r.Ky ?? u.Ky ?? defaults.Ky,
    xSign: r.xSign ?? u.xSign ?? defaults.xSign,
    ySign: r.ySign ?? u.ySign ?? defaults.ySign,
    padXCenter: r.padXCenter ?? u.padXCenter ?? defaults.padXCenter,
    padYCenter: r.padYCenter ?? u.padYCenter ?? defaults.padYCenter,
    maxStepDeg: r.maxStepDeg ?? u.maxStepDeg ?? defaults.maxStepDeg,
    filterAlpha: r.filterAlpha ?? u.filterAlpha ?? defaults.filterAlpha,
    qSignA: r.qSignA ?? u.qSignA ?? defaults.qSignA,
    qSignB: r.qSignB ?? u.qSignB ?? defaults.qSignB,
    qGainA: r.qGainA ?? u.qGainA ?? defaults.qGainA,
    qGainB: r.qGainB ?? u.qGainB ?? defaults.qGainB,
    servoSwap: r.servoSwap ?? u.servoSwap ?? defaults.servoSwap,
  }
}

function bindingFromProfileOverride(profile, controlId, channel, overrideEntry) {
  if (!overrideEntry || typeof overrideEntry !== "object") {
    return null
  }
  const fromProfile = (profile?.bindings || []).find(
    (b) => b?.controlId === controlId && b.channel === channel && b.enabled !== false
  )
  if (fromProfile) {
    return { ...fromProfile, ...overrideEntry, controlId, channel }
  }
  return {
    bindingId: overrideEntry.bindingId || `${controlId}_${channel}`,
    controlId,
    channel,
    servoId: overrideEntry.servoId,
    neutralPwm: overrideEntry.neutralPwm ?? 1500,
    pwmPerUnit: overrideEntry.pwmPerUnit,
    invert: overrideEntry.invert,
    enabled: overrideEntry.enabled !== false,
    positiveTargetPwm: overrideEntry.positiveTargetPwm,
    negativeTargetPwm: overrideEntry.negativeTargetPwm,
  }
}

function enrichPadOffsetDiagnostics(d, sideR, params) {
  const cx = Number(params.padXCenter ?? 50)
  const cy = Number(params.padYCenter ?? 50)
  const u = cx !== 0 ? (Number(sideR.x) - cx) / cx : 0
  const v = cy !== 0 ? (cy - Number(sideR.y)) / cy : 0
  const xSign = Number(params.xSign ?? 1)
  const ySign = Number(params.ySign ?? 1)
  const Kx = Number(params.Kx ?? 1)
  const Ky = Number(params.Ky ?? 1)
  const expectedDOffset = [xSign * Kx * u, ySign * Ky * v]
  let actualDOffset = [null, null]
  const D0 = d.D0
  const D_raw = d.D_raw
  if (Array.isArray(D0) && Array.isArray(D_raw) && D0.length >= 2 && D_raw.length >= 2) {
    actualDOffset = [D_raw[0] - D0[0], D_raw[1] - D0[1]]
  }
  const offsetError = [
    actualDOffset[0] != null ? actualDOffset[0] - expectedDOffset[0] : null,
    actualDOffset[1] != null ? actualDOffset[1] - expectedDOffset[1] : null,
  ]
  return { u, v, expectedDOffset, actualDOffset, offsetError }
}

function attachEffectiveRuntimeDiagnostics(d, params, runtimeSource, diagnosticsSource = "rightMouthFiveBar") {
  d.source = diagnosticsSource
  d.runtimeSource = runtimeSource || "default"
  d.effectiveKx = params.Kx
  d.effectiveKy = params.Ky
  d.effectiveXSign = params.xSign
  d.effectiveYSign = params.ySign
  d.effectiveQSignA = params.qSignA
  d.effectiveQSignB = params.qSignB
  d.effectiveQGainA = params.qGainA
  d.effectiveQGainB = params.qGainB
  d.effectiveServoSwap = Boolean(params.servoSwap)
}

/**
 * @param {object} profile
 * @param {object} [options]
 * @param {object} [options.runtimeParams] getRightMouthFiveBarRuntime().params（最高优先级）
 * @param {object} [options.runtimeBindingOverride] baseline profileBindings / servoA/B
 * @param {object} [options.kinematics] mapFaceRigToPose kinematics 包装
 * @param {string} [options.runtimeSource] "runtimeBaseline" | "default"
 * @returns {{
 *   enabled: boolean,
 *   readyForIk: boolean,
 *   servoAId: number|null,
 *   servoBId: number|null,
 *   bindingA: object|null,
 *   bindingB: object|null,
 *   params: object,
 *   runtimeOutputMode: "static-target"|"stateful-one-step"|"run-to-target",
 *   skipReason?: string
 * }}
 */
/**
 * @param {object} profile
 * @param {import("./mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} sideId
 * @param {object} [options]
 */
export function resolveMouthCornerKinematics(profile, sideId = "right", options = null) {
  const side = getMouthCornerLabSide(sideId)
  const opts = options && typeof options === "object" ? options : {}
  const userKinematics = opts.kinematics ?? (options && !opts.runtimeParams && !opts.runtimeBindingOverride ? options : null)
  const u = sliceRightMouthFiveBarKinematics(userKinematics)
  const d = DEFAULT_FACE_RIG_KINEMATICS.rightMouthCornerFiveBar || {}
  const enabled = u.enabled !== false && d.enabled !== false

  const runtimeOutputMode =
    u.runtimeOutputMode ?? d.runtimeOutputMode ?? /** @type {const} */ ("static-target")

  const params = mergeFiveBarRuntimeParams(opts.runtimeParams, userKinematics)

  const bindOv = opts.runtimeBindingOverride
  const pb = bindOv?.profileBindings || {}
  const bindKeyX = `${side.profileBindingPrefix}_x`
  const bindKeyY = `${side.profileBindingPrefix}_y`

  let bindingA = bindingFromProfileOverride(profile, side.controlId, CHANNEL_X, pb[bindKeyX])
  let bindingB = bindingFromProfileOverride(profile, side.controlId, CHANNEL_Y, pb[bindKeyY])
  let servoAId =
    bindOv?.servoAId != null
      ? Number(bindOv.servoAId)
      : bindingA
        ? Number(bindingA.servoId)
        : null
  let servoBId =
    bindOv?.servoBId != null
      ? Number(bindOv.servoBId)
      : bindingB
        ? Number(bindingB.servoId)
        : null

  if (!bindingA || !bindingB) {
    for (const b of profile?.bindings || []) {
      if (!b || b.enabled === false || b.controlId !== side.controlId) {
        continue
      }
      if (b.channel === CHANNEL_X && !bindingA) {
        bindingA = b
        servoAId = Number(b.servoId)
      }
      if (b.channel === CHANNEL_Y && !bindingB) {
        bindingB = b
        servoBId = Number(b.servoId)
      }
    }
  }

  if (params.servoSwap) {
    const tmpB = bindingB
    const tmpS = servoBId
    bindingB = bindingA
    servoBId = servoAId
    bindingA = tmpB
    servoAId = tmpS
  }

  const hasA = Number.isFinite(servoAId) && bindingA
  const hasB = Number.isFinite(servoBId) && bindingB
  const readyForIk = Boolean(enabled && hasA && hasB)

  let skipReason
  if (enabled && !readyForIk) {
    skipReason = `已启用${side.label}五杆，但未找到已启用的 ${side.controlId}.x / ${side.controlId}.y 绑定（或舵机 id 无效）`
  }

  return {
    enabled,
    readyForIk,
    servoAId: hasA ? servoAId : null,
    servoBId: hasB ? servoBId : null,
    bindingA,
    bindingB,
    params,
    runtimeOutputMode,
    runtimeSource: opts.runtimeSource || "default",
    diagnosticsSource: side.diagnosticsSource,
    sideId: side.id,
    skipReason,
  }
}

export function resolveRightMouthCornerKinematics(profile, options = null) {
  return resolveMouthCornerKinematics(profile, "right", options)
}

export function resolveLeftMouthCornerKinematics(profile, options = null) {
  return resolveMouthCornerKinematics(profile, "left", options)
}

/**
 * @param {number} qDeg
 * @param {number} neutralPwm
 * @param {number} pwmPerDeg
 * @deprecated 请使用 {@link angleToBindingLogicalPwm} 与 profile 绑定目标
 */
export function angleDegToLogicalPwm(qDeg, neutralPwm, pwmPerDeg) {
  const n = Number(neutralPwm)
  const neutral = Number.isFinite(n) ? n : STANDARD_CENTER_PWM
  const logicalPwm = neutral + Number(qDeg) * Number(pwmPerDeg)
  return clampNumber(
    Math.round(logicalPwm),
    SERVO_LOGICAL_MIN_PWM,
    SERVO_LOGICAL_MAX_PWM
  )
}

/**
 * @param {object} rigValues
 * @param {ReturnType<typeof resolveRightMouthCornerKinematics>} resolved
 * @param {ReturnType<typeof createRightMouthCornerFivebarState>} [state]
 */
export function computeMouthCornerFiveBarIk(rigValues, resolved, state, sideId = "right") {
  const pad = rigValuesForMouthCorner(rigValues, sideId)
  const {
    params,
    bindingA,
    bindingB,
    servoAId,
    servoBId,
    runtimeOutputMode = "static-target",
    runtimeSource = "default",
    diagnosticsSource = "rightMouthFiveBar",
  } = resolved

  const mode = runtimeOutputMode || "static-target"
  const st = state || createRightMouthCornerFivebarState()
  const qPrevBackup = mode === "static-target" ? [st.qPrev[0], st.qPrev[1]] : null

  const result = resolveRightMouthCornerFivebar({
    resolved: { bindingA, bindingB, servoAId, servoBId },
    sideR: pad,
    params,
    state: st,
  })

  if (mode === "static-target" && qPrevBackup) {
    st.qPrev[0] = qPrevBackup[0]
    st.qPrev[1] = qPrevBackup[1]
  }

  const d = { ...result.diagnostics }
  Object.assign(d, enrichPadOffsetDiagnostics(d, pad, params))
  d.enabled = true
  const side = getMouthCornerLabSide(sideId)
  d.overrideNote = `${side.controlId} 使用 fivebar IK 覆盖线性绑定`
  d.ikOk = result.ok
  d.ikMessage = result.ok ? "" : result.message || "IK 失败"
  d.runtimeOutputMode = mode
  d.outputMode = mode
  attachEffectiveRuntimeDiagnostics(d, params, runtimeSource, diagnosticsSource)

  if (!result.ok) {
    d.qSend = null
    return {
      ok: false,
      message: result.message || "IK 失败",
      diagnostics: d,
    }
  }

  const qRaw = d.qRaw
  const qCmd = d.qCmd

  if (mode === "static-target" && qRaw && bindingA && bindingB) {
    const qSend = { qA_deg: qRaw.qA_deg, qB_deg: qRaw.qB_deg }
    d.qSend = qSend
    const pwmA = angleToBindingLogicalPwm(
      applyRuntimeAngleMod(qSend.qA_deg, params.qSignA, params.qGainA),
      bindingA
    )
    const pwmB = angleToBindingLogicalPwm(
      applyRuntimeAngleMod(qSend.qB_deg, params.qSignB, params.qGainB),
      bindingB
    )
    d.logicalPwmA = pwmA
    d.logicalPwmB = pwmB
    d.pwmA = pwmA
    d.pwmB = pwmB
    return {
      ok: true,
      message: "",
      pwmA,
      pwmB,
      diagnostics: d,
    }
  }

  d.qSend = qCmd ? { qA_deg: qCmd.qA_deg, qB_deg: qCmd.qB_deg } : null
  d.logicalPwmA = result.pwmA
  d.logicalPwmB = result.pwmB
  return {
    ok: true,
    message: "",
    pwmA: result.pwmA,
    pwmB: result.pwmB,
    diagnostics: d,
  }
}

export function computeRightMouthCornerFiveBarIk(rigValues, resolved, state) {
  return computeMouthCornerFiveBarIk(rigValues, resolved, state, "right")
}

export function computeLeftMouthCornerFiveBarIk(rigValues, resolved, state) {
  return computeMouthCornerFiveBarIk(rigValues, resolved, state, "left")
}

/**
 * 合并贡献时：若某条 mouth_corner_r.x/y 指向五杆的两个舵机，则从合成中剔除，避免与 IK 叠加。
 * @param {object} c
 * @param {ReturnType<typeof resolveRightMouthCornerKinematics>} resolved
 */
export function contributionExcludedForMouthFiveBar(c, resolved) {
  if (!resolved?.readyForIk) {
    return false
  }
  const side = getMouthCornerLabSide(resolved.sideId || "right")
  if (c.controlId !== side.controlId) {
    return false
  }
  if (c.channel !== CHANNEL_X && c.channel !== CHANNEL_Y) {
    return false
  }
  const sid = c.servoId
  return sid === resolved.servoAId || sid === resolved.servoBId
}

export function contributionExcludedForRightMouthFiveBar(c, resolved) {
  return contributionExcludedForMouthFiveBar(c, resolved)
}

/**
 * 在已有 pose 上应用右嘴角五杆（供外部与 mapFaceRigToPose 共用）。
 * 成功时：期望 pose.logicalPose 已由「已排除 mouth_corner_r→A/B 的贡献」合并得到，本函数写入两路 PWM 与 actual。
 * 若传入 ikResult 且 ok 为 false，仅写入 diagnostics，不修改 pose 中的 PWM。
 *
 * @param {{
 *   rig: object,
 *   profile: object,
 *   configs: object[],
 *   pose: { logicalPose: object, actualPose: object, contributions: object[], warnings: string[] },
 *   kinematics?: object,
 *   ikResult?: ReturnType<typeof computeRightMouthCornerFiveBarIk>,
 *   rightMouthCornerFivebarState?: ReturnType<typeof createRightMouthCornerFivebarState>
 * }} args
 */
export function applyFaceRigKinematicsOverrides(args) {
  const {
    rig,
    profile,
    configs = [],
    pose,
    kinematics: kinematicsUser,
    ikResult: ikResultIn,
    rightMouthCornerFivebarState: fiveBarStateIn,
  } = args || {}
  if (!pose || typeof pose !== "object") {
    return pose
  }
  const sideId = args?.sideId || "right"
  const side = getMouthCornerLabSide(sideId)
  const rigValues = isRigValuesShapeForSide(rig, side.rigValuesKey)
    ? rig
    : { [side.rigValuesKey]: rigValuesForMouthCorner(rig, sideId) }
  const rt = args?.rightMouthRuntime ?? args?.mouthRuntime
  const resolved = resolveMouthCornerKinematics(profile, sideId, {
    runtimeParams: rt?.params ?? args?.runtimeParams,
    runtimeBindingOverride: rt?.bindingOverride ?? args?.runtimeBindingOverride,
    kinematics: kinematicsUser,
    runtimeSource: rt?.source ?? args?.runtimeSource,
  })
  if (!pose.kinematics) {
    pose.kinematics = {}
  }

  if (!resolved.enabled) {
    pose.kinematics.rightMouthCorner = {
      enabled: false,
      overrideNote: "",
      ikOk: null,
      ikMessage: "",
    }
    return pose
  }

  if (!resolved.readyForIk) {
    if (resolved.skipReason) {
      pose.warnings = [...(pose.warnings || []), resolved.skipReason]
    }
    pose.kinematics.rightMouthCorner = {
      enabled: true,
      readyForIk: false,
      overrideNote: "",
      ikOk: null,
      ikMessage: resolved.skipReason || "未就绪",
      servoAId: resolved.servoAId,
      servoBId: resolved.servoBId,
    }
    return pose
  }

  const ikResult =
    ikResultIn ??
    computeMouthCornerFiveBarIk(
      rigValues,
      resolved,
      fiveBarStateIn ?? createRightMouthCornerFivebarState(),
      sideId
    )
  const diag = ikResult.diagnostics
  pose.kinematics.rightMouthCorner = diag
  pose.kinematics.rightMouthCornerFivebar = diag

  if (!ikResult.ok) {
    pose.warnings = [...(pose.warnings || []), `右嘴角五杆 IK：${ikResult.message}`]
    return pose
  }

  const cfgList = Array.isArray(configs) ? configs : []
  const sa = String(resolved.servoAId)
  const sb = String(resolved.servoBId)
  pose.logicalPose[sa] = ikResult.pwmA
  pose.logicalPose[sb] = ikResult.pwmB

  for (const sid of [resolved.servoAId, resolved.servoBId]) {
    const key = String(sid)
    const cfg = getServoConfig(cfgList, sid)
    if (cfg.enabled === false) {
      pose.warnings = [...(pose.warnings || []), `舵机 ${sid}：未启用，五杆输出跳过 actual 映射`]
      continue
    }
    const r = logicalToActualPwm(pose.logicalPose[key], cfg)
    pose.actualPose[key] = r.actualPwm
  }

  if (pose.kinematics?.rightMouthCorner) {
    const k = pose.kinematics.rightMouthCorner
    const sa = String(resolved.servoAId)
    const sb = String(resolved.servoBId)
    k.actualPwmA = pose.actualPose[sa] ?? null
    k.actualPwmB = pose.actualPose[sb] ?? null
    attachEffectiveRuntimeDiagnostics(
      k,
      resolved.params,
      resolved.runtimeSource,
      resolved.diagnosticsSource
    )
    pose.kinematics.rightMouthCornerFivebar = k
  }

  for (const c of pose.contributions || []) {
    if (contributionExcludedForRightMouthFiveBar(c, resolved)) {
      c.supersededByFiveBarIk = true
    }
  }

  return pose
}
