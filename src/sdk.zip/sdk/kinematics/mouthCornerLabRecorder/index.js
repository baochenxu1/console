/**
 * Kinematics Lab · 嘴角 FiveBar 会话录制
 *
 * 分层：
 * - sessionSchema.js — JSON 结构与单帧字段（纯函数）
 * - store.js         — 录制运行时（定时器 + 帧缓冲，模块级单例）
 * - useMouthCornerLabRecorder.js（hooks/）— React UI 订阅
 * - KinematicsDebugDrawer.jsx — 底部录制面板
 * - KinematicsLabPage.jsx     — 采样逻辑（MediaPipe + IK + 舵机）
 */

export {
  MOUTH_CORNER_LAB_SESSION_VERSION,
  MOUTH_CORNER_LAB_RECORD_DURATION_MS,
  MOUTH_CORNER_LAB_RECORD_SAMPLE_MS,
  createMouthCornerLabSessionMeta,
  buildMouthCornerLabSessionFrame,
  buildMouthCornerLabSessionExport,
} from "./sessionSchema.js"

export { resolvePreviewCommand, computePadMismatch } from "./labRecordSample.js"

export {
  subscribeLabRecorder,
  getLabRecorderSnapshot,
  isLabRecorderActive,
  pushLabRecorderFrame,
  startLabRecorder,
  stopLabRecorder,
  clearLabRecorder,
  getLabRecorderExportPayload,
  getLabRecorderDurationMs,
} from "./store.js"
