/**
 * 嘴角 Lab 会话 JSON 结构：meta / 单帧序列化 / 导出包。
 */

import { computePadMismatch } from "./labRecordSample.js"

export const MOUTH_CORNER_LAB_SESSION_VERSION = "facedev.mouthCornerLab.session.v1"
export const MOUTH_CORNER_LAB_RECORD_DURATION_MS = 5000
/** 录制轮询间隔（约 30fps） */
export const MOUTH_CORNER_LAB_RECORD_SAMPLE_MS = 33

const CAL_KEYS = [
  "Kx",
  "Ky",
  "xSign",
  "ySign",
  "qSignA",
  "qSignB",
  "qGainA",
  "qGainB",
  "servoSwap",
  "outputMode",
  "sendMode",
  "servoTimeMs",
  "useProfileServoIds",
]

/**
 * @param {object} [opts]
 */
export function createMouthCornerLabSessionMeta(opts = {}) {
  const cal = opts.calibration && typeof opts.calibration === "object" ? opts.calibration : {}
  /** @type {Record<string, unknown>} */
  const calibration = {}
  for (const k of CAL_KEYS) {
    if (cal[k] !== undefined) {
      calibration[k] = cal[k]
    }
  }
  return {
    version: MOUTH_CORNER_LAB_SESSION_VERSION,
    label: `mouth-corner-lab-${opts.sideId || "right"}`,
    sideId: opts.sideId || "right",
    rigSideKey: opts.rigSideKey || "sideR",
    mechanismId: opts.mechanismId || "",
    startedAt: opts.startedAt || new Date().toISOString(),
    endedAt: null,
    wsUrl: opts.wsUrl || "",
    durationLimitMs: MOUTH_CORNER_LAB_RECORD_DURATION_MS,
    sampleIntervalMs: MOUTH_CORNER_LAB_RECORD_SAMPLE_MS,
    frameCount: 0,
    calibration,
  }
}

/**
 * @param {object | null | undefined} evalResult
 */
function pickKinematics(evalResult) {
  if (!evalResult || typeof evalResult !== "object") {
    return null
  }
  return {
    ok: Boolean(evalResult.ok),
    scale: evalResult.scale ?? null,
    DRaw: evalResult.DRaw ?? null,
    DSafe: evalResult.DSafe ?? null,
    padRaw: evalResult.padRaw ?? null,
    padSafe: evalResult.padSafe ?? null,
    qRaw: evalResult.qRaw ?? null,
    qCmd: evalResult.qCmd ?? null,
    qSend: evalResult.qSend ?? null,
    rawReachable: evalResult.rawReachable ?? null,
    message: evalResult.message ?? "",
  }
}

/**
 * @param {object | null | undefined} preview
 * @param {string} [command]
 * @param {boolean} [skipped]
 * @param {string} [sendMode]
 */
function pickServo(preview, command, skipped, sendMode) {
  if (!preview || typeof preview !== "object") {
    return {
      canSend: false,
      blockReasons: [],
      servoA: null,
      servoB: null,
      logicalPwmA: null,
      logicalPwmB: null,
      actualPwmA: null,
      actualPwmB: null,
      logicalDeltaA: null,
      logicalDeltaB: null,
      actualDeltaA: null,
      actualDeltaB: null,
      qSendMode: null,
      outputMode: null,
      sendMode: sendMode || null,
      command: command || "",
      multiBraceCommand: "",
      sequentialCommand: "",
      singleCommands: [],
      skipped: Boolean(skipped),
    }
  }

  const singleCommands = Array.isArray(preview.singleCommands) ? [...preview.singleCommands] : []
  const multiBraceCommand =
    typeof preview.multiBraceCommand === "string" ? preview.multiBraceCommand : ""
  const sequentialCommand =
    typeof preview.sequentialCommand === "string" ? preview.sequentialCommand : ""
  const resolvedCommand =
    command ||
    preview.sentCommand ||
    preview.command ||
    sequentialCommand ||
    multiBraceCommand ||
    (singleCommands.length > 0 ? singleCommands.join(" ") : "")

  return {
    canSend: Boolean(preview.canSend),
    blockReasons: Array.isArray(preview.blockReasons) ? [...preview.blockReasons] : [],
    servoA: preview.servoAId ?? preview.profileServoAId ?? null,
    servoB: preview.servoBId ?? preview.profileServoBId ?? null,
    logicalPwmA: preview.logicalPwmA ?? null,
    logicalPwmB: preview.logicalPwmB ?? null,
    actualPwmA: preview.actualPwmA ?? null,
    actualPwmB: preview.actualPwmB ?? null,
    logicalDeltaA: preview.logicalDeltaA ?? null,
    logicalDeltaB: preview.logicalDeltaB ?? null,
    actualDeltaA: preview.actualDeltaA ?? null,
    actualDeltaB: preview.actualDeltaB ?? null,
    qSendMode: preview.qSendMode ?? null,
    outputMode: preview.outputMode ?? null,
    sendMode: sendMode || null,
    command: resolvedCommand,
    multiBraceCommand,
    sequentialCommand,
    singleCommands,
    skipped: Boolean(skipped),
  }
}

function resolveFrameSource(ctx) {
  if (ctx.source) {
    return ctx.source
  }
  if (ctx.padSource === "tracking") {
    return "poll"
  }
  if (ctx.padSource === "manual-pad" || ctx.padSource === "fallback-center") {
    return "poll"
  }
  return "poll"
}

/**
 * @param {object} ctx
 * @param {string} ctx.sideId
 * @param {string} ctx.rigSideKey
 * @param {import("../../tracking/trackingTypes.js").RigFrame | null} [ctx.lastFrame]
 * @param {object | null} [ctx.trackingStatus]
 * @param {{ x: number, y: number } | null} [ctx.padUsed]
 * @param {object | null} [ctx.evalResult]
 * @param {object | null} [ctx.preview]
 * @param {string} [ctx.command]
 * @param {boolean} [ctx.skipped]
 * @param {"periodic-drive" | "poll" | "live"} [ctx.source]
 * @param {string} [ctx.padSource]
 * @param {number | string | null} [ctx.frameSeq]
 * @param {string} [ctx.sendMode]
 * @param {string} [ctx.actualLastSentCommand]
 * @param {boolean | null} [ctx.padMismatch]
 */
export function buildMouthCornerLabSessionFrame(ctx) {
  const mouth = ctx.lastFrame?.rig?.mouth
  const pt = mouth?.[ctx.rigSideKey]
  const status = ctx.trackingStatus
  const padUsed = ctx.padUsed ?? null

  const mouthCorner =
    pt && Number.isFinite(Number(pt.x)) && Number.isFinite(Number(pt.y))
      ? { x: Number(pt.x), y: Number(pt.y) }
      : padUsed && Number.isFinite(Number(padUsed.x)) && Number.isFinite(Number(padUsed.y))
        ? { x: Number(padUsed.x), y: Number(padUsed.y) }
        : null

  const frameSeq =
    ctx.frameSeq ?? ctx.lastFrame?.seq ?? status?.lastFrameSeq ?? null

  const padMismatch =
    ctx.padMismatch !== undefined
      ? ctx.padMismatch
      : computePadMismatch(padUsed, ctx.evalResult)

  return {
    t: new Date().toISOString(),
    source: resolveFrameSource(ctx),
    sideId: ctx.sideId,
    padSource: ctx.padSource || (padUsed ? "unknown" : "none"),
    padMismatch,
    actualLastSentCommand: ctx.actualLastSentCommand ?? "",
    mediaPipe: {
      trackingStatus: status
        ? {
            running: Boolean(status.running),
            faceDetected: Boolean(status.faceDetected),
            fps: Number(status.fps) || 0,
            rxFps: Number(status.rxFps) || 0,
            quality: Number(status.quality) || 0,
            lastFrameSeq: status.lastFrameSeq ?? null,
            error: status.error ?? null,
          }
        : null,
      mouthCorner,
      frameSeq,
    },
    pad: padUsed,
    kinematics: pickKinematics(ctx.evalResult),
    servo: pickServo(ctx.preview, ctx.command, ctx.skipped, ctx.sendMode),
  }
}

/**
 * @param {object} meta
 * @param {object[]} frames
 */
export function buildMouthCornerLabSessionExport(meta, frames) {
  return {
    meta: {
      ...meta,
      endedAt: meta.endedAt || new Date().toISOString(),
      frameCount: frames.length,
    },
    frames,
  }
}
