# 嘴角 Lab 会话录制

机构调试台底部「录制 5s」功能，导出 `facedev-mouth-lab-{side}-*.json`。

## 文件一览

| 文件 | 职责 |
|------|------|
| `sessionSchema.js` | 常量、meta、单帧 `buildMouthCornerLabSessionFrame`、导出包 |
| `labRecordSample.js` | `resolvePreviewCommand`、`computePadMismatch` |
| `store.js` | 模块级录制状态：`start` / `stop` / `push` / 33ms 采样 / 5s 自动停 |
| `index.js` | 统一导出 |
| `../../hooks/useMouthCornerLabRecorder.js` | `useSyncExternalStore` 订阅 store，供 UI 显示帧数 |
| `../../react/kinematics/KinematicsDebugDrawer.jsx` | 录制按钮、状态、复制/导出 |
| `../../../pages/KinematicsLabPage.jsx` | 实现 `sampleFn`：读 Tracking + FiveBar IK + 舵机命令 |

## 数据流

```
KinematicsLabPage.buildLabRecordFrameFromPad(padNow)
  → evaluateMouthFiveBarPadPoint(padNow)   [与 pad 一致]
  → buildMouthFiveBarSendPreview(...)
  → resolvePreviewCommand(preview)
  → buildMouthCornerLabSessionFrame(...)
  → pushLabRecorderFrame(frame)     [store.js]
  → notify() → useSyncExternalStore  [UI 帧数更新]

startLabRecorder(meta, sampleFn, onAutoComplete)
  → setInterval(sampleFn, 33ms)
  → setTimeout(5s) → stop + exportJsonFile
```

## 单帧 JSON 字段

- `mediaPipe` — Tracking 状态 + `mouthCorner`（sideR/sideL）+ `frameSeq`（含 lastFrameSeq 兜底）
- `pad` / `padSource` — `tracking` | `manual-pad` | `fallback-center`
- `kinematics` — DRaw/DSafe、qRaw/qCmd/qSend、scale
- `servo` — canSend、blockReasons、command（按 sendMode 解析）、PWM/delta
- `padMismatch` — padUsed 与 kinematics.padRaw 是否不一致（应为 false）
- `actualLastSentCommand` — 周期驱动实际上次下发（诊断用）

## Store 状态（UI 订阅）

- `lastError` — 采样或导出失败原因
- `lastSampleAt` / `lastPushedAt` — 最近一次采样 / 成功 push 时间
- `samplingBusy` — 防 async sample 重入（内部）

## 已删除（勿再引用）

- `useMediaPipeDebugJsonRecorder.js` — 旧 React hook 实现，已由 store 替代
- `trackingDebugJsonRecord.js` — 仅含 raw lastFrame 的简化版，已废弃
