/**
 * 模块级录制运行时：定时采样、帧缓冲、5s 自动停止。
 * 帧数据每 tick 写入；UI 通知节流，避免整页同步重渲染拖死采样循环。
 */
import {
  MOUTH_CORNER_LAB_RECORD_DURATION_MS,
  MOUTH_CORNER_LAB_RECORD_SAMPLE_MS,
  buildMouthCornerLabSessionExport,
  createMouthCornerLabSessionMeta,
} from "./sessionSchema.js"

const MAX_FRAMES = 250
const UI_NOTIFY_MS = 80
const DEV = typeof import.meta !== "undefined" && Boolean(import.meta.env?.DEV)

/** @type {object[]} */
let frames = []
/** @type {ReturnType<typeof createMouthCornerLabSessionMeta> | null} */
let meta = null
let active = false
let stopReason = ""
let lastError = ""
let lastSampleAt = /** @type {string | null} */ (null)
let lastPushedAt = /** @type {string | null} */ (null)
let samplingBusy = false
let startedAtMs = 0

/** @type {ReturnType<typeof setInterval> | null} */
let sampleIntervalId = null
/** @type {ReturnType<typeof setTimeout> | null} */
let autoStopTimeoutId = null
let uiNotifyTimer = null
/** @type {(() => void | Promise<void>) | null} */
let samplerFn = null
/** @type {((payload: object) => void) | null} */
let onAutoCompleteFn = null

/** @type {Set<() => void>} */
const listeners = new Set()

let cachedSnapshot = {
  active: false,
  frameCount: 0,
  meta: /** @type {ReturnType<typeof createMouthCornerLabSessionMeta> | null} */ (null),
  stopReason: "",
  lastError: "",
  lastSampleAt: /** @type {string | null} */ (null),
  lastPushedAt: /** @type {string | null} */ (null),
}

/** @returns {boolean} 快照引用是否已更新 */
function rebuildSnapshot() {
  const frameCount = frames.length
  if (
    cachedSnapshot.active === active &&
    cachedSnapshot.frameCount === frameCount &&
    cachedSnapshot.meta === meta &&
    cachedSnapshot.stopReason === stopReason &&
    cachedSnapshot.lastError === lastError &&
    cachedSnapshot.lastSampleAt === lastSampleAt &&
    cachedSnapshot.lastPushedAt === lastPushedAt
  ) {
    return false
  }
  cachedSnapshot = {
    active,
    frameCount,
    meta,
    stopReason,
    lastError,
    lastSampleAt,
    lastPushedAt,
  }
  return true
}

rebuildSnapshot()

function flushListeners() {
  for (const fn of listeners) {
    try {
      fn()
    } catch {
      /* ignore */
    }
  }
}

/**
 * @param {boolean} [immediate] 停止/开始时立即刷新 UI
 */
function notifyListeners(immediate = false) {
  rebuildSnapshot()
  if (immediate) {
    if (uiNotifyTimer != null) {
      clearTimeout(uiNotifyTimer)
      uiNotifyTimer = null
    }
    flushListeners()
    return
  }
  if (uiNotifyTimer != null) {
    return
  }
  uiNotifyTimer = setTimeout(() => {
    uiNotifyTimer = null
    flushListeners()
  }, UI_NOTIFY_MS)
}

function clearTimers() {
  if (sampleIntervalId != null) {
    clearInterval(sampleIntervalId)
    sampleIntervalId = null
  }
  if (autoStopTimeoutId != null) {
    clearTimeout(autoStopTimeoutId)
    autoStopTimeoutId = null
  }
  if (uiNotifyTimer != null) {
    clearTimeout(uiNotifyTimer)
    uiNotifyTimer = null
  }
}

function elapsedMs() {
  return startedAtMs > 0 ? Date.now() - startedAtMs : 0
}

function shouldStopByDuration() {
  return startedAtMs > 0 && elapsedMs() >= MOUTH_CORNER_LAB_RECORD_DURATION_MS
}

async function runSamplerTick() {
  if (!active || typeof samplerFn !== "function") {
    return
  }

  if (shouldStopByDuration()) {
    stopLabRecorder("已录满 5 秒", true)
    return
  }

  if (samplingBusy) {
    return
  }

  samplingBusy = true
  lastSampleAt = new Date().toISOString()

  try {
    const result = samplerFn()
    if (result != null && typeof /** @type {any} */ (result).then === "function") {
      await result
    }
    lastError = ""
  } catch (err) {
    lastError = err?.message || String(err)
    console.warn("[mouth-lab-recorder] sample failed:", err)
  } finally {
    samplingBusy = false
    notifyListeners(false)

    if (active && shouldStopByDuration()) {
      stopLabRecorder("已录满 5 秒", true)
    }
  }
}

/** useSyncExternalStore：必须在数据变更时换新引用，读取时不得重建。 */
export function getLabRecorderSnapshot() {
  return cachedSnapshot
}

/** @param {() => void} listener */
export function subscribeLabRecorder(listener) {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

export function isLabRecorderActive() {
  return active
}

/** @param {object} frame */
export function pushLabRecorderFrame(frame) {
  if (!active) {
    lastError = "push 时录制未激活"
    if (DEV) {
      console.warn("[mouth-lab-recorder]", lastError, { frameCount: frames.length })
    }
    notifyListeners(false)
    return false
  }
  if (!frame || typeof frame !== "object") {
    lastError = "push 收到空帧"
    if (DEV) {
      console.warn("[mouth-lab-recorder]", lastError)
    }
    notifyListeners(false)
    return false
  }
  if (frames.length >= MAX_FRAMES) {
    stopLabRecorder("帧缓冲已满", true)
    return false
  }

  frames.push(frame)
  lastPushedAt = new Date().toISOString()
  lastError = ""
  if (meta) {
    meta = { ...meta, frameCount: frames.length }
  }

  if (DEV && frames.length % 50 === 0) {
    console.info(`[mouth-lab-recorder] ${frames.length} frames, ${elapsedMs()}ms`)
  }

  notifyListeners(false)
  return true
}

/**
 * @param {object} [sessionMeta]
 * @param {() => void | Promise<void>} sampleFn
 * @param {(payload: object) => void} [onAutoComplete]
 */
export function startLabRecorder(sessionMeta = {}, sampleFn, onAutoComplete) {
  if (typeof sampleFn !== "function") {
    const msg = "startLabRecorder: sampleFn required"
    lastError = msg
    console.warn("[mouth-lab-recorder]", msg)
    notifyListeners(true)
    return
  }

  if (active) {
    stopLabRecorder("", false)
  }

  clearTimers()
  frames = []
  stopReason = ""
  lastError = ""
  lastSampleAt = null
  lastPushedAt = null
  samplingBusy = false
  startedAtMs = Date.now()
  samplerFn = sampleFn
  onAutoCompleteFn = typeof onAutoComplete === "function" ? onAutoComplete : null
  meta = createMouthCornerLabSessionMeta({
    ...sessionMeta,
    startedAt: new Date().toISOString(),
  })
  active = true
  notifyListeners(true)

  void runSamplerTick()
  sampleIntervalId = setInterval(() => {
    void runSamplerTick()
  }, MOUTH_CORNER_LAB_RECORD_SAMPLE_MS)
  autoStopTimeoutId = setTimeout(() => {
    if (active) {
      stopLabRecorder("已录满 5 秒", true)
    }
  }, MOUTH_CORNER_LAB_RECORD_DURATION_MS)
}

/**
 * @param {string} [reason]
 * @param {boolean} [autoExport]
 */
export function stopLabRecorder(reason = "", autoExport = false) {
  if (!active && frames.length === 0 && !meta) {
    return null
  }

  const wasActive = active
  active = false
  samplingBusy = false
  samplerFn = null
  clearTimers()

  if (reason) {
    stopReason = reason
  }

  const endedMeta = {
    ...(meta || createMouthCornerLabSessionMeta()),
    endedAt: new Date().toISOString(),
    frameCount: frames.length,
  }
  meta = endedMeta
  const payload = buildMouthCornerLabSessionExport(endedMeta, frames)

  if (DEV && wasActive) {
    console.info(
      `[mouth-lab-recorder] stopped: ${frames.length} frames, ${elapsedMs()}ms, reason=${stopReason || reason}`
    )
  }

  notifyListeners(true)

  if (autoExport && onAutoCompleteFn) {
    try {
      onAutoCompleteFn(payload)
    } catch (err) {
      lastError = `自动导出失败：${err?.message || String(err)}`
      console.warn("[mouth-lab-recorder] onAutoComplete failed:", err)
      notifyListeners(true)
    }
  }

  startedAtMs = 0
  return payload
}

export function clearLabRecorder() {
  active = false
  samplingBusy = false
  samplerFn = null
  startedAtMs = 0
  clearTimers()
  frames = []
  stopReason = ""
  lastError = ""
  lastSampleAt = null
  lastPushedAt = null
  meta = null
  notifyListeners(true)
}

export function getLabRecorderExportPayload() {
  const exportMeta = meta || createMouthCornerLabSessionMeta()
  return buildMouthCornerLabSessionExport(exportMeta, frames)
}

export function getLabRecorderDurationMs() {
  return MOUTH_CORNER_LAB_RECORD_DURATION_MS
}
