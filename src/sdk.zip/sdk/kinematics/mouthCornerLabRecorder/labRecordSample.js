/**
 * Lab 录制采样辅助：preview 命令解析、pad 一致性诊断。
 */

/**
 * @param {object | null | undefined} preview
 * @param {string} [preferredSendMode]
 */
export function resolvePreviewCommand(preview, preferredSendMode) {
  if (!preview || typeof preview !== "object") {
    return ""
  }

  const mode = preferredSendMode || "separate-write"
  const singleCommands = Array.isArray(preview.singleCommands) ? preview.singleCommands : []

  if (mode === "separate-write") {
    return singleCommands.length > 0
      ? singleCommands.join(" | ")
      : preview.command || preview.sentCommand || ""
  }
  if (mode === "sequential-string") {
    return preview.sequentialCommand || preview.command || preview.sentCommand || ""
  }
  if (mode === "multi-brace") {
    return preview.multiBraceCommand || preview.command || preview.sentCommand || ""
  }

  return (
    preview.command ||
    preview.sentCommand ||
    preview.sequentialCommand ||
    preview.multiBraceCommand ||
    (singleCommands.length > 0 ? singleCommands.join(" | ") : "")
  )
}

/**
 * @param {{ x: number, y: number } | null | undefined} padUsed
 * @param {object | null | undefined} evalResult
 */
export function computePadMismatch(padUsed, evalResult) {
  const pr = evalResult?.padRaw
  if (!padUsed || !pr) {
    return null
  }
  const x = Number(padUsed.x)
  const y = Number(padUsed.y)
  const px = Number(pr.x)
  const py = Number(pr.y)
  if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(px) || !Number.isFinite(py)) {
    return null
  }
  return Math.abs(x - px) > 0.01 || Math.abs(y - py) > 0.01
}
