import {
  SERVO_LOGICAL_MAX_PWM,
  SERVO_LOGICAL_MIN_PWM,
  STANDARD_CENTER_PWM,
  getServoConfig,
  logicalToActualPwm,
} from "../../core/servoConfig.js"
import {
  buildMultiServoMoveCommand,
  buildServoMoveCommand,
} from "../../core/servoProtocol.js"
import { CHANNEL_X, CHANNEL_Y } from "../../core/faceRigProfile.js"
import { clampNumber } from "../../utils/clamp.js"
import { angleToBindingLogicalPwm } from "./mouthCornerFivebar.js"
import { getMouthCornerLabSide } from "./mouthCornerFiveBarLabConfig.js"

const SCALE_MIN_SEND = 0.8

/** @typedef {"static-target" | "stateful-one-step" | "run-to-target"} LabOutputMode */
/** @typedef {"separate-write" | "sequential-string" | "multi-brace"} LabSendMode */

/** @param {import("./mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} sideId */
export function createDefaultMouthLabCalibration(sideId) {
  const side = getMouthCornerLabSide(sideId)
  const d = side.defaultCalibration
  return {
    Kx: d.Kx,
    Ky: d.Ky,
    xSign: d.xSign,
    ySign: d.ySign,
    qSignA: d.qSignA,
    qSignB: d.qSignB,
    qGainA: d.qGainA,
    qGainB: d.qGainB,
    servoSwap: d.servoSwap,
    useProfileServoIds: true,
    servoTimeMs: 40,
    runIntervalMs: 30,
    minVisibleDeltaUs: 1,
    outputMode: /** @type {LabOutputMode} */ ("static-target"),
    sendMode: /** @type {LabSendMode} */ ("separate-write"),
    livePadDriveEnabled: false,
    livePadDriveIntervalMs: 40,
    mediaPipeRightMouthDriveEnabled: false,
    mediaPipeLeftMouthDriveEnabled: false,
  }
}

/** @param {import("./mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} sideId */
/** @param {unknown} raw */
export function loadMouthLabCalibration(sideId, raw) {
  const side = getMouthCornerLabSide(sideId)
  const base = createDefaultMouthLabCalibration(sideId)
  if (!raw || typeof raw !== "object") {
    return base
  }
  const o = /** @type {Record<string, unknown>} */ (raw)
  const num = (k, def) => {
    const v = Number(o[k])
    return Number.isFinite(v) ? v : def
  }
  const sign = (k, def) => {
    const v = Number(o[k])
    return v === -1 ? -1 : def
  }
  return {
    ...base,
    Kx: clampNumber(num("Kx", base.Kx), 0.1, 50),
    Ky: clampNumber(num("Ky", base.Ky), 0.1, 50),
    xSign: sign("xSign", base.xSign),
    ySign: sign("ySign", base.ySign),
    qSignA: sign("qSignA", base.qSignA),
    qSignB: sign("qSignB", base.qSignB),
    qGainA: clampNumber(num("qGainA", base.qGainA), 0.01, 4),
    qGainB: clampNumber(num("qGainB", base.qGainB), 0.01, 4),
    servoSwap: Boolean(o.servoSwap),
    useProfileServoIds:
      o.useProfileServoIds !== undefined ? Boolean(o.useProfileServoIds) : base.useProfileServoIds,
    servoTimeMs: clampNumber(num("servoTimeMs", base.servoTimeMs), 0, 9999),
    runIntervalMs: clampNumber(num("runIntervalMs", base.runIntervalMs), 10, 2000),
    minVisibleDeltaUs: clampNumber(num("minVisibleDeltaUs", base.minVisibleDeltaUs), 1, 500),
    outputMode:
      o.outputMode === "stateful-one-step" || o.outputMode === "run-to-target"
        ? o.outputMode
        : "static-target",
    sendMode:
      o.sendMode === "sequential-string" || o.sendMode === "multi-brace"
        ? o.sendMode
        : "separate-write",
    livePadDriveEnabled: Boolean(o.livePadDriveEnabled),
    livePadDriveIntervalMs: clampNumber(num("livePadDriveIntervalMs", base.livePadDriveIntervalMs), 16, 500),
    mediaPipeRightMouthDriveEnabled: Boolean(o.mediaPipeRightMouthDriveEnabled),
    mediaPipeLeftMouthDriveEnabled: Boolean(o.mediaPipeLeftMouthDriveEnabled),
  }
}

export async function sendMouthFiveBarPreview(preview, sendMode, writeText) {
  if (!preview?.canSend) {
    return { ok: false, command: "", error: (preview?.blockReasons || ["不可发送"]).join("；") }
  }
  const mode = sendMode || "separate-write"
  let sentCmd = ""
  if (mode === "separate-write") {
    for (const cmd of preview.singleCommands) {
      await writeText(cmd)
    }
    sentCmd = preview.singleCommands.join(" ")
  } else if (mode === "sequential-string") {
    await writeText(preview.sequentialCommand)
    sentCmd = preview.sequentialCommand
  } else {
    await writeText(preview.multiBraceCommand)
    sentCmd = preview.multiBraceCommand
  }
  return { ok: true, command: sentCmd, error: "" }
}

/** @param {import("./mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} sideId */
export function buildLabKinematicsOverrideForSide(sideId, calibration, outputModeOverride) {
  const cal = loadMouthLabCalibration(sideId, calibration)
  const mode = outputModeOverride || cal.outputMode || "static-target"
  const stateful = mode === "stateful-one-step" || mode === "run-to-target"
  return {
    rightMouthCornerFiveBar: {
      enabled: true,
      runtimeOutputMode: mode,
      Kx: cal.Kx,
      Ky: cal.Ky,
      xSign: cal.xSign,
      ySign: cal.ySign,
      maxStepDeg: stateful ? 90 : 1.0,
      filterAlpha: stateful ? 1.0 : 0.25,
    },
  }
}

function applyAngleLabMods(qDeg, sign, gain) {
  return Number(qDeg) * Number(sign) * Number(gain)
}

function isForbiddenExtremePad(pad) {
  const x = Number(pad?.x)
  const y = Number(pad?.y)
  if (!Number.isFinite(x) || !Number.isFinite(y)) {
    return false
  }
  return (x === 0 && y === 0) || (x === 100 && y === 100)
}

/**
 * @param {object} args
 * @param {import("./mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} args.sideId
 */
export function buildMouthFiveBarSendPreview({
  sideId = "right",
  evalResult,
  pad,
  calibration,
  resolved,
  configs = [],
  outputMode,
}) {
  const side = getMouthCornerLabSide(sideId)
  const cal = loadMouthLabCalibration(sideId, calibration)
  const mode = outputMode || cal.outputMode || "static-target"
  const swap = Boolean(cal.servoSwap)
  const profA = resolved?.servoAId
  const profB = resolved?.servoBId
  let bindingA = resolved?.bindingA
  let bindingB = resolved?.bindingB
  let profileServoAId = profA
  let profileServoBId = profB
  if (swap) {
    bindingA = resolved?.bindingB
    bindingB = resolved?.bindingA
    profileServoAId = profB
    profileServoBId = profA
  }
  const useProf = Boolean(cal.useProfileServoIds)
  const servoAId = useProf ? profileServoAId : side.labHwServoA
  const servoBId = useProf ? profileServoBId : side.labHwServoB
  const timeMs = clampNumber(Number(cal.servoTimeMs) || 50, 0, 9999)

  const qRaw = evalResult?.qRaw
  const qCmd = evalResult?.qCmd
  const qSendMode = mode === "run-to-target" ? "stateful-one-step" : mode
  let qSend = null
  if (qSendMode === "static-target" && qRaw) {
    qSend = qRaw
  } else if (qCmd) {
    qSend = qCmd
  }

  let errorA = null
  let errorB = null
  let errorAbsA = null
  let errorAbsB = null
  if (qSendMode === "stateful-one-step" && qRaw && qCmd) {
    errorA = Number(qRaw.qA_deg) - Number(qCmd.qA_deg)
    errorB = Number(qRaw.qB_deg) - Number(qCmd.qB_deg)
    errorAbsA = Math.abs(errorA)
    errorAbsB = Math.abs(errorB)
  }

  let logicalPwmA = null
  let logicalPwmB = null
  if (qSend && bindingA && bindingB) {
    const qA = applyAngleLabMods(qSend.qA_deg, cal.qSignA, cal.qGainA)
    const qB = applyAngleLabMods(qSend.qB_deg, cal.qSignB, cal.qGainB)
    logicalPwmA = angleToBindingLogicalPwm(qA, bindingA)
    logicalPwmB = angleToBindingLogicalPwm(qB, bindingB)
  }

  const blockReasons = []
  if (isForbiddenExtremePad(pad)) {
    blockReasons.push("禁止发送 Pad 0/0 或 100/100 极限点")
  }
  if (!evalResult?.ok) {
    blockReasons.push(evalResult?.message || "evaluate 失败")
  }
  if (!evalResult?.qSend && !qSend) {
    blockReasons.push("qSend 无效")
  }
  if (evalResult?.scale != null && Number(evalResult.scale) < SCALE_MIN_SEND) {
    blockReasons.push(`scale=${Number(evalResult.scale).toFixed(2)} < ${SCALE_MIN_SEND}`)
  }
  if (!Number.isFinite(servoAId) || !Number.isFinite(servoBId)) {
    blockReasons.push("命令 servoId 无效")
  }

  const cfgList = Array.isArray(configs) ? configs : []
  const neutralLogicalA = Number(bindingA?.neutralPwm)
  const neutralLogicalB = Number(bindingB?.neutralPwm)
  const nLogA = Number.isFinite(neutralLogicalA) ? neutralLogicalA : STANDARD_CENTER_PWM
  const nLogB = Number.isFinite(neutralLogicalB) ? neutralLogicalB : STANDARD_CENTER_PWM

  const actualA =
    logicalPwmA != null && Number.isFinite(servoAId)
      ? logicalToActualPwm(logicalPwmA, getServoConfig(cfgList, servoAId))
      : null
  const actualB =
    logicalPwmB != null && Number.isFinite(servoBId)
      ? logicalToActualPwm(logicalPwmB, getServoConfig(cfgList, servoBId))
      : null

  const moves = []
  for (const [label, sid, logical, actual] of [
    ["A", servoAId, logicalPwmA, actualA],
    ["B", servoBId, logicalPwmB, actualB],
  ]) {
    if (logical == null || !Number.isFinite(Number(logical))) {
      blockReasons.push(`logicalPwm${label} 无效`)
      continue
    }
    const lg = Number(logical)
    if (lg < SERVO_LOGICAL_MIN_PWM || lg > SERVO_LOGICAL_MAX_PWM) {
      blockReasons.push(`logicalPwm${label} 超出逻辑限位`)
    }
    if (!actual) {
      blockReasons.push(`servo${label} 配置无效`)
      continue
    }
    const cfg = getServoConfig(cfgList, sid)
    if (cfg.enabled === false) {
      blockReasons.push(`舵机 ${sid} 未启用`)
    }
    if (actual.limited) {
      blockReasons.push(`actualPwm（servo ${sid}）被钳制`)
    }
    moves.push({
      servoId: sid,
      pwm: actual.actualPwm,
      timeMs,
      minPwm: cfg.actualMinPwm,
      maxPwm: cfg.actualMaxPwm,
    })
  }

  let multiBraceCommand = ""
  let sequentialCommand = ""
  let singleCommands = []
  try {
    if (moves.length === 2 && blockReasons.length === 0) {
      singleCommands = moves.map((move) => buildServoMoveCommand(move))
      multiBraceCommand = buildMultiServoMoveCommand(moves)
      sequentialCommand = singleCommands.join("")
    }
  } catch (e) {
    blockReasons.push(e?.message || "命令构建失败")
  }

  const actAp = actualA?.actualPwm
  const actBp = actualB?.actualPwm
  const neutralActualA =
    Number.isFinite(servoAId) && Number.isFinite(nLogA)
      ? logicalToActualPwm(nLogA, getServoConfig(cfgList, servoAId)).actualPwm
      : null
  const neutralActualB =
    Number.isFinite(servoBId) && Number.isFinite(nLogB)
      ? logicalToActualPwm(nLogB, getServoConfig(cfgList, servoBId)).actualPwm
      : null

  const logicalNeutralA = Math.round(nLogA)
  const logicalNeutralB = Math.round(nLogB)
  const logicalDeltaA =
    logicalPwmA != null && Number.isFinite(logicalPwmA)
      ? Math.round(Number(logicalPwmA)) - logicalNeutralA
      : null
  const logicalDeltaB =
    logicalPwmB != null && Number.isFinite(logicalPwmB)
      ? Math.round(Number(logicalPwmB)) - logicalNeutralB
      : null
  const actualNeutralA =
    neutralActualA != null && Number.isFinite(neutralActualA) ? Math.round(Number(neutralActualA)) : null
  const actualNeutralB =
    neutralActualB != null && Number.isFinite(neutralActualB) ? Math.round(Number(neutralActualB)) : null
  const actualDeltaA =
    actAp != null && actualNeutralA != null ? Math.round(Number(actAp)) - actualNeutralA : null
  const actualDeltaB =
    actBp != null && actualNeutralB != null ? Math.round(Number(actBp)) - actualNeutralB : null
  const absDeltaA = actualDeltaA != null ? Math.abs(actualDeltaA) : null
  const absDeltaB = actualDeltaB != null ? Math.abs(actualDeltaB) : null
  const minVis = clampNumber(Number(cal.minVisibleDeltaUs) || 1, 1, 500)
  const visibleMotion =
    absDeltaA != null && absDeltaB != null ? !(absDeltaA < minVis && absDeltaB < minVis) : null

  return {
    sideId: side.id,
    pad,
    scale: evalResult?.scale,
    qRaw,
    qCmd,
    qSend,
    qSendMode,
    outputMode: mode,
    errorA,
    errorB,
    errorAbsA,
    errorAbsB,
    logicalPwmA,
    logicalPwmB,
    logicalNeutralA,
    logicalNeutralB,
    logicalDeltaA,
    logicalDeltaB,
    actualPwmA: actAp ?? null,
    actualPwmB: actBp ?? null,
    actualNeutralA,
    actualNeutralB,
    actualDeltaA,
    actualDeltaB,
    minVisibleDeltaUs: minVis,
    visibleMotion,
    profileServoAId: profA,
    profileServoBId: profB,
    servoAId,
    servoBId,
    multiBraceCommand,
    sequentialCommand,
    singleCommands,
    canSend: blockReasons.length === 0 && singleCommands.length === 2,
    blockReasons,
    timeMs,
  }
}

/** @param {object} profile */
/** @param {import("./mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} sideId */
/** @param {object} calibration */
/** @param {{ x: number, y: number }} [pad] */
export function buildMouthRuntimeSnapshot(profile, sideId, calibration, pad) {
  const side = getMouthCornerLabSide(sideId)
  const cal = loadMouthLabCalibration(sideId, calibration)
  const normalizedProfile = profile || {}

  const bindings = {}
  let servoAId = null
  let servoBId = null
  for (const b of normalizedProfile.bindings || []) {
    if (b?.controlId !== side.controlId || b.enabled === false) {
      continue
    }
    if (b.channel === CHANNEL_X || b.channel === CHANNEL_Y) {
      bindings[`${side.profileBindingPrefix}_${b.channel}`] = {
        bindingId: b.bindingId,
        servoId: b.servoId,
        neutralPwm: b.neutralPwm,
        pwmPerUnit: b.pwmPerUnit,
        invert: b.invert,
        enabled: b.enabled,
      }
      if (b.channel === CHANNEL_X) {
        servoAId = Number(b.servoId)
      }
      if (b.channel === CHANNEL_Y) {
        servoBId = Number(b.servoId)
      }
    }
  }
  const readyForIk = Number.isFinite(servoAId) && Number.isFinite(servoBId)

  return {
    version: `facedev.${side.id}MouthFivebar.runtimeSnapshot.v1`,
    side: side.id,
    savedAt: new Date().toISOString(),
    calibration: cal,
    runtime: {
      enabled: true,
      runtimeOutputMode: "static-target",
      Kx: cal.Kx,
      Ky: cal.Ky,
      xSign: cal.xSign,
      ySign: cal.ySign,
      qSignA: cal.qSignA,
      qSignB: cal.qSignB,
      qGainA: cal.qGainA,
      qGainB: cal.qGainB,
      servoSwap: cal.servoSwap,
      maxStepDeg: 1.0,
      filterAlpha: 0.25,
      servoTimeMs: cal.servoTimeMs,
      sendIntervalMs: cal.livePadDriveIntervalMs,
    },
    profileBindings: bindings,
    servoAId,
    servoBId,
    readyForIk,
    skipReason: readyForIk ? "" : `${side.controlId}.x/y 绑定未就绪`,
    pad: pad ? { x: Number(pad.x), y: Number(pad.y) } : null,
  }
}
