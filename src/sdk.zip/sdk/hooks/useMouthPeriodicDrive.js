import { useEffect, useRef } from "react"
import { webSerial } from "../../core/webSerial.js"
import { evaluateRightMouthPadPoint } from "../kinematics/mouthCornerFivebarDebug.js"
import {
  buildMouthFiveBarSendPreview,
  sendMouthFiveBarPreview,
} from "../kinematics/mouthCornerFiveBarLab.js"

/**
 * 固定周期 Pad → FiveBar → 串口（左右嘴角 Lab 共用）。
 *
 * @param {object} args
 * @param {import("../kinematics/mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} args.sideId
 */
export function useMouthPeriodicDrive({
  sideId = "right",
  enabled,
  intervalMs,
  getPad,
  resolved,
  calibration,
  configs,
  fiveBarStateRef,
  baudRate,
  onTick,
  onError,
}) {
  const getPadRef = useRef(getPad)
  const calibrationRef = useRef(calibration)
  const resolvedRef = useRef(resolved)
  const configsRef = useRef(configs)
  const onTickRef = useRef(onTick)
  const onErrorRef = useRef(onError)
  const baudRateRef = useRef(baudRate)
  const runningRef = useRef(false)
  const timerRef = useRef(/** @type {ReturnType<typeof setTimeout> | null} */ (null))
  const serialHintShownRef = useRef(false)

  getPadRef.current = getPad
  calibrationRef.current = calibration
  resolvedRef.current = resolved
  configsRef.current = configs
  onTickRef.current = onTick
  onErrorRef.current = onError
  baudRateRef.current = baudRate

  useEffect(() => {
    if (!enabled) {
      runningRef.current = false
      serialHintShownRef.current = false
      if (timerRef.current != null) {
        window.clearTimeout(timerRef.current)
        timerRef.current = null
      }
      return undefined
    }

    runningRef.current = true
    serialHintShownRef.current = false
    const ms = Math.max(16, Math.round(Number(intervalMs) || 40))

    const scheduleNext = () => {
      if (!runningRef.current) {
        return
      }
      timerRef.current = window.setTimeout(() => {
        timerRef.current = null
        void runOnce()
      }, ms)
    }

    const runOnce = async () => {
      if (!runningRef.current) {
        return
      }
      const r = resolvedRef.current
      if (!r?.readyForIk) {
        scheduleNext()
        return
      }
      try {
        const cal = calibrationRef.current
        const padNow = getPadRef.current()
        const evalResult = evaluateRightMouthPadPoint({
          pad: padNow,
          params: r.params,
          state: fiveBarStateRef.current,
          bindingA: r.bindingA,
          bindingB: r.bindingB,
          servoAId: r.servoAId,
          servoBId: r.servoBId,
          configs: configsRef.current,
          outputMode: "static-target",
        })
        const preview = buildMouthFiveBarSendPreview({
          sideId,
          evalResult,
          pad: padNow,
          calibration: { ...cal, outputMode: "static-target", useProfileServoIds: true },
          resolved: r,
          configs: configsRef.current,
          outputMode: "static-target",
        })
        if (!preview.canSend) {
          onTickRef.current?.({
            pad: padNow,
            command: "",
            skipped: true,
            evalResult,
            preview,
          })
          scheduleNext()
          return
        }
        if (!webSerial.getStatus().connected) {
          const opened = await webSerial.tryOpen({
            baudRate: Number(baudRateRef.current) || 115200,
          })
          if (!opened) {
            if (!serialHintShownRef.current) {
              serialHintShownRef.current = true
              onErrorRef.current?.("串口未连接：请先在顶栏「选择串口」并「打开串口」")
            }
            scheduleNext()
            return
          }
        }
        const result = await sendMouthFiveBarPreview(
          preview,
          cal.sendMode || "separate-write",
          (cmd) => webSerial.writeText(cmd)
        )
        if (result.ok) {
          onTickRef.current?.({
            pad: padNow,
            command: result.command,
            skipped: false,
            evalResult,
            preview: { ...preview, sentCommand: result.command },
          })
        } else {
          onErrorRef.current?.(result.error)
        }
      } catch (e) {
        onErrorRef.current?.(e?.message || String(e))
      } finally {
        scheduleNext()
      }
    }

    void runOnce()

    return () => {
      runningRef.current = false
      if (timerRef.current != null) {
        window.clearTimeout(timerRef.current)
        timerRef.current = null
      }
    }
  }, [enabled, intervalMs, fiveBarStateRef, sideId])
}
