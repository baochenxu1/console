import { useCallback, useSyncExternalStore } from "react"
import {
  clearLabRecorder,
  getLabRecorderDurationMs,
  getLabRecorderExportPayload,
  getLabRecorderSnapshot,
  stopLabRecorder,
  subscribeLabRecorder,
} from "../kinematics/mouthCornerLabRecorder/index.js"

/**
 * React 订阅层：录制逻辑见 `kinematics/mouthCornerLabRecorder/store.js`。
 */
export function useMouthCornerLabRecorder() {
  const snapshot = useSyncExternalStore(
    subscribeLabRecorder,
    getLabRecorderSnapshot,
    getLabRecorderSnapshot
  )

  const getExportPayload = useCallback(() => getLabRecorderExportPayload(), [])

  const copyExportJson = useCallback(async () => {
    const text = JSON.stringify(getExportPayload(), null, 2)
    await navigator.clipboard.writeText(text)
    return text
  }, [getExportPayload])

  const stopAndExport = useCallback(
    (reason = "用户停止") => {
      const payload = stopLabRecorder(reason, false)
      return payload
    },
    []
  )

  return {
    recording: snapshot.active,
    frameCount: snapshot.frameCount,
    meta: snapshot.meta,
    stopReason: snapshot.stopReason,
    lastError: snapshot.lastError,
    lastSampleAt: snapshot.lastSampleAt,
    lastPushedAt: snapshot.lastPushedAt,
    durationLimitMs: getLabRecorderDurationMs(),
    getExportPayload,
    copyExportJson,
    stopAndExport,
  }
}
