import { useCallback, useEffect, useState } from "react"
import {
  RIGHT_MOUTH_CALIB_STORAGE_KEY,
  createDefaultRightMouthLabCalibration,
  loadRightMouthLabCalibration,
} from "../kinematics/rightMouthFiveBarLab.js"

/**
 * @param {string} [storageKey]
 */
export function useKinematicsLabCalibration(storageKey = RIGHT_MOUTH_CALIB_STORAGE_KEY) {
  const [calibration, setCalibrationState] = useState(() => {
    try {
      const raw = localStorage.getItem(storageKey)
      if (!raw) {
        return createDefaultRightMouthLabCalibration()
      }
      return loadRightMouthLabCalibration(JSON.parse(raw))
    } catch {
      return createDefaultRightMouthLabCalibration()
    }
  })

  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(calibration))
    } catch {
      // ignore quota errors
    }
  }, [calibration, storageKey])

  const setCalibration = useCallback((next) => {
    setCalibrationState((prev) => {
      const patch = typeof next === "function" ? next(prev) : next
      return loadRightMouthLabCalibration({ ...prev, ...patch })
    })
  }, [])

  const resetCalibration = useCallback(() => {
    setCalibrationState(createDefaultRightMouthLabCalibration())
  }, [])

  return { calibration, setCalibration, resetCalibration }
}
