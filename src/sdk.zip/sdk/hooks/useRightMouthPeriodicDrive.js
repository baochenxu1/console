import { useMouthPeriodicDrive } from "./useMouthPeriodicDrive.js"

/** @deprecated 使用 useMouthPeriodicDrive({ sideId: "right", ... }) */
export function useRightMouthPeriodicDrive(args) {
  return useMouthPeriodicDrive({ sideId: "right", ...args })
}
