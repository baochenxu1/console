import RightMouthFiveBarLiveDrivePanel from "./RightMouthFiveBarLiveDrivePanel.jsx"
import { getMouthCornerLabSide } from "../../kinematics/mouthCornerFiveBarLabConfig.js"

function Row({ label, value }) {
  return (
    <div className="kinematics-lab-kv">
      <span className="kinematics-lab-k">{label}</span>
      <span className="kinematics-lab-v">{value}</span>
    </div>
  )
}

/**
 * @param {object} props
 * @param {object} props.calibration
 * @param {(patch: object) => void} props.onCalibrationChange
 * @param {object} [props.preview]
 * @param {boolean} [props.runBusy]
 * @param {() => void} props.onSendCurrent
 * @param {() => void} props.onRunToTarget
 * @param {() => void} props.onStopRun
 * @param {() => void} props.onReturnCenter
 * @param {(servoId: number, pwm: number) => void} props.onDirectServo
 * @param {() => void} props.onStopAllServo
 * @param {boolean} [props.trackingEnabled]
 * @param {(v: boolean) => void} [props.onTrackingEnabledChange]
 * @param {string} [props.trackingWsUrl]
 * @param {(url: string) => void} [props.onTrackingWsUrlChange]
 * @param {object} [props.trackingStatus]
 * @param {{ x: number, y: number } | null} [props.trackingSidePad]
 * @param {import("../../kinematics/mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} [props.sideId]
 */
export default function RightMouthFiveBarSendPanel({
  sideId = "right",
  calibration,
  onCalibrationChange,
  preview,
  runBusy = false,
  onSendCurrent,
  onRunToTarget,
  onStopRun,
  onReturnCenter,
  onDirectServo,
  onStopAllServo,
  trackingEnabled,
  onTrackingEnabledChange,
  trackingWsUrl,
  onTrackingWsUrlChange,
  trackingStatus,
  trackingSidePad,
  trackingSideR,
}) {
  const side = getMouthCornerLabSide(sideId)
  const trackingPad = trackingSidePad ?? trackingSideR
  const sendMode = calibration.sendMode || "separate-write"
  const servoA = preview?.servoAId ?? side.labHwServoA
  const servoB = preview?.servoBId ?? side.labHwServoB

  const cmdPreview =
    sendMode === "separate-write"
      ? (preview?.singleCommands || []).join(" + ") || "—"
      : sendMode === "sequential-string"
        ? preview?.sequentialCommand || "—"
        : preview?.multiBraceCommand || "—"

  return (
    <section className="kinematics-lab-col kinematics-lab-col--send">
      <h3 className="kinematics-lab-col-title">Servo Send</h3>

      <Row label="servoA / B" value={`${servoA} / ${servoB}`} />

      <RightMouthFiveBarLiveDrivePanel
        sideId={sideId}
        calibration={calibration}
        onCalibrationChange={onCalibrationChange}
        trackingEnabled={trackingEnabled}
        onTrackingEnabledChange={onTrackingEnabledChange}
        wsUrl={trackingWsUrl}
        onWsUrlChange={onTrackingWsUrlChange}
        trackingStatus={trackingStatus}
        trackingSidePad={trackingPad}
      />

      <fieldset className="kinematics-lab-fieldset">
        <legend>sendMode</legend>
        {[
          ["separate-write", "separate-write"],
          ["sequential-string", "sequential-string"],
          ["multi-brace", "multi-brace"],
        ].map(([id, label]) => (
          <label key={id} className="kinematics-lab-radio">
            <input
              type="radio"
              name="lab-send-mode"
              checked={sendMode === id}
              onChange={() => onCalibrationChange({ sendMode: id })}
            />
            {label}
          </label>
        ))}
      </fieldset>

      <div className="kinematics-lab-cmd-preview">
        <div className="kinematics-lab-kv">
          <span className="kinematics-lab-k">multiBrace</span>
          <code className="kinematics-lab-code">{preview?.multiBraceCommand || "—"}</code>
        </div>
        <div className="kinematics-lab-kv">
          <span className="kinematics-lab-k">sequential</span>
          <code className="kinematics-lab-code">{preview?.sequentialCommand || "—"}</code>
        </div>
        <div className="kinematics-lab-kv">
          <span className="kinematics-lab-k">single</span>
          <code className="kinematics-lab-code">
            {(preview?.singleCommands || []).join(" | ") || "—"}
          </code>
        </div>
      </div>

      <Row label="canSend" value={preview?.canSend ? "yes" : "no"} />
      {preview?.blockReasons?.length ? (
        <ul className="kinematics-lab-block-list">
          {preview.blockReasons.map((r) => (
            <li key={r}>{r}</li>
          ))}
        </ul>
      ) : null}

      <div className="kinematics-lab-btn-stack">
        <button
          type="button"
          className="btn-primary btn-tiny"
          disabled={!preview?.canSend}
          onClick={onSendCurrent}
        >
          Send Current Target
        </button>
        <button
          type="button"
          className="btn-secondary btn-tiny"
          disabled={runBusy || !preview?.canSend}
          onClick={onRunToTarget}
        >
          Run To Target
        </button>
        <button type="button" className="btn-ghost btn-tiny" disabled={!runBusy} onClick={onStopRun}>
          Stop Run
        </button>
        <button type="button" className="btn-ghost btn-tiny" onClick={onReturnCenter}>
          Return Center
        </button>
        <button type="button" className="btn-ghost btn-tiny" onClick={onStopAllServo}>
          Stop All Servo
        </button>
      </div>

      <div className="kinematics-lab-direct-diag">
        <h4>Direct Servo Diagnostic</h4>
        <div className="kinematics-lab-btn-grid">
          {[1300, 1500, 1700].map((pwm) => (
            <button
              key={`a-${pwm}`}
              type="button"
              className="btn-ghost btn-tiny"
              onClick={() => onDirectServo(side.labHwServoA, pwm)}
            >
              Servo {side.labHwServoA} → {pwm}
            </button>
          ))}
          {[1300, 1500, 1700].map((pwm) => (
            <button
              key={`b-${pwm}`}
              type="button"
              className="btn-ghost btn-tiny"
              onClick={() => onDirectServo(side.labHwServoB, pwm)}
            >
              Servo {side.labHwServoB} → {pwm}
            </button>
          ))}
          <button
            type="button"
            className="btn-ghost btn-tiny"
            onClick={() => {
              onDirectServo(side.labHwServoA, 1500)
              onDirectServo(side.labHwServoB, 1500)
            }}
          >
            Both {side.labHwServoA}/{side.labHwServoB} → 1500
          </button>
        </div>
      </div>
    </section>
  )
}
