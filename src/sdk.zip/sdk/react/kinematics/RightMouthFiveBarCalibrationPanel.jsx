import { clampNumber } from "../../../utils/clamp.js"
import RightMouthFiveBarBaselineStatus from "./RightMouthFiveBarBaselineStatus.jsx"

function fmt2(v) {
  if (v == null || Number.isNaN(Number(v))) {
    return "—"
  }
  return Number(v).toFixed(2)
}

function fmtPt(p) {
  if (!p || !Number.isFinite(p.x) || !Number.isFinite(p.y)) {
    return "—"
  }
  return `${fmt2(p.x)} / ${fmt2(p.y)}`
}

function Row({ label, value }) {
  return (
    <div className="kinematics-lab-kv">
      <span className="kinematics-lab-k">{label}</span>
      <span className="kinematics-lab-v">{value}</span>
    </div>
  )
}

function NumField({ label, value, onChange, min, max, step = 0.1 }) {
  return (
    <label className="kinematics-lab-field">
      <span>{label}</span>
      <input
        type="number"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </label>
  )
}

/**
 * @param {object} props
 * @param {object} props.calibration
 * @param {(patch: object) => void} props.onCalibrationChange
 * @param {object} [props.currentEval]
 * @param {object} [props.preview]
 * @param {object} [props.params]
 * @param {{ x: number, y: number }} props.pad
 * @param {() => void} [props.onSaveRuntimeBaseline]
 * @param {() => void} [props.onExportRuntimeSnapshot]
 * @param {import("../../kinematics/mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} [props.sideId]
 */
export default function RightMouthFiveBarCalibrationPanel({
  sideId = "right",
  calibration,
  onCalibrationChange,
  currentEval,
  preview,
  params,
  pad,
  onSaveRuntimeBaseline,
  onExportRuntimeSnapshot,
}) {
  const set = (key, val) => onCalibrationChange({ [key]: val })

  const uv = (() => {
    if (!params) {
      return { u: "—", v: "—" }
    }
    const cx = Number(params.padXCenter ?? 50)
    const cy = Number(params.padYCenter ?? 50)
    const u = (pad.x - cx) / cx
    const v = (cy - pad.y) / cy
    return { u: fmt2(u), v: fmt2(v) }
  })()

  return (
    <section className="kinematics-lab-col kinematics-lab-col--calibration">
      <h3 className="kinematics-lab-col-title">
        Calibration · {sideId === "left" ? "左" : "右"}嘴角解算
      </h3>

      <div className="kinematics-lab-field-grid">
        <NumField label="Kx" value={calibration.Kx} min={0.1} max={50} onChange={(v) => set("Kx", v)} />
        <NumField label="Ky" value={calibration.Ky} min={0.1} max={50} onChange={(v) => set("Ky", v)} />
        <label className="kinematics-lab-field">
          <span>xSign</span>
          <select
            value={calibration.xSign}
            onChange={(e) => set("xSign", Number(e.target.value))}
          >
            <option value={1}>+1</option>
            <option value={-1}>-1</option>
          </select>
        </label>
        <label className="kinematics-lab-field">
          <span>ySign</span>
          <select
            value={calibration.ySign}
            onChange={(e) => set("ySign", Number(e.target.value))}
          >
            <option value={1}>+1</option>
            <option value={-1}>-1</option>
          </select>
        </label>
        <label className="kinematics-lab-field">
          <span>qSignA</span>
          <select value={calibration.qSignA} onChange={(e) => set("qSignA", Number(e.target.value))}>
            <option value={1}>+1</option>
            <option value={-1}>-1</option>
          </select>
        </label>
        <label className="kinematics-lab-field">
          <span>qSignB</span>
          <select value={calibration.qSignB} onChange={(e) => set("qSignB", Number(e.target.value))}>
            <option value={1}>+1</option>
            <option value={-1}>-1</option>
          </select>
        </label>
        <NumField
          label="qGainA"
          value={calibration.qGainA}
          min={0.01}
          max={4}
          step={0.01}
          onChange={(v) => set("qGainA", v)}
        />
        <NumField
          label="qGainB"
          value={calibration.qGainB}
          min={0.01}
          max={4}
          step={0.01}
          onChange={(v) => set("qGainB", v)}
        />
        <label className="kinematics-lab-field kinematics-lab-field--check">
          <input
            type="checkbox"
            checked={calibration.servoSwap}
            onChange={(e) => set("servoSwap", e.target.checked)}
          />
          <span>servoSwap</span>
        </label>
        <label className="kinematics-lab-field kinematics-lab-field--check">
          <input
            type="checkbox"
            checked={calibration.useProfileServoIds}
            onChange={(e) => set("useProfileServoIds", e.target.checked)}
          />
          <span>使用 Profile 舵机 ID</span>
        </label>
      </div>

      <fieldset className="kinematics-lab-fieldset">
        <legend>outputMode</legend>
        {["static-target", "run-to-target", "stateful-one-step"].map((mode) => (
          <label key={mode} className="kinematics-lab-radio">
            <input
              type="radio"
              name="lab-output-mode"
              checked={calibration.outputMode === mode}
              onChange={() => set("outputMode", mode)}
            />
            {mode}
          </label>
        ))}
      </fieldset>

      <div className="kinematics-lab-field-grid">
        <NumField
          label="T (ms)"
          value={calibration.servoTimeMs}
          min={0}
          max={9999}
          step={1}
          onChange={(v) => set("servoTimeMs", clampNumber(v, 0, 9999))}
        />
        <NumField
          label="runIntervalMs"
          value={calibration.runIntervalMs}
          min={10}
          max={2000}
          step={1}
          onChange={(v) => set("runIntervalMs", clampNumber(v, 10, 2000))}
        />
        <NumField
          label="minVisibleDeltaUs"
          value={calibration.minVisibleDeltaUs}
          min={1}
          max={500}
          step={1}
          onChange={(v) => set("minVisibleDeltaUs", clampNumber(v, 1, 500))}
        />
      </div>

      <div className="kinematics-lab-solve-block">
        <h4>解算结果</h4>
        <Row label="Pad x/y" value={fmtPt(pad)} />
        <Row label="u / v" value={`${uv.u} / ${uv.v}`} />
        <Row
          label="D_raw"
          value={
            currentEval?.DRaw
              ? `[${fmt2(currentEval.DRaw[0])}, ${fmt2(currentEval.DRaw[1])}]`
              : "—"
          }
        />
        <Row
          label="D_safe"
          value={
            currentEval?.DSafe
              ? `[${fmt2(currentEval.DSafe[0])}, ${fmt2(currentEval.DSafe[1])}]`
              : "—"
          }
        />
        <Row label="scale" value={fmt2(currentEval?.scale)} />
        <Row label="rawReachable" value={currentEval?.rawReachable ? "yes" : "no"} />
        <Row
          label="qRaw A/B"
          value={
            currentEval?.qRaw
              ? `${fmt2(currentEval.qRaw.qA_deg)}° / ${fmt2(currentEval.qRaw.qB_deg)}°`
              : "—"
          }
        />
        <Row
          label="qSend A/B"
          value={
            currentEval?.qSend
              ? `${fmt2(currentEval.qSend.qA_deg)}° / ${fmt2(currentEval.qSend.qB_deg)}°`
              : "—"
          }
        />
        <Row
          label="logicalNeutral A/B"
          value={
            preview
              ? `${preview.logicalNeutralA ?? "—"} / ${preview.logicalNeutralB ?? "—"}`
              : "—"
          }
        />
        <Row
          label="logicalPwm A/B"
          value={`${preview?.logicalPwmA ?? currentEval?.logicalPwmA ?? "—"} / ${preview?.logicalPwmB ?? currentEval?.logicalPwmB ?? "—"}`}
        />
        <Row
          label="logicalDelta A/B"
          value={
            preview
              ? `${preview.logicalDeltaA ?? "—"} / ${preview.logicalDeltaB ?? "—"}`
              : "—"
          }
        />
        <Row
          label="actualNeutral A/B"
          value={
            preview
              ? `${preview.actualNeutralA ?? "—"} / ${preview.actualNeutralB ?? "—"}`
              : "—"
          }
        />
        <Row
          label="actualPwm A/B"
          value={`${preview?.actualPwmA ?? currentEval?.actualPwmA ?? "—"} / ${preview?.actualPwmB ?? currentEval?.actualPwmB ?? "—"}`}
        />
        <Row
          label="actualDelta A/B"
          value={
            preview
              ? `${preview.actualDeltaA ?? "—"} / ${preview.actualDeltaB ?? "—"}`
              : "—"
          }
        />
        <Row
          label="visibleMotion"
          value={
            preview?.visibleMotion === true
              ? "yes"
              : preview?.visibleMotion === false
                ? "no"
                : "—"
          }
        />
        <Row label="pad safe" value={fmtPt(currentEval?.padSafe)} />
        <Row label="pad cmd" value={fmtPt(currentEval?.padCmd)} />
        <Row label="message" value={currentEval?.message || "—"} />
      </div>

      <div className="kinematics-lab-runtime-baseline">
        <h4 className="kinematics-lab-subtitle">Runtime Baseline · 正式链路</h4>
        <p className="hint kinematics-lab-baseline-hint">
          保存后 Face Rig / MediaPipe Drive / 关键帧播放将共用同一套 Kx/Ky 与 q 符号校准（localStorage）。
        </p>
        <RightMouthFiveBarBaselineStatus sideId={sideId} />
        <div className="kinematics-lab-baseline-actions">
          <button
            type="button"
            className="btn-primary btn-tiny"
            onClick={onSaveRuntimeBaseline}
            disabled={!onSaveRuntimeBaseline}
          >
            Save Right Mouth Baseline
          </button>
          <button
            type="button"
            className="btn-secondary btn-tiny"
            onClick={onExportRuntimeSnapshot}
            disabled={!onExportRuntimeSnapshot}
          >
            Export Right Mouth Runtime Snapshot
          </button>
        </div>
      </div>
    </section>
  )
}
