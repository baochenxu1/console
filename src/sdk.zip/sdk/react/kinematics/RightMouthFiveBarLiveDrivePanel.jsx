import { clampNumber } from "../../../utils/clamp.js"
import { getMouthCornerLabSide } from "../../kinematics/mouthCornerFiveBarLabConfig.js"

function NumField({ label, value, onChange, min, max, step = 1 }) {
  return (
    <label className="kinematics-lab-field">
      <span>{label}</span>
      <input
        type="number"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </label>
  )
}

/**
 * @param {object} props
 * @param {object} props.calibration
 * @param {(patch: object) => void} props.onCalibrationChange
 * @param {boolean} [props.trackingEnabled]
 * @param {(v: boolean) => void} [props.onTrackingEnabledChange]
 * @param {string} [props.wsUrl]
 * @param {(url: string) => void} [props.onWsUrlChange]
 * @param {object} [props.trackingStatus]
 * @param {{ x: number, y: number } | null} [props.trackingSidePad]
 * @param {import("../../kinematics/mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} [props.sideId]
 */
export default function RightMouthFiveBarLiveDrivePanel({
  sideId = "right",
  calibration,
  onCalibrationChange,
  trackingEnabled = false,
  onTrackingEnabledChange,
  wsUrl = "",
  onWsUrlChange,
  trackingStatus,
  trackingSidePad,
}) {
  const side = getMouthCornerLabSide(sideId)
  const mpKey = side.mediaPipeDriveKey
  const set = (key, val) => onCalibrationChange({ [key]: val })

  const liveOn = Boolean(calibration.livePadDriveEnabled)
  const mpOn = Boolean(calibration[mpKey])

  return (
    <section className="kinematics-lab-live-drive">
      <h4>连续驱动</h4>
      <p className="kinematics-lab-hint">
        固定周期发送当前目标点（默认 40ms），不在每次 mousemove 下发；仅 servoA/B，不写关键帧、不全脸下发。
      </p>

      <label className="kinematics-lab-field kinematics-lab-field--check">
        <input
          type="checkbox"
          checked={liveOn}
          onChange={(e) => {
            const on = e.target.checked
            set("livePadDriveEnabled", on)
            if (on) {
              onCalibrationChange({
                livePadDriveEnabled: true,
                [mpKey]: false,
                mediaPipeRightMouthDriveEnabled: false,
                mediaPipeLeftMouthDriveEnabled: false,
                outputMode: "static-target",
                sendMode: "separate-write",
                useProfileServoIds: true,
              })
            }
          }}
        />
        <span>Enable Live Pad Drive</span>
      </label>

      <label className="kinematics-lab-field kinematics-lab-field--check">
        <input
          type="checkbox"
          checked={mpOn}
          onChange={(e) => {
            const on = e.target.checked
            if (on) {
              onCalibrationChange({
                [mpKey]: true,
                livePadDriveEnabled: false,
                mediaPipeRightMouthDriveEnabled: sideId === "right" ? true : false,
                mediaPipeLeftMouthDriveEnabled: sideId === "left" ? true : false,
                outputMode: "static-target",
                sendMode: "separate-write",
                useProfileServoIds: true,
              })
            } else {
              set(mpKey, false)
            }
          }}
        />
        <span>Enable MediaPipe {side.label} Only</span>
      </label>

      <div className="kinematics-lab-field-grid">
        <NumField
          label="livePadDriveIntervalMs"
          value={calibration.livePadDriveIntervalMs ?? 40}
          min={16}
          max={500}
          onChange={(v) => set("livePadDriveIntervalMs", clampNumber(v, 16, 500))}
        />
        <NumField
          label="servoTimeMs (T)"
          value={calibration.servoTimeMs ?? 40}
          min={0}
          max={9999}
          onChange={(v) => set("servoTimeMs", clampNumber(v, 0, 9999))}
        />
      </div>

      {mpOn ? (
        <div className="kinematics-lab-mp-mini">
          <label className="kinematics-lab-field">
            <span>WS URL</span>
            <input
              type="text"
              value={wsUrl}
              onChange={(e) => onWsUrlChange?.(e.target.value)}
            />
          </label>
          <label className="kinematics-lab-field kinematics-lab-field--check">
            <input
              type="checkbox"
              checked={trackingEnabled}
              onChange={(e) => onTrackingEnabledChange?.(e.target.checked)}
            />
            <span>Tracking WS</span>
          </label>
          <p className="kinematics-lab-hint">
            face: {trackingStatus?.faceDetected ? "yes" : "no"} · fps:{" "}
            {trackingStatus?.fps ?? 0} · {side.rigSideKey}:{" "}
            {trackingSidePad
              ? `${Math.round(trackingSidePad.x)}/${Math.round(trackingSidePad.y)}`
              : "—"}
          </p>
        </div>
      ) : null}

      {liveOn || mpOn ? (
        <p className="kinematics-lab-live-active">
          {liveOn ? "Live Pad Drive 运行中" : `MediaPipe ${side.label} 驱动运行中`} · interval=
          {calibration.livePadDriveIntervalMs ?? 40}ms · static-target · servo{" "}
          {side.labHwServoA}/{side.labHwServoB}
        </p>
      ) : null}
    </section>
  )
}
