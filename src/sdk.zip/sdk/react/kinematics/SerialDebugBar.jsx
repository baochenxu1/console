import { useCallback, useEffect, useRef, useState } from "react"
import { webSerial } from "../../../core/webSerial.js"
import { buildStopAllCommand } from "../../../core/servoProtocol.js"

/**
 * 机构调试台串口条：复用 webSerial 单例。
 *
 * @param {object} props
 * @param {number} [props.baudRate]
 * @param {(rate: number) => void} [props.onBaudRateChange]
 * @param {string} [props.lastCommand]
 * @param {string} [props.lastError]
 * @param {(entry: { type: string, message: string, time: string }) => void} [props.onLog]
 */
export default function SerialDebugBar({
  baudRate = 115200,
  onBaudRateChange,
  lastCommand = "",
  lastError = "",
  onLog,
}) {
  const [status, setStatus] = useState(() => webSerial.getStatus())

  const onLogRef = useRef(onLog)
  onLogRef.current = onLog

  const refresh = useCallback(() => {
    setStatus(webSerial.getStatus())
  }, [])

  useEffect(() => {
    const prev = {
      onStatus: webSerial.onStatus,
      onData: webSerial.onData,
      onLog: webSerial.onLog,
    }
    webSerial.setCallbacks({
      onStatus: (s) => {
        setStatus(s)
        if (typeof prev.onStatus === "function") {
          prev.onStatus(s)
        }
      },
      onData: (text) => {
        onLogRef.current?.({ type: "RX", message: text, time: new Date().toLocaleTimeString() })
        if (typeof prev.onData === "function") {
          prev.onData(text)
        }
      },
      onLog: (log) => {
        onLogRef.current?.({
          type: log.level || "INFO",
          message: log.message,
          time: log.time || new Date().toLocaleTimeString(),
        })
        if (typeof prev.onLog === "function") {
          prev.onLog(log)
        }
      },
    })
    refresh()
    const id = window.setInterval(refresh, 400)
    return () => {
      window.clearInterval(id)
      webSerial.setCallbacks(prev)
    }
  }, [refresh])

  const appendErr = (msg) => {
    onLog?.({ type: "ERROR", message: msg, time: new Date().toLocaleTimeString() })
  }

  const handleSelect = async () => {
    try {
      await webSerial.selectPort()
      refresh()
    } catch (e) {
      appendErr(e?.message || String(e))
    }
  }

  const handleOpen = async () => {
    try {
      const st = webSerial.getStatus()
      await webSerial.open({
        baudRate: Number(baudRate) || 115200,
        requestPortIfNeeded: !st.portSelected,
      })
      refresh()
    } catch (e) {
      appendErr(e?.message || String(e))
    }
  }

  const handleClose = async () => {
    try {
      await webSerial.close()
      refresh()
    } catch (e) {
      appendErr(e?.message || String(e))
    }
  }

  const handleStopAll = async () => {
    try {
      if (!status.connected) {
        const opened = await webSerial.tryOpen({ baudRate: Number(baudRate) || 115200 })
        if (!opened) {
          appendErr("串口未连接：请先选择并打开串口")
          return
        }
      }
      await webSerial.writeText(buildStopAllCommand())
      refresh()
    } catch (e) {
      appendErr(e?.message || String(e))
    }
  }

  return (
    <div className="kinematics-lab-serial-bar">
      <div className="kinematics-lab-serial-status">
        <span>supported: {status.supported ? "yes" : "no"}</span>
        <span>portSelected: {status.portSelected ? "yes" : "no"}</span>
        <span>connected: {status.connected ? "yes" : "no"}</span>
        <span>baud: {status.baudRate}</span>
        <span>tx: {status.txCount}</span>
        <span>rx: {status.rxCount}</span>
        <span className="kinematics-lab-serial-last" title={lastCommand}>
          lastCmd: {lastCommand ? lastCommand.slice(0, 48) : "—"}
          {lastCommand && lastCommand.length > 48 ? "…" : ""}
        </span>
        <span className="kinematics-lab-serial-err" title={lastError}>
          lastErr: {lastError || "—"}
        </span>
      </div>
      <div className="kinematics-lab-serial-actions">
        <label className="kinematics-lab-inline-label">
          波特率
          <input
            type="number"
            min={9600}
            max={921600}
            step={9600}
            value={baudRate}
            onChange={(e) => onBaudRateChange?.(Number(e.target.value) || 115200)}
          />
        </label>
        <button type="button" className="btn-secondary btn-tiny" onClick={handleSelect}>
          选择串口
        </button>
        <button type="button" className="btn-secondary btn-tiny" onClick={handleOpen}>
          打开串口
        </button>
        <button type="button" className="btn-ghost btn-tiny" onClick={handleClose}>
          关闭串口
        </button>
        <button type="button" className="btn-ghost btn-tiny" onClick={handleStopAll}>
          停止全部舵机
        </button>
      </div>
    </div>
  )
}
