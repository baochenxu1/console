import { useState } from "react"
import { exportJsonFile, getDateTimeText } from "../../../utils/fileExport.js"
import { MOUTH_CORNER_LAB_RECORD_DURATION_MS, clearLabRecorder } from "../../kinematics/mouthCornerLabRecorder/index.js"
import { useMouthCornerLabRecorder } from "../../hooks/useMouthCornerLabRecorder.js"

/**
 * 底部嘴角 Lab 会话录制（MediaPipe + FiveBar IK + 舵机预览/下发）。
 */
export default function KinematicsDebugDrawer({
  liveTrackingDebug,
  sideLabel = "嘴角",
  canRecord,
  recordBlockReason = "",
  onStartRecord,
  onStopRecord,
}) {
  const labRecorder = useMouthCornerLabRecorder()
  const {
    recording,
    frameCount,
    stopReason,
    lastError,
    lastSampleAt,
    lastPushedAt,
    getExportPayload,
    copyExportJson,
  } = labRecorder

  const [copyStatus, setCopyStatus] = useState("")
  const [exportStatus, setExportStatus] = useState("")
  const durationSec = MOUTH_CORNER_LAB_RECORD_DURATION_MS / 1000
  const hasFrames = frameCount > 0

  const handleCopy = async () => {
    setCopyStatus("")
    try {
      if (!hasFrames) {
        setCopyStatus("无数据可复制")
        return
      }
      await copyExportJson()
      setCopyStatus(`已复制 ${frameCount} 帧`)
    } catch (e) {
      setCopyStatus(`复制失败：${e?.message || String(e)}`)
    }
  }

  const handleExport = () => {
    setExportStatus("")
    try {
      if (!hasFrames) {
        setExportStatus("无数据可导出")
        return
      }
      const payload = getExportPayload()
      const side = payload?.meta?.sideId || "mouth"
      const n = payload?.frames?.length ?? frameCount
      exportJsonFile(`facedev-mouth-lab-${side}-${getDateTimeText()}.json`, payload)
      setExportStatus(`已导出 ${n} 帧（${durationSec}s 窗口）`)
    } catch (e) {
      setExportStatus(`导出失败：${e?.message || String(e)}`)
    }
  }

  return (
    <aside className="kinematics-lab-drawer">
      <section className="kinematics-lab-mp-json-section">
        <h4 className="kinematics-lab-drawer-title">{sideLabel} · Lab 会话录制</h4>
        <p className="kinematics-lab-hint">
          录制最近 {durationSec} 秒（到时自动停止并导出）：每帧含 MediaPipe 嘴角、Pad、FiveBar IK、舵机命令。
          MediaPipe 驱动须先开 Tracking WS；<code>padSource=fallback-center</code> 表示未收到 Tracking。
        </p>

        <div className="kinematics-lab-mp-recorder-status">
          <span>可录制：{canRecord ? "是" : "否"}</span>
          <span>录制：{recording ? "进行中" : "停止"}</span>
          <span>
            帧数：{frameCount}
            {recording ? ` / 最长 ${durationSec}s` : ""}
          </span>
          {lastSampleAt ? (
            <span>采样：{new Date(lastSampleAt).toLocaleTimeString()}</span>
          ) : null}
          {lastPushedAt ? <span>末帧：{new Date(lastPushedAt).toLocaleTimeString()}</span> : null}
          {stopReason ? <span className="kinematics-lab-warn">{stopReason}</span> : null}
          {lastError ? <span className="kinematics-lab-warn">采样错误：{lastError}</span> : null}
          {!canRecord && recordBlockReason ? (
            <span className="kinematics-lab-warn">{recordBlockReason}</span>
          ) : null}
        </div>

        <div className="kinematics-lab-btn-stack">
          <button
            type="button"
            className="btn-primary btn-tiny"
            disabled={!canRecord || recording}
            onClick={onStartRecord}
          >
            录制 {durationSec}s
          </button>
          <button
            type="button"
            className="btn-secondary btn-tiny"
            disabled={!recording}
            onClick={onStopRecord}
          >
            停止并导出
          </button>
          <button type="button" className="btn-ghost btn-tiny" disabled={recording} onClick={clearLabRecorder}>
            清空
          </button>
          <button type="button" className="btn-ghost btn-tiny" disabled={!hasFrames} onClick={handleCopy}>
            复制 JSON
          </button>
          <button type="button" className="btn-ghost btn-tiny" disabled={!hasFrames} onClick={handleExport}>
            导出 JSON
          </button>
        </div>

        {copyStatus ? <p className="kinematics-lab-status">{copyStatus}</p> : null}
        {exportStatus ? <p className="kinematics-lab-status">{exportStatus}</p> : null}

        <p className="kinematics-lab-json-label">当前帧（实时）</p>
        <pre className="kinematics-lab-json kinematics-lab-json--live">
          {liveTrackingDebug ? JSON.stringify(liveTrackingDebug, null, 2) : "请先开启 Tracking WS 或连续驱动。"}
        </pre>
      </section>
    </aside>
  )
}
