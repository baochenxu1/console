import { useCallback, useRef } from "react"
import { clampNumber } from "../../../utils/clamp.js"
import { attachDragSession, tryCapturePointer } from "../../../hooks/useFaceRigInteraction.js"
import RightMouthFiveBarReachabilityOverlay from "../RightMouthFiveBarReachabilityOverlay.jsx"
import { getMouthCornerLabSide } from "../../kinematics/mouthCornerFiveBarLabConfig.js"

/** @type {{ id: string, label: string, x: number, y: number }[]} */
const PAD_PRESETS = [
  { id: "center", label: "Center 50/50", x: 50, y: 50 },
  { id: "px", label: "+X 60/50", x: 60, y: 50 },
  { id: "mx", label: "-X 40/50", x: 40, y: 50 },
  { id: "py", label: "+Y 50/40", x: 50, y: 40 },
  { id: "my", label: "-Y 50/60", x: 50, y: 60 },
  { id: "ru", label: "Right-Up 60/40", x: 60, y: 40 },
  { id: "rd", label: "Right-Down 60/60", x: 60, y: 60 },
]

function pickPadClientXY(ev, rect) {
  let cx = ev.clientX
  let cy = ev.clientY
  if (typeof cx !== "number" || typeof cy !== "number") {
    const t = ev.touches?.[0] ?? ev.changedTouches?.[0]
    if (t) {
      cx = t.clientX
      cy = t.clientY
    }
  }
  if (typeof cx !== "number" || typeof cy !== "number") {
    return null
  }
  const x = clampNumber(((cx - rect.left) / rect.width) * 100, 0, 100)
  const y = clampNumber(((cy - rect.top) / rect.height) * 100, 0, 100)
  return { x, y }
}

/**
 * @param {object} props
 * @param {{ x: number, y: number }} props.pad
 * @param {{ x: number, y: number }} [props.cursorPad] MediaPipe 等：仅移动光标，不触发 pad 状态风暴
 * @param {(pad: { x: number, y: number }) => void} props.onPadChange
 * @param {object} [props.reachabilityMap]
 * @param {object} [props.currentEval]
 * @param {import("../../kinematics/mouthCornerFiveBarLabConfig.js").MouthCornerLabSideId | string} [props.sideId]
 */
export default function RightMouthFiveBarWorkspace({
  sideId = "right",
  pad,
  cursorPad,
  onPadChange,
  reachabilityMap,
  currentEval,
}) {
  const cursor = cursorPad ?? pad
  const padRef = useRef(null)

  const startPadDrag = useCallback(
    (ev) => {
      const el = padRef.current
      if (!el) {
        return
      }
      tryCapturePointer(ev, el)
      const move = (e) => {
        const rect = el.getBoundingClientRect()
        const pt = pickPadClientXY(e, rect)
        if (pt) {
          onPadChange(pt)
        }
      }
      const rect0 = el.getBoundingClientRect()
      const pt0 = pickPadClientXY(ev, rect0)
      if (pt0) {
        onPadChange(pt0)
      }
      attachDragSession({ onMove: move, onEnd: () => {} })
    },
    [onPadChange]
  )

  const side = getMouthCornerLabSide(sideId)

  return (
    <section className="kinematics-lab-col kinematics-lab-col--workspace">
      <h3 className="kinematics-lab-col-title">
        Workspace · {side.label} Pad ({side.rigSideKey})
      </h3>
      <p className="kinematics-lab-hint">
        拖动设定目标点；叠加层显示可达区、raw / safe / cmd 点。
      </p>
      <div className="kinematics-lab-pad-wrap">
        <div
          ref={padRef}
          role="presentation"
          className="face-rig-corner-pad face-rig-mouth-corner-pad face-rig-mouth-corner-pad--fivebar-debug kinematics-lab-pad"
          onPointerDown={startPadDrag}
        >
          {reachabilityMap ? (
            <RightMouthFiveBarReachabilityOverlay
              reachabilityMap={reachabilityMap}
              currentEval={currentEval}
            />
          ) : null}
          <div
            className="face-rig-corner-cursor"
            style={{ left: `${cursor.x}%`, top: `${cursor.y}%` }}
          />
          <div className="face-rig-corner-label face-rig-corner-label-r">右嘴角</div>
        </div>
        <div className="kinematics-lab-pad-readout">
          <span>Pad x: {Math.round(pad.x)}</span>
          <span>Pad y: {Math.round(pad.y)}</span>
        </div>
      </div>
      <div className="kinematics-lab-preset-grid">
        {PAD_PRESETS.map((p) => (
          <button
            key={p.id}
            type="button"
            className="btn-ghost btn-tiny"
            onClick={() => onPadChange({ x: p.x, y: p.y })}
          >
            {p.label}
          </button>
        ))}
      </div>
    </section>
  )
}
