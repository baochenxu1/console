import { useRightMouthFiveBarRuntime } from "../../hooks/useRightMouthFiveBarRuntime.js"
import { useLeftMouthFiveBarRuntime } from "../../hooks/useLeftMouthFiveBarRuntime.js"
import { reloadRightMouthRuntimeBaseline } from "../../kinematics/rightMouthFiveBarRuntime.js"
import { reloadLeftMouthRuntimeBaseline } from "../../kinematics/leftMouthFiveBarRuntime.js"
import { getMouthCornerLabSide } from "../../kinematics/mouthCornerFiveBarLabConfig.js"

function fmt(v) {
  if (v == null || Number.isNaN(Number(v))) {
    return "—"
  }
  return String(v)
}

/**
 * Right Mouth runtime baseline 状态条（Lab / 表情编排共用）。
 */
export default function RightMouthFiveBarBaselineStatus({ sideId = "right", compact = false }) {
  const side = getMouthCornerLabSide(sideId)
  const rightRt = useRightMouthFiveBarRuntime()
  const leftRt = useLeftMouthFiveBarRuntime()
  const { runtime, reload } = sideId === "left" ? leftRt : rightRt

  const handleReload = () => {
    if (sideId === "left") {
      reloadLeftMouthRuntimeBaseline()
    } else {
      reloadRightMouthRuntimeBaseline()
    }
    reload()
  }

  return (
    <div className={`kinematics-lab-baseline-status${compact ? " kinematics-lab-baseline-status--compact" : ""}`}>
      <h4 className="kinematics-lab-subtitle">Right Mouth Runtime Baseline</h4>
      <ul className="kinematics-lab-baseline-status-list">
        <li>loaded: {runtime.loaded ? "true" : "false"}</li>
        <li>source: {runtime.source}</li>
        <li>version: {fmt(runtime.version)}</li>
        <li>
          Kx / Ky: {fmt(runtime.params?.Kx)} / {fmt(runtime.params?.Ky)}
        </li>
        <li>savedAt: {runtime.savedAt || "—"}</li>
        <li>
          servoA / servoB: {fmt(runtime.servoAId)} / {fmt(runtime.servoBId)}
        </li>
      </ul>
      <button type="button" className="btn-secondary btn-tiny" onClick={handleReload}>
        Reload Right Mouth Baseline
      </button>
    </div>
  )
}
