import FaceRigControlConsole from "../../components/FaceRigControlConsole.jsx"
import FaceRigWorkspace from "../../components/FaceRigWorkspace.jsx"

/**
 * SDK 包装的面部控件（不含绑定检视）。
 * - workspace：整脸示意图（绑定页）
 * - console：左右分区控制台（表情编排页）
 */
export default function FaceRigControls({
  variant = "workspace",
  rigState,
  onRigStateChange,
  setSelectedControlId,
  selectedControlId,
  draggingControlId,
  padLRef,
  padRRef,
  startVerticalScrub,
  startRadar,
  startCorner,
  radarCxPx,
  radarCyPx,
  jawPx,
  showFiveBarReachabilityOverlay = false,
  rightMouthPadReachabilityMap = null,
  rightMouthPadEval = null,
}) {
  if (variant === "console") {
    return (
      <FaceRigControlConsole
        rig={rigState}
        setRig={onRigStateChange}
        setSelectedControlId={setSelectedControlId}
        selectedControlId={selectedControlId}
        draggingControlId={draggingControlId}
        padLRef={padLRef}
        padRRef={padRRef}
        startVerticalScrub={startVerticalScrub}
        startRadar={startRadar}
        startCorner={startCorner}
        radarCxPx={radarCxPx}
        radarCyPx={radarCyPx}
        jawPx={jawPx}
        showFiveBarReachabilityOverlay={showFiveBarReachabilityOverlay}
        rightMouthPadReachabilityMap={rightMouthPadReachabilityMap}
        rightMouthPadEval={rightMouthPadEval}
      />
    )
  }

  return (
    <FaceRigWorkspace
      rig={rigState}
      setRig={onRigStateChange}
      setSelectedControlId={setSelectedControlId}
      padLRef={padLRef}
      padRRef={padRRef}
      startVerticalScrub={startVerticalScrub}
      startRadar={startRadar}
      startCorner={startCorner}
      radarCxPx={radarCxPx}
      radarCyPx={radarCyPx}
      jawPx={jawPx}
      showFiveBarReachabilityOverlay={showFiveBarReachabilityOverlay}
      rightMouthPadReachabilityMap={rightMouthPadReachabilityMap}
      rightMouthPadEval={rightMouthPadEval}
    />
  )
}
