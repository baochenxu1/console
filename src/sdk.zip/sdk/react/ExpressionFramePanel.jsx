/** 表情编排侧栏：当前帧 / 工程 / 诊断（与原版页面行为一致）。 */
export default function ExpressionFramePanel({
  sideTab,
  setSideTab,
  mergeHint,
  hasUnsavedRigPose,
  rig,
  keyframes,
  selectedKeyframe,
  selectedFrameIndex,
  keyframeDurationDraft,
  setKeyframeDurationDraft,
  updateSelectedKeyframeMeta,
  handleWriteCurrentKeyframe,
  handleSaveNewKeyframe,
  handleApplyRigToPoseOnly,
  handleApplyRigToPoseAndPush,
  currentControlInspect,
  handleAddKeyframe,
  handleCopyKeyframe,
  handleInsertKeyframe,
  handleMoveKeyframe,
  handleDeleteKeyframe,
  defaultDurationMs,
  setDefaultDurationMs,
  handleNewExpression,
  handleSaveProject,
  handleLoadProject,
  handleExportProject,
  handleProjectImportFile,
  projectFileInputRef,
}) {
  return (
    <aside className="face-expression-side" aria-label="属性与工程">
      <div className="face-expression-tabs" role="tablist">
        <button
          type="button"
          role="tab"
          aria-selected={sideTab === "frame"}
          className={sideTab === "frame" ? "active" : ""}
          onClick={() => setSideTab("frame")}
        >
          当前帧
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={sideTab === "project"}
          className={sideTab === "project" ? "active" : ""}
          onClick={() => setSideTab("project")}
        >
          动作工程
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={sideTab === "diag"}
          className={sideTab === "diag" ? "active" : ""}
          onClick={() => setSideTab("diag")}
        >
          输出诊断
        </button>
      </div>

      <div className="face-expression-side-body">
        {sideTab !== "frame" && mergeHint ? (
          <p className="hint face-expression-merge-hint">{mergeHint}</p>
        ) : null}

        {sideTab === "frame" ? (
          <div className="face-expression-tab-panel face-expression-tab-frame" role="tabpanel">
            {hasUnsavedRigPose ? (
              <div className="face-expression-unsaved-banner" role="status">
                当前 Face Rig 姿态尚未写入关键帧
              </div>
            ) : null}

            {selectedKeyframe ? (
              <>
                <div className="form-row">
                  <label>名称</label>
                  <input
                    value={selectedKeyframe.name}
                    onChange={(e) => updateSelectedKeyframeMeta({ name: e.target.value })}
                  />
                </div>
                <div className="form-row">
                  <label>时长 ms</label>
                  <input
                    type="number"
                    min={20}
                    value={
                      keyframeDurationDraft !== null
                        ? keyframeDurationDraft
                        : String(selectedKeyframe.durationMs)
                    }
                    onFocus={() => setKeyframeDurationDraft(String(selectedKeyframe.durationMs))}
                    onChange={(e) => setKeyframeDurationDraft(e.target.value)}
                    onBlur={() => {
                      if (keyframeDurationDraft === null) return
                      const raw = keyframeDurationDraft.trim()
                      setKeyframeDurationDraft(null)
                      if (raw === "") {
                        return
                      }
                      const n = Number.parseInt(raw, 10)
                      if (Number.isNaN(n)) {
                        return
                      }
                      updateSelectedKeyframeMeta({ durationMs: Math.max(20, n) })
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.currentTarget.blur()
                      }
                    }}
                  />
                </div>

                <button
                  type="button"
                  className="btn-primary face-expression-btn-write-kf"
                  onClick={handleWriteCurrentKeyframe}
                >
                  写入当前关键帧
                </button>

                <div className="face-expression-secondary-grid">
                  <button type="button" className="btn-secondary-full" onClick={handleSaveNewKeyframe}>
                    保存为新关键帧
                  </button>
                  <button type="button" className="btn-secondary-full" onClick={handleApplyRigToPoseOnly}>
                    应用到当前姿态
                  </button>
                  <button type="button" className="btn-secondary-full" onClick={handleApplyRigToPoseAndPush}>
                    应用并下发
                  </button>
                </div>
              </>
            ) : (
              <p className="hint face-expression-pick-kf-hint">请在下方时间轴选择关键帧。</p>
            )}

            {mergeHint ? <p className="hint face-expression-merge-hint">{mergeHint}</p> : null}

            <details className="face-expression-details">
              <summary>当前控件状态</summary>
              <div className="face-expression-details-body">
                {currentControlInspect ? (
                  <dl className="face-expression-inspect-dl">
                    <div className="face-expression-inspect-row">
                      <dt>控件名称</dt>
                      <dd>{currentControlInspect.label}</dd>
                    </div>
                    <div className="face-expression-inspect-row">
                      <dt>控件通道</dt>
                      <dd>
                        <code className="face-expression-code">{currentControlInspect.channelTag}</code>
                      </dd>
                    </div>
                    <div className="face-expression-inspect-row">
                      <dt>控件值</dt>
                      <dd className="face-expression-inspect-value">{currentControlInspect.valueText}</dd>
                    </div>
                    <div className="face-expression-inspect-row">
                      <dt>输出路数</dt>
                      <dd>{currentControlInspect.outputPathCount}</dd>
                    </div>
                    <div className="face-expression-inspect-row">
                      <dt>舵机 ID</dt>
                      <dd>
                        {currentControlInspect.servoIds.length
                          ? currentControlInspect.servoIds.join(", ")
                          : "—"}
                      </dd>
                    </div>
                  </dl>
                ) : (
                  <p className="hint face-expression-no-control">未选择控件</p>
                )}
              </div>
            </details>

            <details className="face-expression-details" open>
              <summary>关键帧管理</summary>
              <div className="face-expression-details-body">
                <div className="face-expression-kf-manage-grid">
                  <button type="button" className="btn-secondary-full" onClick={handleAddKeyframe}>
                    新增关键帧
                  </button>
                  <button
                    type="button"
                    className="btn-secondary-full"
                    onClick={handleCopyKeyframe}
                    disabled={!selectedKeyframe}
                  >
                    复制当前帧
                  </button>
                  <button type="button" className="btn-ghost btn-compact" onClick={() => handleInsertKeyframe(0)}>
                    插入前
                  </button>
                  <button type="button" className="btn-ghost btn-compact" onClick={() => handleInsertKeyframe(1)}>
                    插入后
                  </button>
                  <button
                    type="button"
                    className="btn-ghost btn-compact"
                    onClick={() => handleMoveKeyframe(-1)}
                    disabled={selectedFrameIndex <= 0}
                  >
                    上移
                  </button>
                  <button
                    type="button"
                    className="btn-ghost btn-compact"
                    onClick={() => handleMoveKeyframe(1)}
                    disabled={selectedFrameIndex >= keyframes.length - 1}
                  >
                    下移
                  </button>
                </div>
                <button
                  type="button"
                  className="danger btn-danger-full"
                  onClick={handleDeleteKeyframe}
                  disabled={!selectedKeyframe}
                >
                  删除当前关键帧
                </button>
              </div>
            </details>
          </div>
        ) : null}

        {sideTab === "project" ? (
          <div className="face-expression-tab-panel" role="tabpanel">
            <div className="form-row">
              <label>新建关键帧默认时长 ms</label>
              <input
                type="number"
                min={20}
                value={defaultDurationMs}
                onChange={(e) => {
                  const n = Number.parseInt(e.target.value, 10)
                  if (!Number.isNaN(n)) setDefaultDurationMs(Math.max(20, n))
                }}
              />
            </div>
            <div className="button-row button-row-expression">
              <button type="button" className="btn-secondary-full" onClick={handleNewExpression}>
                新建
              </button>
              <button type="button" className="btn-secondary-full" onClick={handleSaveProject}>
                保存
              </button>
              <button type="button" className="btn-secondary-full" onClick={handleLoadProject}>
                加载
              </button>
              <button
                type="button"
                className="btn-secondary-full"
                onClick={() => projectFileInputRef.current?.click()}
              >
                导入
              </button>
              <button type="button" className="btn-secondary-full" onClick={handleExportProject}>
                导出
              </button>
            </div>
            <input
              ref={projectFileInputRef}
              type="file"
              accept="application/json,.json"
              style={{ display: "none" }}
              onChange={handleProjectImportFile}
            />
          </div>
        ) : null}

        {sideTab === "diag" ? (
          <div className="face-expression-tab-panel face-expression-diag-tab" role="tabpanel">
            <details className="face-rig-diag-block">
              <summary>warnings（{rig.warnings.length}）</summary>
              {rig.warnings.length === 0 ? (
                <p className="hint muted">无</p>
              ) : (
                <ul className="face-rig-warnings">
                  {rig.warnings.map((w, i) => (
                    <li key={i}>{w}</li>
                  ))}
                </ul>
              )}
            </details>
            <details className="face-rig-diag-block">
              <summary>logicalPose</summary>
              <pre className="face-rig-diag-json">{JSON.stringify(rig.logicalPose, null, 2)}</pre>
            </details>
            <details className="face-rig-diag-block">
              <summary>actualPose</summary>
              <pre className="face-rig-diag-json">{JSON.stringify(rig.actualPose, null, 2)}</pre>
            </details>
            <details className="face-rig-diag-block">
              <summary>contributions</summary>
              <pre className="face-rig-diag-json">{JSON.stringify(rig.contributions, null, 2)}</pre>
            </details>
          </div>
        ) : null}
      </div>
    </aside>
  )
}
