import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { normalizeFaceRigProfile } from "../../core/faceRigProfile.js"
import {
  SERVO_LOGICAL_MAX_PWM,
  SERVO_LOGICAL_MIN_PWM,
  STANDARD_CENTER_PWM,
  getServoConfig,
  logicalToActualPwm,
} from "../../core/servoConfig.js"
import {
  buildMultiServoMoveCommand,
  buildServoMoveCommand,
  buildStopAllCommand,
} from "../../core/servoProtocol.js"
import { webSerial } from "../../core/webSerial.js"
import { clampNumber } from "../../utils/clamp.js"
import {
  angleToBindingLogicalPwm,
  createRightMouthCornerFivebarState,
  resetRightMouthCornerFivebarState,
  resolveRightMouthCornerFivebar,
} from "../kinematics/mouthCornerFivebar.js"
import { resolveRightMouthCornerKinematics } from "../kinematics/mouthCornerKinematics.js"

/** 仅测试区：static 解析用小幅步进（仅影响诊断中的 qCmd）；stateful 调试用大步进+无滤波延迟 */
const FIXED_SERVO_TEST_IK_TRIM = {
  maxStepDeg: 1.0,
  filterAlpha: 0.25,
}

const SERVO_TEST_STATEFUL_IK_TRIM = {
  maxStepDeg: 90,
  filterAlpha: 1.0,
}

const TEST_DEFAULT_KX = 7
const TEST_DEFAULT_KY = 7
const TEST_DEFAULT_SERVO_TIME_MS = 50
const TEST_DEFAULT_MIN_VISIBLE_DELTA_US = 1
const TEST_DEFAULT_RUN_INTERVAL_MS = 30
const RUN_TO_TARGET_MAX_FRAMES = 20
const RUN_TO_TARGET_CONVERGE_DEG = 0.5
/** 直发诊断固定时长（与验收示例 T0500 一致） */
const DIRECT_DIAG_TIME_MS = 500
const SCALE_MIN_SEND = 0.8

/**
 * 样机右嘴角 FiveBar 在总线上的物理序号（与仓库默认 profile 里 mouth_corner_r→20/21 不一致时，测试区默认改发这两路）。
 */
const FIVEBAR_HW_SERVO_A = 6
const FIVEBAR_HW_SERVO_B = 7

/** 首版禁止直达 Pad 极限角点（避免误触大行程） */
function isForbiddenExtremePad(sideR) {
  const x = Number(sideR?.x)
  const y = Number(sideR?.y)
  if (!Number.isFinite(x) || !Number.isFinite(y)) {
    return false
  }
  if (x === 0 && y === 0) {
    return true
  }
  if (x === 100 && y === 100) {
    return true
  }
  return false
}

/** @type {{ id: string, label: string, x: number, y: number, resetQPrev?: boolean, dangerousConfirm?: boolean }[]} */
const SERVO_TEST_PRESETS = [
  { id: "send-center", label: "Send Center 50/50", x: 50, y: 50, resetQPrev: true },
  { id: "send-small-right", label: "Send Small Right 53/50", x: 53, y: 50 },
  { id: "send-small-left", label: "Send Small Left 47/50", x: 47, y: 50 },
  { id: "send-small-up", label: "Send Small Up 50/47", x: 50, y: 47 },
  { id: "send-small-down", label: "Send Small Down 50/53", x: 50, y: 53 },
  { id: "medium-r-65", label: "Send Medium Right 65/50", x: 65, y: 50 },
  { id: "medium-l-35", label: "Send Medium Left 35/50", x: 35, y: 50 },
  { id: "medium-u-35", label: "Send Medium Up 50/35", x: 50, y: 35 },
  { id: "medium-d-65", label: "Send Medium Down 50/65", x: 50, y: 65 },
  { id: "medium-ru-6540", label: "Send Medium Right-Up 65/40", x: 65, y: 40 },
  {
    id: "large-lu-00",
    label: "Send Large Left-Up 0/0",
    x: 0,
    y: 0,
    dangerousConfirm: true,
  },
  { id: "return-center", label: "Return Center", x: 50, y: 50, resetQPrev: true },
]

function fmt2(v) {
  if (v === null || v === undefined || Number.isNaN(Number(v))) {
    return "—"
  }
  return Number(v).toFixed(2)
}

function fmtInt(v) {
  if (v === null || v === undefined || Number.isNaN(Number(v))) {
    return "—"
  }
  return String(Math.round(Number(v)))
}

function DiagRow({ label, value }) {
  return (
    <div className="sdk-fivebar-test-row">
      <span className="sdk-fivebar-test-k">{label}</span>
      <span className="sdk-fivebar-test-v">{value}</span>
    </div>
  )
}

function delay(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms))
}

function mergeTestParams(baseParams, servoTimeMs, kx, ky, resolveMode = "static-target") {
  const t = clampNumber(Number(servoTimeMs) || TEST_DEFAULT_SERVO_TIME_MS, 0, 9999)
  const Kx = clampNumber(Number(kx) || TEST_DEFAULT_KX, 0.1, 50)
  const Ky = clampNumber(Number(ky) || TEST_DEFAULT_KY, 0.1, 50)
  const trim = resolveMode === "stateful-one-step" ? SERVO_TEST_STATEFUL_IK_TRIM : FIXED_SERVO_TEST_IK_TRIM
  return {
    ...baseParams,
    maxStepDeg: trim.maxStepDeg,
    filterAlpha: trim.filterAlpha,
    Kx,
    Ky,
    _servoTimeMs: t,
  }
}

/**
 * @param {ReturnType<typeof resolveRightMouthCornerKinematics>} resolved
 * @param {{ x: number, y: number }} sideR
 * @param {number} servoTimeMs
 * @param {ReturnType<typeof createRightMouthCornerFivebarState>} stateRef
 * @param {"static-target" | "stateful-one-step"} resolveMode  static：恢复 qPrev，不累积滤波状态
 */
function runServoTestResolve(resolved, sideR, servoTimeMs, stateRef, kx, ky, resolveMode = "static-target") {
  const st = stateRef.current
  const restoreStatic = resolveMode === "static-target"
  const qPrevBackup = restoreStatic ? [st.qPrev[0], st.qPrev[1]] : null
  const params = mergeTestParams(resolved.params, servoTimeMs, kx, ky, resolveMode)
  const { _servoTimeMs: timeClamped, ...ikParams } = params
  const result = resolveRightMouthCornerFivebar({
    resolved: {
      bindingA: resolved.bindingA,
      bindingB: resolved.bindingB,
      servoAId: resolved.servoAId,
      servoBId: resolved.servoBId,
    },
    sideR,
    params: ikParams,
    state: st,
  })
  if (restoreStatic && qPrevBackup) {
    st.qPrev[0] = qPrevBackup[0]
    st.qPrev[1] = qPrevBackup[1]
  }
  return { ...result, _servoTimeMs: timeClamped }
}

/**
 * @param {object} args
 * @param {ReturnType<typeof runServoTestResolve>} args.ikResult
 * @param {object[]} args.configs
 * @param {number} args.commandServoAId  协议下发的 A 路 id（可与 profile 绑定 id 不同）
 * @param {number} args.commandServoBId
 * @param {object} [args.bindingA]
 * @param {object} [args.bindingB]
 * @param {number} [args.minVisibleDeltaUs]
 * @param {boolean} [args.allowExtremePad]
 * @param {"static-target" | "stateful-one-step" | "run-to-target"} [args.fiveBarOutputModeUi]
 */
function buildServoTestPreview({
  ikResult,
  configs,
  commandServoAId,
  commandServoBId,
  bindingA,
  bindingB,
  minVisibleDeltaUs = TEST_DEFAULT_MIN_VISIBLE_DELTA_US,
  allowExtremePad = false,
  fiveBarOutputModeUi = "static-target",
}) {
  const d = ikResult.diagnostics
  const profileServoAId = d?.servoAId
  const profileServoBId = d?.servoBId
  const servoAId = commandServoAId
  const servoBId = commandServoBId
  const timeMs = clampNumber(Number(ikResult._servoTimeMs) || TEST_DEFAULT_SERVO_TIME_MS, 0, 9999)

  const qRawObj = d?.qRaw
  const qCmdObj = d?.qCmd
  /** @type {"static-target" | "stateful-one-step"} */
  const qSendMode = fiveBarOutputModeUi === "run-to-target" ? "stateful-one-step" : fiveBarOutputModeUi

  let qSendObj = null
  if (qSendMode === "static-target" && qRawObj) {
    qSendObj = qRawObj
  } else if (qCmdObj) {
    qSendObj = qCmdObj
  }

  let errorA = null
  let errorB = null
  let errorAbsA = null
  let errorAbsB = null
  let estimatedFramesToTarget = null
  if (qSendMode === "stateful-one-step" && qRawObj && qCmdObj) {
    const rawA = Number(qRawObj.qA_deg)
    const rawB = Number(qRawObj.qB_deg)
    const cA = Number(qCmdObj.qA_deg)
    const cB = Number(qCmdObj.qB_deg)
    if (Number.isFinite(rawA) && Number.isFinite(rawB) && Number.isFinite(cA) && Number.isFinite(cB)) {
      errorA = rawA - cA
      errorB = rawB - cB
      errorAbsA = Math.abs(errorA)
      errorAbsB = Math.abs(errorB)
      const maxStep =
        qSendMode === "stateful-one-step"
          ? SERVO_TEST_STATEFUL_IK_TRIM.maxStepDeg
          : FIXED_SERVO_TEST_IK_TRIM.maxStepDeg
      estimatedFramesToTarget = Math.ceil(Math.max(errorAbsA, errorAbsB) / maxStep)
    }
  }

  let logicalPwmA = null
  let logicalPwmB = null
  if (qSendObj && bindingA && bindingB) {
    logicalPwmA = angleToBindingLogicalPwm(qSendObj.qA_deg, bindingA)
    logicalPwmB = angleToBindingLogicalPwm(qSendObj.qB_deg, bindingB)
  }

  const blockReasons = []

  if (d?.sideR && isForbiddenExtremePad(d.sideR) && !allowExtremePad) {
    blockReasons.push("禁止发送 Pad 0/0 或 100/100 极限点（首版）")
  }
  if (!ikResult.ok) {
    blockReasons.push(ikResult.message || "IK 失败（ok=false）")
  }
  if (d?.candidateCount === 0) {
    blockReasons.push("candidateCount=0")
  }
  if (!Number.isFinite(servoAId) || !Number.isFinite(servoBId)) {
    blockReasons.push("命令 servoId 无效（请检查 profile 绑定或样机 6/7 选项）")
  }
  if (d?.scale != null && Number(d.scale) < SCALE_MIN_SEND) {
    blockReasons.push(`scale=${fmt2(d.scale)} < ${SCALE_MIN_SEND}（强提示：已禁止发送）`)
  }
  if (!qSendObj) {
    blockReasons.push("qSend 无效（缺少 qRaw/qCmd）")
  }

  const cfgList = Array.isArray(configs) ? configs : []

  const neutralLogicalA = Number(bindingA?.neutralPwm)
  const neutralLogicalB = Number(bindingB?.neutralPwm)
  const nLogA = Number.isFinite(neutralLogicalA) ? neutralLogicalA : STANDARD_CENTER_PWM
  const nLogB = Number.isFinite(neutralLogicalB) ? neutralLogicalB : STANDARD_CENTER_PWM

  const actualA =
    logicalPwmA != null && Number.isFinite(servoAId)
      ? logicalToActualPwm(logicalPwmA, getServoConfig(cfgList, servoAId))
      : null
  const actualB =
    logicalPwmB != null && Number.isFinite(servoBId)
      ? logicalToActualPwm(logicalPwmB, getServoConfig(cfgList, servoBId))
      : null

  const moves = []
  for (const [label, sid, logical, actual] of [
    ["A", servoAId, logicalPwmA, actualA],
    ["B", servoBId, logicalPwmB, actualB],
  ]) {
    if (logical == null || !Number.isFinite(Number(logical))) {
      blockReasons.push(`logicalPwm${label} 无效`)
      continue
    }
    const lg = Number(logical)
    if (lg < SERVO_LOGICAL_MIN_PWM || lg > SERVO_LOGICAL_MAX_PWM) {
      blockReasons.push(`logicalPwm${label}=${lg} 超出逻辑限位`)
    }
    if (!actual) {
      blockReasons.push(`servo${label} 配置无效`)
      continue
    }
    const cfg = getServoConfig(cfgList, sid)
    if (cfg.enabled === false) {
      blockReasons.push(`舵机 ${sid} 未启用`)
    }
    if (actual.limited) {
      blockReasons.push(`actualPwm（servo ${sid}）超出配置范围或被钳制`)
    }
    moves.push({
      servoId: sid,
      pwm: actual.actualPwm,
      timeMs,
      minPwm: cfg.actualMinPwm,
      maxPwm: cfg.actualMaxPwm,
    })
  }

  let command = ""
  let multiBraceCommand = ""
  let sequentialCommand = ""
  let singleCommands = []
  try {
    if (moves.length === 2 && blockReasons.length === 0) {
      singleCommands = moves.map((move) => buildServoMoveCommand(move))
      multiBraceCommand = buildMultiServoMoveCommand(moves)
      sequentialCommand = singleCommands.join("")
      command = multiBraceCommand
    }
  } catch (e) {
    blockReasons.push(e?.message || "命令构建失败")
  }

  const actAp = actualA?.actualPwm
  const actBp = actualB?.actualPwm

  const neutralActualA =
    Number.isFinite(servoAId) && Number.isFinite(nLogA)
      ? logicalToActualPwm(nLogA, getServoConfig(cfgList, servoAId)).actualPwm
      : null
  const neutralActualB =
    Number.isFinite(servoBId) && Number.isFinite(nLogB)
      ? logicalToActualPwm(nLogB, getServoConfig(cfgList, servoBId)).actualPwm
      : null

  const deltaAFromNeutral =
    actAp != null && neutralActualA != null && Number.isFinite(Number(actAp)) && Number.isFinite(Number(neutralActualA))
      ? Math.round(Number(actAp)) - Math.round(Number(neutralActualA))
      : null
  const deltaBFromNeutral =
    actBp != null && neutralActualB != null && Number.isFinite(Number(actBp)) && Number.isFinite(Number(neutralActualB))
      ? Math.round(Number(actBp)) - Math.round(Number(neutralActualB))
      : null

  const absDeltaA = deltaAFromNeutral != null ? Math.abs(deltaAFromNeutral) : null
  const absDeltaB = deltaBFromNeutral != null ? Math.abs(deltaBFromNeutral) : null

  const minVis = clampNumber(Number(minVisibleDeltaUs) || TEST_DEFAULT_MIN_VISIBLE_DELTA_US, 1, 500)
  const visibleMotion =
    absDeltaA != null && absDeltaB != null ? !(absDeltaA < minVis && absDeltaB < minVis) : null

  return {
    sideR: d?.sideR,
    scale: d?.scale,
    qRaw: qRawObj,
    qCmd: qCmdObj,
    qSend: qSendObj,
    qSendMode,
    fiveBarOutputModeUi,
    errorA,
    errorB,
    errorAbsA,
    errorAbsB,
    estimatedFramesToTarget,
    logicalPwmA,
    logicalPwmB,
    actualPwmA: actAp ?? null,
    actualPwmB: actBp ?? null,
    neutralActualA,
    neutralActualB,
    deltaAFromNeutral,
    deltaBFromNeutral,
    absDeltaA,
    absDeltaB,
    minVisibleDeltaUs: minVis,
    visibleMotion,
    profileServoAId,
    profileServoBId,
    servoAId,
    servoBId,
    command,
    multiBraceCommand,
    sequentialCommand,
    singleCommands,
    canSend: blockReasons.length === 0 && singleCommands.length === 2,
    blockReasons,
    timeMs,
  }
}

/**
 * @param {{ profile: object, configs?: object[] }} props
 */
/** @typedef {"multi-brace" | "sequential-string" | "separate-write"} FiveBarServoSendMode */
/** @typedef {"static-target" | "stateful-one-step" | "run-to-target"} FiveBarOutputModeUi */

function formatCommandLineForSendMode(preview, mode) {
  if (!preview) {
    return "—"
  }
  if (mode === "separate-write" && Array.isArray(preview.singleCommands) && preview.singleCommands.length) {
    return preview.singleCommands.join(" + ")
  }
  if (mode === "sequential-string" && preview.sequentialCommand) {
    return preview.sequentialCommand
  }
  if (mode === "multi-brace" && preview.multiBraceCommand) {
    return preview.multiBraceCommand
  }
  return preview.command || "—"
}

function formatFiveBarSendLog(preview, mode, label) {
  if (!preview) {
    return ""
  }
  const a = preview.servoAId
  const b = preview.servoBId
  const sr = preview.sideR
  const qr = preview.qRaw
  const qc = preview.qCmd
  const qs = preview.qSend
  const cmdLine = formatCommandLineForSendMode(preview, mode)
  const lines = [
    label ? `preset: ${label}` : null,
    sr ? `sideR = ${fmt2(sr.x)}/${fmt2(sr.y)}` : null,
    qr ? `qRaw A/B = ${fmt2(qr.qA_deg)}° / ${fmt2(qr.qB_deg)}°` : null,
    qc ? `qCmd A/B = ${fmt2(qc.qA_deg)}° / ${fmt2(qc.qB_deg)}°` : null,
    qs ? `qSend A/B = ${fmt2(qs.qA_deg)}° / ${fmt2(qs.qB_deg)}°` : null,
    `fiveBarOutputModeUi = ${preview.fiveBarOutputModeUi ?? "—"}；qSendMode = ${preview.qSendMode ?? "—"}`,
    `logicalPwm ${a}/${b} = ${preview.logicalPwmA ?? "—"} / ${preview.logicalPwmB ?? "—"}`,
    `actualPwm ${a}/${b} = ${preview.actualPwmA ?? "—"} / ${preview.actualPwmB ?? "—"}`,
    `neutralActual ${a}/${b} = ${preview.neutralActualA ?? "—"} / ${preview.neutralActualB ?? "—"}`,
    `Δ ${a}/${b} = ${preview.deltaAFromNeutral ?? "—"} / ${preview.deltaBFromNeutral ?? "—"}`,
    `absΔ ${a}/${b} = ${preview.absDeltaA ?? "—"} / ${preview.absDeltaB ?? "—"}`,
    `visibleMotion = ${preview.visibleMotion === true ? "yes" : preview.visibleMotion === false ? "no" : "—"}`,
    `minVisibleDeltaUs = ${preview.minVisibleDeltaUs ?? "—"}`,
    `sendMode = ${mode}`,
    `command = ${cmdLine}`,
  ]
  return lines.filter(Boolean).join("\n")
}

export default function RightMouthFiveBarServoTestPanel({ profile, configs = [] }) {
  const [testKx, setTestKx] = useState(TEST_DEFAULT_KX)
  const [testKy, setTestKy] = useState(TEST_DEFAULT_KY)
  const [servoTimeMs, setServoTimeMs] = useState(TEST_DEFAULT_SERVO_TIME_MS)
  const [minVisibleDeltaUs, setMinVisibleDeltaUs] = useState(TEST_DEFAULT_MIN_VISIBLE_DELTA_US)
  /** 勾选：命令中的 ID 与 profile 绑定一致；不勾选（默认）：固定样机 #6 / #7 */
  const [useProfileServoIds, setUseProfileServoIds] = useState(false)
  /** @type {[FiveBarServoSendMode, function]} */
  const [sendMode, setSendMode] = useState(
    /** @type {FiveBarServoSendMode} */ ("separate-write")
  )
  const [baudRate, setBaudRate] = useState(115200)
  const [sideR, setSideR] = useState({ x: 50, y: 50 })
  const [preview, setPreview] = useState(null)
  const [sendStatus, setSendStatus] = useState("")
  const [serialStatus, setSerialStatus] = useState(() => webSerial.getStatus())
  const [lastCommand, setLastCommand] = useState("")
  const [lastError, setLastError] = useState("")
  const [lastSendMode, setLastSendMode] = useState("")
  const [directDiag, setDirectDiag] = useState(null)
  const [lastFiveBarSendLog, setLastFiveBarSendLog] = useState("")

  /** @type {[FiveBarOutputModeUi, function]} */
  const [fiveBarOutputMode, setFiveBarOutputMode] = useState(
    /** @type {FiveBarOutputModeUi} */ ("static-target")
  )
  const [runIntervalMs, setRunIntervalMs] = useState(TEST_DEFAULT_RUN_INTERVAL_MS)
  const [runToTargetBusy, setRunToTargetBusy] = useState(false)

  const testFivebarStateRef = useRef(createRightMouthCornerFivebarState())
  const resolvedRef = useRef(null)
  const servoTimeMsRef = useRef(servoTimeMs)
  servoTimeMsRef.current = servoTimeMs
  const testKxRef = useRef(testKx)
  testKxRef.current = testKx
  const testKyRef = useRef(testKy)
  testKyRef.current = testKy
  const minVisibleDeltaUsRef = useRef(minVisibleDeltaUs)
  minVisibleDeltaUsRef.current = minVisibleDeltaUs
  const baudRateRef = useRef(baudRate)
  baudRateRef.current = baudRate
  const sendModeRef = useRef(sendMode)
  sendModeRef.current = sendMode
  const fiveBarOutputModeRef = useRef(fiveBarOutputMode)
  fiveBarOutputModeRef.current = fiveBarOutputMode
  const runIntervalMsRef = useRef(TEST_DEFAULT_RUN_INTERVAL_MS)
  runIntervalMsRef.current = runIntervalMs
  const runToTargetRunningRef = useRef(false)
  const runToTargetBusyRef = useRef(false)

  const serialSupported = Boolean(serialStatus.supported)
  const serialConnected = Boolean(serialStatus.connected)

  const refreshSerialUi = useCallback(() => {
    setSerialStatus(webSerial.getStatus())
  }, [])

  const normalizedProfile = useMemo(() => normalizeFaceRigProfile(profile), [profile])
  const resolved = useMemo(
    () => resolveRightMouthCornerKinematics(normalizedProfile),
    [normalizedProfile]
  )
  resolvedRef.current = resolved

  useEffect(() => {
    const tick = () => setSerialStatus(webSerial.getStatus())
    tick()
    const id = window.setInterval(tick, 400)
    return () => window.clearInterval(id)
  }, [])

  const evaluatePreview = useCallback(
    (nextSideR) => {
      const r = resolvedRef.current
      const nx = {
        x: clampNumber(Number(nextSideR.x), 0, 100),
        y: clampNumber(Number(nextSideR.y), 0, 100),
      }
      if (!r?.enabled || !r?.readyForIk) {
        setPreview(null)
        setSideR(nx)
        return null
      }
      const ui = fiveBarOutputModeRef.current
      const resolveMode = ui === "static-target" ? "static-target" : "stateful-one-step"
      const ik = runServoTestResolve(
        r,
        nx,
        servoTimeMsRef.current,
        testFivebarStateRef,
        testKxRef.current,
        testKyRef.current,
        resolveMode
      )
      const useProf = useProfileServoIds
      const cmdA = useProf ? r.servoAId : FIVEBAR_HW_SERVO_A
      const cmdB = useProf ? r.servoBId : FIVEBAR_HW_SERVO_B
      const pv = buildServoTestPreview({
        ikResult: ik,
        configs,
        commandServoAId: cmdA,
        commandServoBId: cmdB,
        bindingA: r.bindingA,
        bindingB: r.bindingB,
        minVisibleDeltaUs: minVisibleDeltaUsRef.current,
        allowExtremePad: false,
        fiveBarOutputModeUi: ui,
      })
      setPreview(pv)
      setSideR(nx)
      return { ik, pv }
    },
    [configs, useProfileServoIds, minVisibleDeltaUs, testKx, testKy, fiveBarOutputMode]
  )

  const ensureSerialOpen = useCallback(async () => {
    const st = webSerial.getStatus()
    if (st.connected) {
      return
    }
    if (!st.portSelected) {
      throw new Error("未选择串口：请先选择并打开串口。")
    }
    await webSerial.open({ baudRate: Number(baudRateRef.current) || 115200 })
  }, [])

  const runDirectCommands = useCallback(
    async ({ commands, targetServoId, targetPwm }) => {
      setLastError("")
      const beforeTx = webSerial.getStatus().txCount
      const expectedAdds = commands.length
      try {
        await ensureSerialOpen()
        refreshSerialUi()
        const connectedNow = webSerial.getStatus().connected
        if (!connectedNow) {
          const msg = "串口未连接，直发已取消"
          setLastError(msg)
          setDirectDiag({
            directCommand: commands.join(" | "),
            sendMode: "separate-write",
            beforeTxCount: beforeTx,
            afterTxCount: webSerial.getStatus().txCount,
            lastError: msg,
            connected: false,
            targetServoId,
            targetPwm,
          })
          setSendStatus(msg)
          return
        }

        for (const cmd of commands) {
          await webSerial.writeText(cmd)
          await delay(20)
        }
        refreshSerialUi()
        const afterTx = webSerial.getStatus().txCount
        const txInc = afterTx - beforeTx
        const txOk = txInc >= expectedAdds
        const txErr = txOk
          ? ""
          : `txCount 未按预期增加（期望至少 +${expectedAdds}，实际 +${txInc}）`
        const singleLine = commands.length === 1 ? commands[0] : commands.join(" | ")
        setLastCommand(singleLine)
        setLastSendMode("separate-write")
        if (txErr) {
          setLastError(txErr)
        }
        setDirectDiag({
          directCommand: singleLine,
          sendMode: "separate-write",
          beforeTxCount: beforeTx,
          afterTxCount: afterTx,
          lastError: txErr || "—",
          connected: webSerial.getStatus().connected,
          targetServoId,
          targetPwm,
        })
        setSendStatus(
          txOk
            ? `直发完成：${singleLine}`
            : `直发已写出但 ${txErr}。若机构仍不动，请核对舵机 ID、接线、电源、波特率是否为控制板要求。`
        )
      } catch (e) {
        const msg = e?.message || String(e)
        refreshSerialUi()
        setLastError(msg)
        setDirectDiag({
          directCommand: commands.join(" | "),
          sendMode: "separate-write",
          beforeTxCount: beforeTx,
          afterTxCount: webSerial.getStatus().txCount,
          lastError: msg,
          connected: webSerial.getStatus().connected,
          targetServoId,
          targetPwm,
        })
        setSendStatus(`直发失败：${msg}`)
      }
    },
    [ensureSerialOpen, refreshSerialUi]
  )

  const sendDirectSingle = useCallback(
    async (servoId, pwm) => {
      const cmd = buildServoMoveCommand({
        servoId,
        pwm,
        timeMs: DIRECT_DIAG_TIME_MS,
      })
      await runDirectCommands({
        commands: [cmd],
        targetServoId: servoId,
        targetPwm: String(pwm),
      })
    },
    [runDirectCommands]
  )

  const sendDirectBothCenter = useCallback(async () => {
    const c6 = buildServoMoveCommand({
      servoId: FIVEBAR_HW_SERVO_A,
      pwm: 1500,
      timeMs: DIRECT_DIAG_TIME_MS,
    })
    const c7 = buildServoMoveCommand({
      servoId: FIVEBAR_HW_SERVO_B,
      pwm: 1500,
      timeMs: DIRECT_DIAG_TIME_MS,
    })
    await runDirectCommands({
      commands: [c6, c7],
      targetServoId: `${FIVEBAR_HW_SERVO_A},${FIVEBAR_HW_SERVO_B}`,
      targetPwm: "1500,1500",
    })
  }, [runDirectCommands])

  const sendPreviewCommand = useCallback(
    async (preview, label) => {
      if (!preview?.canSend) {
        setSendStatus(`禁止发送：${(preview?.blockReasons || ["未知原因"]).join("；")}`)
        return
      }
      setLastError("")
      const mode = sendModeRef.current
      setLastFiveBarSendLog(formatFiveBarSendLog(preview, mode, label))
      const visNote =
        preview.visibleMotion === false
          ? "（提示：visibleMotion=no，机构可能几乎无可见动作）"
          : ""
      try {
        await ensureSerialOpen()
        refreshSerialUi()
        if (!webSerial.getStatus().connected) {
          setSendStatus("串口未连接，发送已取消。")
          setLastError("串口未连接")
          return
        }

        if (mode === "separate-write") {
          for (const cmd of preview.singleCommands) {
            await webSerial.writeText(cmd)
            await delay(10)
          }
          refreshSerialUi()
          const joined = preview.singleCommands.join(" ")
          setLastCommand(joined)
          setLastSendMode(mode)
          setSendStatus(
            label
              ? `已逐条发送：${joined}（${label}）${visNote}`
              : `已逐条发送：${joined}${visNote}`
          )
          return
        }

        if (mode === "sequential-string") {
          await webSerial.writeText(preview.sequentialCommand)
          refreshSerialUi()
          setLastCommand(preview.sequentialCommand)
          setLastSendMode(mode)
          setSendStatus(
            label
              ? `已发送连续命令：${preview.sequentialCommand}（${label}）${visNote}`
              : `已发送连续命令：${preview.sequentialCommand}${visNote}`
          )
          return
        }

        await webSerial.writeText(preview.multiBraceCommand)
        refreshSerialUi()
        setLastCommand(preview.multiBraceCommand)
        setLastSendMode(mode)
        setSendStatus(
          label
            ? `已发送同步命令：${preview.multiBraceCommand}（${label}）${visNote}`
            : `已发送同步命令：${preview.multiBraceCommand}${visNote}`
        )
      } catch (e) {
        const msg = e?.message || String(e)
        refreshSerialUi()
        setLastError(msg)
        setSendStatus(`发送失败：${msg}`)
      }
    },
    [ensureSerialOpen, refreshSerialUi]
  )

  const executeRunToTarget = useCallback(
    async (nx, label) => {
      if (runToTargetBusyRef.current) {
        return
      }
      const r = resolvedRef.current
      if (!r?.enabled || !r?.readyForIk) {
        setSendStatus("五杆未就绪，无法 Run To Target。")
        return
      }
      runToTargetBusyRef.current = true
      setRunToTargetBusy(true)
      runToTargetRunningRef.current = true
      const useProf = useProfileServoIds
      const cmdA = useProf ? r.servoAId : FIVEBAR_HW_SERVO_A
      const cmdB = useProf ? r.servoBId : FIVEBAR_HW_SERVO_B
      try {
        /** @type {"converged" | "stopped" | "blocked" | null} */
        let exitReason = null
        for (let i = 0; i < RUN_TO_TARGET_MAX_FRAMES; i++) {
          if (!runToTargetRunningRef.current) {
            exitReason = "stopped"
            setSendStatus("run-to-target 已停止（用户中断）。")
            break
          }
          const ikResult = runServoTestResolve(
            r,
            nx,
            servoTimeMsRef.current,
            testFivebarStateRef,
            testKxRef.current,
            testKyRef.current,
            "stateful-one-step"
          )
          const preview = buildServoTestPreview({
            ikResult,
            configs,
            commandServoAId: cmdA,
            commandServoBId: cmdB,
            bindingA: r.bindingA,
            bindingB: r.bindingB,
            minVisibleDeltaUs: minVisibleDeltaUsRef.current,
            allowExtremePad: false,
            fiveBarOutputModeUi: "run-to-target",
          })
          setPreview(preview)
          setSideR(nx)
          if (!preview.canSend) {
            exitReason = "blocked"
            setSendStatus(`run-to-target 中止：${preview.blockReasons.join("；")}`)
            break
          }
          const converged =
            preview.errorAbsA != null &&
            preview.errorAbsA < RUN_TO_TARGET_CONVERGE_DEG &&
            preview.errorAbsB != null &&
            preview.errorAbsB < RUN_TO_TARGET_CONVERGE_DEG
          const stepLabel = label ? `${label} #${i + 1}` : `Run To Target #${i + 1}`
          await sendPreviewCommand(preview, stepLabel)
          if (converged) {
            exitReason = "converged"
            setSendStatus(
              `run-to-target 已收敛（|qRaw−qCmd| < ${RUN_TO_TARGET_CONVERGE_DEG}°），步数 ${i + 1}。`
            )
            break
          }
          const ms = clampNumber(Number(runIntervalMsRef.current) || TEST_DEFAULT_RUN_INTERVAL_MS, 20, 500)
          await delay(ms)
        }
        if (exitReason == null) {
          setSendStatus(`run-to-target 已达最大帧数 ${RUN_TO_TARGET_MAX_FRAMES}（未收敛）。`)
        }
      } finally {
        runToTargetRunningRef.current = false
        runToTargetBusyRef.current = false
        setRunToTargetBusy(false)
      }
    },
    [configs, useProfileServoIds, sendPreviewCommand]
  )

  const runPreset = useCallback(
    async (preset) => {
      if (preset.dangerousConfirm) {
        if (
          !window.confirm(
            "「Send Large Left-Up 0/0」为 Pad 极限大行程，可能造成碰撞或超行程。确认仍要计算并发送？"
          )
        ) {
          return
        }
      }
      if (preset.resetQPrev) {
        resetRightMouthCornerFivebarState(testFivebarStateRef.current)
      }
      const r = resolvedRef.current
      const nx = {
        x: clampNumber(Number(preset.x), 0, 100),
        y: clampNumber(Number(preset.y), 0, 100),
      }
      if (!r?.enabled || !r?.readyForIk) {
        setSendStatus("五杆未就绪，无法计算。")
        return
      }
      if (fiveBarOutputModeRef.current === "run-to-target") {
        await executeRunToTarget(nx, preset.label)
        return
      }
      const resolveMode =
        fiveBarOutputModeRef.current === "stateful-one-step" ? "stateful-one-step" : "static-target"
      const ikResult = runServoTestResolve(
        r,
        nx,
        servoTimeMsRef.current,
        testFivebarStateRef,
        testKxRef.current,
        testKyRef.current,
        resolveMode
      )
      const useProf = useProfileServoIds
      const cmdA = useProf ? r.servoAId : FIVEBAR_HW_SERVO_A
      const cmdB = useProf ? r.servoBId : FIVEBAR_HW_SERVO_B
      const preview = buildServoTestPreview({
        ikResult,
        configs,
        commandServoAId: cmdA,
        commandServoBId: cmdB,
        bindingA: r.bindingA,
        bindingB: r.bindingB,
        minVisibleDeltaUs: minVisibleDeltaUsRef.current,
        allowExtremePad: Boolean(preset.dangerousConfirm),
        fiveBarOutputModeUi: fiveBarOutputModeRef.current,
      })
      setPreview(preview)
      setSideR(nx)
      if (!preview.canSend) {
        setSendStatus(`禁止发送：${preview.blockReasons.join("；")}`)
        return
      }
      await sendPreviewCommand(preview, preset.label)
    },
    [configs, useProfileServoIds, sendPreviewCommand, executeRunToTarget]
  )

  const handleRunToTarget = useCallback(() => {
    void executeRunToTarget(
      {
        x: clampNumber(Number(sideR.x), 0, 100),
        y: clampNumber(Number(sideR.y), 0, 100),
      },
      "Run To Target"
    )
  }, [executeRunToTarget, sideR.x, sideR.y])

  const handleStopRunToTarget = useCallback(() => {
    runToTargetRunningRef.current = false
    setSendStatus("已请求停止 run-to-target（当前帧发送完成后结束循环）。")
  }, [])

  const handleStopAllServo = useCallback(async () => {
    if (!window.confirm("Stop All Servo 将按现有协议发送全机停止命令，影响所有舵机。确定？")) {
      return
    }
    setLastError("")
    try {
      await ensureSerialOpen()
      refreshSerialUi()
      if (!webSerial.getStatus().connected) {
        setLastError("串口未连接")
        setSendStatus("串口未连接，Stop All 已取消。")
        return
      }
      const cmd = buildStopAllCommand()
      await webSerial.writeText(cmd)
      refreshSerialUi()
      setLastCommand(cmd)
      setLastSendMode("stop-all")
      setSendStatus(`已发送：${cmd}（Stop All）`)
    } catch (e) {
      const msg = e?.message || String(e)
      refreshSerialUi()
      setLastError(msg)
      setSendStatus(`Stop All 失败：${msg}`)
    }
  }, [ensureSerialOpen, refreshSerialUi])

  const handleSelectSerialPort = useCallback(async () => {
    try {
      await webSerial.selectPort()
      refreshSerialUi()
      setSendStatus("已选择串口，请点击「打开串口」。")
    } catch (e) {
      refreshSerialUi()
      setSendStatus(`选择端口失败：${e?.message || String(e)}`)
    }
  }, [refreshSerialUi])

  const handleOpenSerial = useCallback(async () => {
    try {
      await webSerial.open({ baudRate: Number(baudRate) || 115200 })
      refreshSerialUi()
      const ok = webSerial.getStatus().connected
      setSendStatus(ok ? `串口已打开（${baudRate}），可点击 Send 下发。` : "打开后状态异常，请重试。")
    } catch (e) {
      refreshSerialUi()
      setSendStatus(`打开串口失败：${e?.message || String(e)}`)
    }
  }, [baudRate, refreshSerialUi])

  const handleCloseSerial = useCallback(async () => {
    try {
      await webSerial.close()
      refreshSerialUi()
      setSendStatus("串口已关闭。")
    } catch (e) {
      refreshSerialUi()
      setSendStatus(`关闭串口失败：${e?.message || String(e)}`)
    }
  }, [refreshSerialUi])

  useEffect(() => {
    if (resolved.readyForIk) {
      evaluatePreview(sideR)
    }
  }, [servoTimeMs, resolved.readyForIk, evaluatePreview, testKx, testKy, minVisibleDeltaUs, fiveBarOutputMode])

  useEffect(() => {
    return () => {
      runToTargetRunningRef.current = false
      runToTargetBusyRef.current = false
    }
  }, [])

  const pv = preview
  const qRaw = pv?.qRaw
  const qCmd = pv?.qCmd
  const qSend = pv?.qSend
  const showStatefulErrorRows = pv != null && pv.qSendMode === "stateful-one-step"
  const statefulFramesHint =
    showStatefulErrorRows &&
    pv.estimatedFramesToTarget != null &&
    Number.isFinite(pv.estimatedFramesToTarget)
      ? `当前为单步滤波模式，按估算仍需约 ${pv.estimatedFramesToTarget} 次点击/帧接近当前 Pad 目标（maxStepDeg=${SERVO_TEST_STATEFUL_IK_TRIM.maxStepDeg}°，测试区 stateful 快速参数）。`
      : null
  const pwmAmplitudeHint =
    pv != null &&
    pv.absDeltaA != null &&
    pv.absDeltaB != null &&
    pv.absDeltaA < (pv.minVisibleDeltaUs ?? TEST_DEFAULT_MIN_VISIBLE_DELTA_US) &&
    pv.absDeltaB < (pv.minVisibleDeltaUs ?? TEST_DEFAULT_MIN_VISIBLE_DELTA_US)

  return (
    <div className="sdk-servo-inspector-block sdk-fivebar-servo-test-panel">
      <h4 className="sdk-servo-inspector-subtitle">Right Mouth FiveBar Servo Test</h4>
      <p className="sdk-fivebar-test-hint">
        FiveBar 下发支持 <strong>static-target（默认）</strong>/ stateful / run-to-target；Direct Servo Diagnostic 固定发 <code>#6/#7</code>，T=
        {DIRECT_DIAG_TIME_MS}
        ms，用于排除串口/协议/接线。FiveBar 默认可用 <strong>separate-write</strong>；中等行程见 Medium 按钮。
      </p>

      {!serialSupported ? (
        <p className="sdk-fivebar-test-warn">当前环境不支持网页串口（请用 Chrome / Edge）。</p>
      ) : (
        <>
          <div className="sdk-fivebar-servo-test-serial-bar sdk-fivebar-servo-test-serial-diag">
            <div className="sdk-fivebar-servo-test-serial-diag-grid">
              <span>supported: {String(serialStatus.supported)}</span>
              <span>portSelected: {String(serialStatus.portSelected)}</span>
              <span>connected: {String(serialStatus.connected)}</span>
              <span>baudRate: {serialStatus.baudRate ?? "—"}</span>
              <span>txCount: {serialStatus.txCount ?? 0}</span>
              <span>rxCount: {serialStatus.rxCount ?? 0}</span>
              <span>last send mode: {lastSendMode || "—"}</span>
            </div>
            <DiagRow label="last command" value={lastCommand || "—"} />
            <DiagRow label="last error" value={lastError || "—"} />
          </div>

          <div className="sdk-fivebar-servo-test-serial-bar">
            <span className="sdk-fivebar-servo-test-serial">
              串口：{serialConnected ? "已连接" : "未连接"}
            </span>
            <select
              className="sdk-fivebar-servo-test-baud"
              value={baudRate}
              disabled={serialConnected}
              onChange={(e) => setBaudRate(Number(e.target.value) || 115200)}
            >
              <option value={115200}>115200</option>
              <option value={9600}>9600</option>
            </select>
            <button
              type="button"
              className="btn-ghost btn-tiny"
              disabled={serialConnected}
              onClick={() => void handleSelectSerialPort()}
            >
              选择端口
            </button>
            <button
              type="button"
              className="btn-ghost btn-tiny"
              disabled={serialConnected}
              onClick={() => void handleOpenSerial()}
            >
              打开串口
            </button>
            <button
              type="button"
              className="btn-secondary btn-tiny"
              disabled={!serialConnected}
              onClick={() => void handleCloseSerial()}
            >
              关闭串口
            </button>
          </div>

          <div className="sdk-fivebar-servo-test-direct">
            <h5 className="sdk-fivebar-servo-test-direct-title">Direct Servo Diagnostic</h5>
            <p className="sdk-fivebar-servo-test-direct-hint">
              仅用 separate-write，绕过 IK 与 profile。样机总线 ID：<strong>#{FIVEBAR_HW_SERVO_A}</strong> /{" "}
              <strong>#{FIVEBAR_HW_SERVO_B}</strong>。若直发 1300/1700 仍无动作，请核对舵机 ID、接线、电源及波特率是否为控制板要求。
            </p>
            <div className="sdk-fivebar-test-actions sdk-fivebar-servo-test-direct-actions">
              <span className="sdk-fivebar-servo-test-direct-group">Servo {FIVEBAR_HW_SERVO_A}</span>
              <button type="button" className="btn-ghost btn-tiny" onClick={() => void sendDirectSingle(FIVEBAR_HW_SERVO_A, 1300)}>
                Servo {FIVEBAR_HW_SERVO_A} → 1300
              </button>
              <button type="button" className="btn-ghost btn-tiny" onClick={() => void sendDirectSingle(FIVEBAR_HW_SERVO_A, 1500)}>
                Servo {FIVEBAR_HW_SERVO_A} → 1500
              </button>
              <button type="button" className="btn-ghost btn-tiny" onClick={() => void sendDirectSingle(FIVEBAR_HW_SERVO_A, 1700)}>
                Servo {FIVEBAR_HW_SERVO_A} → 1700
              </button>
              <span className="sdk-fivebar-servo-test-direct-group">Servo {FIVEBAR_HW_SERVO_B}</span>
              <button type="button" className="btn-ghost btn-tiny" onClick={() => void sendDirectSingle(FIVEBAR_HW_SERVO_B, 1300)}>
                Servo {FIVEBAR_HW_SERVO_B} → 1300
              </button>
              <button type="button" className="btn-ghost btn-tiny" onClick={() => void sendDirectSingle(FIVEBAR_HW_SERVO_B, 1500)}>
                Servo {FIVEBAR_HW_SERVO_B} → 1500
              </button>
              <button type="button" className="btn-ghost btn-tiny" onClick={() => void sendDirectSingle(FIVEBAR_HW_SERVO_B, 1700)}>
                Servo {FIVEBAR_HW_SERVO_B} → 1700
              </button>
              <button type="button" className="btn-secondary btn-tiny" onClick={() => void sendDirectBothCenter()}>
                Both {FIVEBAR_HW_SERVO_A}/{FIVEBAR_HW_SERVO_B} → 1500
              </button>
            </div>
            {directDiag ? (
              <div className="sdk-fivebar-servo-test-direct-result">
                <div className="sdk-fivebar-servo-test-preview-title">直发结果（最近一次）</div>
                <DiagRow label="directCommand" value={directDiag.directCommand || "—"} />
                <DiagRow label="sendMode" value={directDiag.sendMode || "—"} />
                <DiagRow label="beforeTxCount" value={String(directDiag.beforeTxCount ?? "—")} />
                <DiagRow label="afterTxCount" value={String(directDiag.afterTxCount ?? "—")} />
                <DiagRow label="lastError" value={directDiag.lastError || "—"} />
                <DiagRow label="connected" value={String(directDiag.connected)} />
                <DiagRow label="targetServoId" value={String(directDiag.targetServoId ?? "—")} />
                <DiagRow label="targetPwm" value={String(directDiag.targetPwm ?? "—")} />
              </div>
            ) : null}
          </div>

          {sendStatus ? <p className="sdk-fivebar-servo-test-status hint">{sendStatus}</p> : null}
        </>
      )}

      {!resolved.enabled ? (
        <p className="sdk-servo-inspector-hint">右嘴角五杆 IK 未启用，仅可使用上方直发诊断。</p>
      ) : !resolved.readyForIk ? (
        <p className="sdk-servo-inspector-hint">{resolved.skipReason || "绑定未就绪"}（仅可使用直发诊断）</p>
      ) : (
        <>
          <div className="sdk-fivebar-servo-test-params sdk-fivebar-servo-test-ik-params">
            <span className="sdk-fivebar-servo-test-params-title">测试参数（仅本面板，不影响 Tracking）</span>
            <label className="sdk-fivebar-servo-test-param sdk-fivebar-servo-test-param--inline">
              testKx
              <input
                type="number"
                step={0.5}
                min={0.1}
                max={50}
                value={testKx}
                onChange={(e) => {
                  const n = Number(e.target.value)
                  setTestKx(Number.isFinite(n) ? clampNumber(n, 0.1, 50) : TEST_DEFAULT_KX)
                }}
              />
            </label>
            <label className="sdk-fivebar-servo-test-param sdk-fivebar-servo-test-param--inline">
              testKy
              <input
                type="number"
                step={0.5}
                min={0.1}
                max={50}
                value={testKy}
                onChange={(e) => {
                  const n = Number(e.target.value)
                  setTestKy(Number.isFinite(n) ? clampNumber(n, 0.1, 50) : TEST_DEFAULT_KY)
                }}
              />
            </label>
            <label className="sdk-fivebar-servo-test-param sdk-fivebar-servo-test-param--inline">
              testServoTimeMs
              <input
                type="number"
                step={10}
                min={0}
                max={9999}
                value={servoTimeMs}
                onChange={(e) => {
                  const n = Number(e.target.value)
                  setServoTimeMs(Number.isFinite(n) ? n : TEST_DEFAULT_SERVO_TIME_MS)
                }}
              />
            </label>
            <label className="sdk-fivebar-servo-test-param sdk-fivebar-servo-test-param--inline">
              runIntervalMs
              <input
                type="number"
                step={5}
                min={20}
                max={500}
                value={runIntervalMs}
                onChange={(e) => {
                  const n = Number(e.target.value)
                  setRunIntervalMs(
                    Number.isFinite(n) ? clampNumber(n, 20, 500) : TEST_DEFAULT_RUN_INTERVAL_MS
                  )
                }}
              />
            </label>
          </div>
          <p className="sdk-fivebar-servo-test-t-hint sdk-servo-inspector-hint">
            <strong>T(ms)</strong>：本面板默认 <strong>50ms</strong>；快速摸底可用 <strong>30–50ms</strong>；机构方向粗测可用{" "}
            <strong>150–300ms</strong>；实时追踪可用 <strong>30–80ms</strong>；<strong>T=5ms</strong> 仅极限低延迟测试。
            <strong>runIntervalMs</strong> 默认 <strong>30ms</strong>（run-to-target，可改 20–80ms）。
          </p>

          <div className="sdk-fivebar-servo-test-controls sdk-fivebar-servo-test-output-mode">
            <label className="sdk-fivebar-servo-test-param sdk-fivebar-servo-test-param--inline sdk-fivebar-servo-test-sendmode">
              FiveBar 输出模式
              <select
                value={fiveBarOutputMode}
                disabled={runToTargetBusy}
                onChange={(e) =>
                  setFiveBarOutputMode(/** @type {FiveBarOutputModeUi} */ (e.target.value))
                }
              >
                <option value="static-target">static-target（qSend=qRaw，不累积 qPrev）</option>
                <option value="stateful-one-step">stateful-one-step（qSend=qCmd，单步滤波）</option>
                <option value="run-to-target">run-to-target（自动循环逼近，或用下方 Run 按钮）</option>
              </select>
            </label>
          </div>
          <p className="sdk-fivebar-servo-test-mode-explain sdk-servo-inspector-hint">
            <strong>Static Target</strong>：一次到目标，验证方向与幅度（与正式 Face Rig 链路一致）。{" "}
            <strong>Stateful One-Step</strong>：单帧滤波调试（测试区使用 maxStep=90°、α=1）。{" "}
            <strong>Run To Target</strong>：模拟连续控制（最多 {RUN_TO_TARGET_MAX_FRAMES} 帧，间隔可调）。
          </p>
          <label className="sdk-fivebar-servo-test-profile-ids">
            <input
              type="checkbox"
              checked={useProfileServoIds}
              onChange={(e) => setUseProfileServoIds(e.target.checked)}
            />
            使用 Face Rig 绑定中的舵机号下发（不勾选则固定为样机{" "}
            <strong>
              #{FIVEBAR_HW_SERVO_A} / #{FIVEBAR_HW_SERVO_B}
            </strong>
            ）
          </label>

          <div className="sdk-fivebar-servo-test-controls">
            <label className="sdk-fivebar-servo-test-param sdk-fivebar-servo-test-param--inline sdk-fivebar-servo-test-sendmode">
              发送模式
              <select
                value={sendMode}
                onChange={(e) =>
                  setSendMode(/** @type {FiveBarServoSendMode} */ (e.target.value))
                }
              >
                <option value="separate-write">separate-write（逐条 writeText，推荐）</option>
                <option value="sequential-string">sequential-string（两帧拼成一串）</option>
                <option value="multi-brace">multi-brace（花括号同步）</option>
              </select>
            </label>
            <span className="sdk-fivebar-servo-test-serial">
              FiveBar 未连接会先 open；目标 <code>#</code>
              {useProfileServoIds ? "绑定号" : `${FIVEBAR_HW_SERVO_A}/${FIVEBAR_HW_SERVO_B}`}
            </span>
          </div>

          <div className="sdk-fivebar-test-actions">
            {SERVO_TEST_PRESETS.map((p) => (
              <button
                key={p.id}
                type="button"
                disabled={runToTargetBusy}
                className={
                  p.dangerousConfirm ? "btn-secondary btn-tiny sdk-fivebar-servo-test-preset-danger" : "btn-ghost btn-tiny"
                }
                onClick={() => void runPreset(p)}
              >
                {p.label}
              </button>
            ))}
            <button
              type="button"
              className="btn-ghost btn-tiny"
              disabled={runToTargetBusy}
              onClick={() => void handleRunToTarget()}
            >
              Run To Target
            </button>
            <button
              type="button"
              className="btn-secondary btn-tiny"
              disabled={!runToTargetBusy}
              onClick={() => handleStopRunToTarget()}
            >
              Stop Run
            </button>
            <button type="button" className="btn-secondary btn-tiny" onClick={() => void handleStopAllServo()}>
              Stop All Servo
            </button>
          </div>

          <div className="sdk-fivebar-test-diag sdk-fivebar-servo-test-preview">
            <div className="sdk-fivebar-servo-test-preview-title">
              发送前确认（相对绑定中立位的 Δ；实际下发以当前发送模式为准）
            </div>
            {!pv ? (
              <p className="sdk-servo-inspector-hint">点击 Send 预设以计算并尝试下发。</p>
            ) : (
              <>
                <DiagRow
                  label="可发送"
                  value={pv.canSend ? "是" : `否 — ${pv.blockReasons.join("；")}`}
                />
                <DiagRow
                  label="profile 绑定 id A/B"
                  value={`${pv.profileServoAId ?? "—"} / ${pv.profileServoBId ?? "—"}`}
                />
                <DiagRow label="命令 servoId A/B" value={`${pv.servoAId ?? "—"} / ${pv.servoBId ?? "—"}`} />
                <DiagRow
                  label="sideR.x / y"
                  value={`${fmt2(pv.sideR?.x)} / ${fmt2(pv.sideR?.y)}`}
                />
                <DiagRow
                  label="qRaw A/B（deg）"
                  value={qRaw ? `${fmt2(qRaw.qA_deg)} / ${fmt2(qRaw.qB_deg)}` : "—"}
                />
                <DiagRow
                  label="qCmd A/B（deg）"
                  value={qCmd ? `${fmt2(qCmd.qA_deg)} / ${fmt2(qCmd.qB_deg)}` : "—"}
                />
                <DiagRow
                  label="qSend A/B（deg，实际转 PWM）"
                  value={qSend ? `${fmt2(qSend.qA_deg)} / ${fmt2(qSend.qB_deg)}` : "—"}
                />
                <DiagRow
                  label="fiveBarOutputMode / qSendMode"
                  value={`${pv.fiveBarOutputModeUi ?? "—"} / ${pv.qSendMode ?? "—"}`}
                />
                {showStatefulErrorRows ? (
                  <>
                    <DiagRow
                      label="error（qRaw−qCmd）A/B（deg）"
                      value={
                        pv.errorA != null && pv.errorB != null
                          ? `${fmt2(pv.errorA)} / ${fmt2(pv.errorB)}`
                          : "—"
                      }
                    />
                    <DiagRow
                      label="estimatedFramesToTarget（ceil(max|error|/maxStep)）"
                      value={
                        pv.estimatedFramesToTarget != null ? String(pv.estimatedFramesToTarget) : "—"
                      }
                    />
                  </>
                ) : null}
                {statefulFramesHint ? <p className="sdk-servo-inspector-hint">{statefulFramesHint}</p> : null}
                <DiagRow
                  label="logicalPwm A / B"
                  value={`${fmtInt(pv.logicalPwmA)} / ${fmtInt(pv.logicalPwmB)}`}
                />
                <DiagRow
                  label="actualPwm A / B"
                  value={`${fmtInt(pv.actualPwmA)} / ${fmtInt(pv.actualPwmB)}`}
                />
                <DiagRow
                  label="neutralActual A / B（绑定中立→命令舵机）"
                  value={`${fmtInt(pv.neutralActualA)} / ${fmtInt(pv.neutralActualB)}`}
                />
                <DiagRow
                  label="Δ 相对中立（A / B，μs）"
                  value={`${fmtInt(pv.deltaAFromNeutral)} / ${fmtInt(pv.deltaBFromNeutral)}`}
                />
                <DiagRow
                  label="|Δ| A / B（μs）"
                  value={`${fmtInt(pv.absDeltaA)} / ${fmtInt(pv.absDeltaB)}`}
                />
                <DiagRow
                  label={`visibleMotion（阈值 ${pv.minVisibleDeltaUs ?? minVisibleDeltaUs}μs）`}
                  value={
                    pv.visibleMotion === true ? "yes" : pv.visibleMotion === false ? "no" : "—"
                  }
                />
                {pwmAmplitudeHint ? (
                  <p className="sdk-fivebar-servo-test-amp-hint">
                    当前 PWM 变化较小（两侧 |Δ| 均小于 {pv.minVisibleDeltaUs ?? minVisibleDeltaUs}
                    μs），真实机构可能不明显。可改用 Medium 预设、提高 testKx/testKy，或使用 static-target / run-to-target
                    观察完整行程。
                  </p>
                ) : null}
                <DiagRow label="scale" value={fmt2(pv.scale)} />
                <DiagRow label="T (ms)" value={String(pv.timeMs ?? "—")} />
                <DiagRow label="发送模式（preview）" value={sendMode} />
                <DiagRow
                  label="本次将下发的 command"
                  value={formatCommandLineForSendMode(pv, sendMode)}
                />
                <DiagRow label="multiBraceCommand" value={pv.multiBraceCommand || "—"} />
                <DiagRow label="sequentialCommand" value={pv.sequentialCommand || "—"} />
                <DiagRow
                  label="singleCommands"
                  value={
                    Array.isArray(pv.singleCommands) && pv.singleCommands.length
                      ? pv.singleCommands.join(" | ")
                      : "—"
                  }
                />
                {lastFiveBarSendLog ? (
                  <>
                    <div className="sdk-fivebar-servo-test-preview-title sdk-fivebar-servo-test-send-log-title">
                      最近一次 Send 前记录
                    </div>
                    <pre className="sdk-fivebar-servo-test-send-log">{lastFiveBarSendLog}</pre>
                  </>
                ) : null}
                {!pv.canSend ? (
                  <p className="sdk-servo-inspector-err sdk-fivebar-test-err">
                    安全拦截：{pv.blockReasons.join("；")}
                  </p>
                ) : null}
              </>
            )}
          </div>
        </>
      )}
    </div>
  )
}
