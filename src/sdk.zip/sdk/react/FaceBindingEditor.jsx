import { useState } from "react"
import FaceBindingInspector from "./FaceBindingInspector.jsx"
import FaceRigControls from "./FaceRigControls.jsx"
import { useRightMouthPadFiveBarDebug } from "../hooks/useRightMouthPadFiveBarDebug.js"
import "../style.css"

/**
 * 面部绑定工作台：FaceRigControls + 绑定检视 + 诊断；串口与工程级操作由宿主工具栏提供。
 */
export default function FaceBindingEditor({ configs = [], rigApi, realtimeThrottleMs }) {
  const rig = rigApi
  const [showFiveBarReachabilityOverlay, setShowFiveBarReachabilityOverlay] = useState(false)
  const padDebug = useRightMouthPadFiveBarDebug({
    profile: rig.normalizedProfile,
    configs,
    pad: rig.rig.mouth.sideR,
    enabled: showFiveBarReachabilityOverlay,
    outputMode: "static-target",
    mapStep: 2,
  })

  return (
    <div className="face-rig-body">
      <aside className="face-rig-panel face-rig-panel-rail">
        <div className="face-rig-rail-top">
          <div className="face-rig-logo-row">
            <span className="face-rig-logo">面部绑定</span>
            <span className="face-rig-logo-accent">精英工作台</span>
          </div>
          <hr className="face-rig-rule" />

          <div className="face-rig-tag">绑定配置</div>
          <p className="face-rig-rail-meta">
            {rig.normalizedProfile.name} · v{rig.normalizedProfile.version}
          </p>

          <label className="face-rig-realtime-toggle">
            <input
              type="checkbox"
              checked={showFiveBarReachabilityOverlay}
              onChange={(e) => setShowFiveBarReachabilityOverlay(e.target.checked)}
            />
            右嘴角 FiveBar 可达区叠加（Pad Debug）
          </label>

          {typeof realtimeThrottleMs === "number" ? (
            <label className="face-rig-realtime-toggle">
              <input
                type="checkbox"
                checked={rig.realtimePreview}
                onChange={(e) => rig.setRealtimePreview(e.target.checked)}
              />
              实时预览（约 {realtimeThrottleMs} 毫秒节流下发）
            </label>
          ) : null}

          <button
            type="button"
            className="btn-primary face-rig-rail-push"
            onClick={() => rig.pushToServo({ realtime: false })}
          >
            下发到舵机
          </button>
          <button type="button" className="btn-ghost face-rig-rail-reset" onClick={rig.resetEngine}>
            重置工作台
          </button>
          {rig.sendStatus ? <p className="hint face-rig-rail-hint">{rig.sendStatus}</p> : null}
        </div>

        <FaceBindingInspector
          controls={rig.normalizedProfile.controls}
          bindings={rig.normalizedProfile.bindings}
          contributions={rig.contributions}
          selectedControlId={rig.selectedControlId}
          selectedChannel={rig.selectedChannel}
          onSelectChannel={rig.setSelectedChannel}
          rigValues={rig.rigValues}
          configs={configs}
          onBindingsReplace={rig.handleBindingsReplace}
        />
      </aside>

      <FaceRigControls
        rigState={rig.rig}
        onRigStateChange={rig.setRig}
        setSelectedControlId={rig.setSelectedControlId}
        padLRef={rig.padLRef}
        padRRef={rig.padRRef}
        startVerticalScrub={rig.startVerticalScrub}
        startRadar={rig.startRadar}
        startCorner={rig.startCorner}
        radarCxPx={rig.radarCxPx}
        radarCyPx={rig.radarCyPx}
        jawPx={rig.jawPx}
        showFiveBarReachabilityOverlay={showFiveBarReachabilityOverlay}
        rightMouthPadReachabilityMap={padDebug.reachabilityMap}
        rightMouthPadEval={padDebug.currentEval}
      />

      <div className="face-rig-panel face-rig-panel-preview">
        <h3>输出诊断 · 舵机一览</h3>
        <div className="face-rig-preview-split">
          <div className="face-rig-preview-split-col face-rig-preview-split-col-diag">
            <p className="hint">
              合成规则：单条绑定直连该条逻辑脉宽；同一舵机多条绑定时以首条 neutralPwm
              为基准，累加各绑定相对其中性的增量。
            </p>

            <details open className="face-rig-diag-block">
              <summary>告警（{rig.warnings.length}）</summary>
              {rig.warnings.length === 0 ? (
                <p className="hint muted">无</p>
              ) : (
                <ul className="face-rig-warnings">
                  {rig.warnings.map((w, i) => (
                    <li key={i}>{w}</li>
                  ))}
                </ul>
              )}
            </details>

            <details open className="face-rig-diag-block">
              <summary>逻辑姿态</summary>
              <pre className="face-rig-diag-json">{JSON.stringify(rig.logicalPose, null, 2)}</pre>
            </details>

            <details open className="face-rig-diag-block">
              <summary>实际脉宽（限位与方向映射后）</summary>
              <pre className="face-rig-diag-json">{JSON.stringify(rig.actualPose, null, 2)}</pre>
            </details>

            <details open className="face-rig-diag-block">
              <summary>单通道贡献（合并前各绑定的逻辑脉宽）</summary>
              <pre className="face-rig-diag-json">{JSON.stringify(rig.contributions, null, 2)}</pre>
            </details>

            <details open className="face-rig-diag-block">
              <summary>控件通道原始值</summary>
              <pre className="face-rig-diag-json">{JSON.stringify(rig.rigValues, null, 2)}</pre>
            </details>
          </div>

          <div className="face-rig-preview-split-col face-rig-preview-split-col-servo">
            <h4 className="face-rig-mini-heading">舵机一览</h4>
            <ul className="face-rig-preview-list">
              {Object.entries(rig.logicalPose)
                .sort(([a], [b]) => Number(a) - Number(b))
                .map(([servoId, logical]) => {
                  const cfg = Array.isArray(configs) ? configs.find((c) => String(c.servoId) === servoId) : null
                  const name = cfg?.name || `舵机 ${servoId}`
                  const actual = rig.actualPose[servoId]
                  return (
                    <li key={servoId}>
                      <span className="preview-name">{name}</span>
                      <span className="preview-id">{servoId.padStart(2, "0")} 号</span>
                      <span className="preview-pwm">
                        逻辑 {logical}　实际 {actual ?? "—"}
                      </span>
                    </li>
                  )
                })}
            </ul>
            {Object.keys(rig.logicalPose).length === 0 ? (
              <p className="hint muted">当前无合成输出。</p>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  )
}
