import { useCallback, useLayoutEffect, useMemo, useRef, useState } from "react"
import { normalizeFaceRigProfile } from "../../core/faceRigProfile.js"
import { clampNumber } from "../../utils/clamp.js"
import { attachDragSession, tryCapturePointer } from "../../hooks/useFaceRigInteraction.js"
import {
  angleToBindingLogicalPwm,
  clampDToReachableArea,
  createRightMouthCornerFivebarState,
  padToRightMouthCornerDTarget,
  resetRightMouthCornerFivebarState,
  resolveRightMouthCornerFivebar,
} from "../kinematics/mouthCornerFivebar.js"
import { resolveRightMouthCornerKinematics } from "../kinematics/mouthCornerKinematics.js"
import {
  chooseNearestIkCandidate,
  fivebarFk,
  fivebarIkAllCandidates,
} from "../kinematics/fiveBar2d.js"

const TEST_MODE_STATEFUL = "stateful"
const TEST_MODE_STATIC = "static"

/** @type {{ id: string, label: string, title: string, x: number, y: number }[]} */
const PAD_PRESETS = [
  {
    id: "left-up",
    label: "Pad Left-Up 0/0",
    title: "左上角边界测试点（u=-1,v=+1），非机构零点",
    x: 0,
    y: 0,
  },
  {
    id: "right-up",
    label: "Right Up 65/40",
    title: "右上运动测试点",
    x: 65,
    y: 40,
  },
  {
    id: "right-down",
    label: "Right Down 60/65",
    title: "右下运动测试点",
    x: 60,
    y: 65,
  },
  {
    id: "left",
    label: "Left 40/50",
    title: "左向运动测试点",
    x: 40,
    y: 50,
  },
]

const VALIDATION_PAD_LABELS = ["50 / 50", "0 / 0", "100 / 100", "65 / 40", "60 / 65"]

function fmt2(v) {
  if (v === null || v === undefined || Number.isNaN(Number(v))) {
    return "—"
  }
  return Number(v).toFixed(2)
}

function fmtInt(v) {
  if (v === null || v === undefined || Number.isNaN(Number(v))) {
    return "—"
  }
  return String(Math.round(Number(v)))
}

function fmtPt(p) {
  if (!p || !Array.isArray(p) || p.length < 2) {
    return "—"
  }
  return `[${fmt2(p[0])}, ${fmt2(p[1])}]`
}

function clampPct(v) {
  const n = Number(v)
  if (!Number.isFinite(n)) {
    return 50
  }
  return clampNumber(n, 0, 100)
}

function normalizedUvFromPad(sideR, params) {
  const cx = Number(params?.padXCenter ?? 50)
  const cy = Number(params?.padYCenter ?? 50)
  const sx = clampPct(sideR?.x ?? 50)
  const sy = clampPct(sideR?.y ?? 50)
  const u = (sx - cx) / cx
  const v = (cy - sy) / cy
  return { u, v }
}

function dOffsetFromRaw(D0, D_raw) {
  if (
    !D0 ||
    !D_raw ||
    !Number.isFinite(D0[0]) ||
    !Number.isFinite(D_raw[0]) ||
    !Number.isFinite(D0[1]) ||
    !Number.isFinite(D_raw[1])
  ) {
    return null
  }
  return { dx: D_raw[0] - D0[0], dy: D_raw[1] - D0[1] }
}

function pickPadClientXY(ev, rect) {
  let cx = ev.clientX
  let cy = ev.clientY
  if (typeof cx !== "number" || typeof cy !== "number") {
    const t = ev.touches?.[0] ?? ev.changedTouches?.[0]
    if (t) {
      cx = t.clientX
      cy = t.clientY
    }
  }
  if (typeof cx !== "number" || typeof cy !== "number") {
    return { x: 50, y: 50 }
  }
  return {
    x: clampNumber(((cx - rect.left) / rect.width) * 100, 0, 100),
    y: clampNumber(((cy - rect.top) / rect.height) * 100, 0, 100),
  }
}

function DiagRow({ label, value }) {
  return (
    <div className="sdk-fivebar-test-row">
      <span className="sdk-fivebar-test-k">{label}</span>
      <span className="sdk-fivebar-test-v">{value}</span>
    </div>
  )
}

function validationRowFromPadLabel(padLabel, Kx, Ky) {
  const [sx, sy] = padLabel.split(" / ").map((s) => Number(String(s).trim()))
  const cx = 50
  const cy = 50
  const u = (sx - cx) / cx
  const v = (cy - sy) / cy
  const dx = Kx * u
  const dy = Ky * v
  return { pad: padLabel, u: fmt2(u), v: fmt2(v), off: `[${fmt2(dx)}, ${fmt2(dy)}]` }
}

/**
 * @param {ReturnType<typeof resolveRightMouthCornerKinematics>} resolved
 * @param {{ x: number, y: number }} nextSideR
 */
function runTestResolve(resolved, nextSideR, testStateRef) {
  const st = testStateRef.current
  const qPrevBefore = [Number(st.qPrev[0]) || 0, Number(st.qPrev[1]) || 0]
  const result = resolveRightMouthCornerFivebar({
    resolved: {
      bindingA: resolved.bindingA,
      bindingB: resolved.bindingB,
      servoAId: resolved.servoAId,
      servoBId: resolved.servoBId,
    },
    sideR: nextSideR,
    params: resolved.params,
    state: st,
  })
  const qPrevAfter = [Number(st.qPrev[0]) || 0, Number(st.qPrev[1]) || 0]
  return {
    ...result,
    qPrevBefore,
    qPrevAfter,
    mode: TEST_MODE_STATEFUL,
  }
}

/**
 * Static IK：单帧 Pad→D→IK；不读写 testFivebarStateRef、无滤波。
 */
function runStaticIk(resolved, nextSideR) {
  const params = resolved.params
  const fk0 = fivebarFk(0, 0, params)
  if (!fk0.ok || !fk0.D) {
    return {
      ok: false,
      message: fk0.message || "FK(0,0) 失败",
      diagnostics: null,
      qPrevBefore: null,
      qPrevAfter: null,
      mode: TEST_MODE_STATIC,
    }
  }
  const D0 = fk0.D
  const pad = padToRightMouthCornerDTarget(nextSideR, D0, params)
  if (!pad.D_raw) {
    return {
      ok: false,
      message: "Pad→D_raw 失败",
      diagnostics: null,
      qPrevBefore: null,
      qPrevAfter: null,
      mode: TEST_MODE_STATIC,
    }
  }
  const clamped = clampDToReachableArea(pad.D_raw, D0, params)
  const D_safe = clamped.D_safe
  const candidates = fivebarIkAllCandidates(D_safe, params)
  if (candidates.length === 0) {
    return {
      ok: false,
      message: clamped.message || "IK 无解（Static）",
      diagnostics: {
        enabled: true,
        ok: false,
        sideR: { x: nextSideR.x, y: nextSideR.y },
        D0: [...D0],
        D_raw: [...pad.D_raw],
        D_safe: [...D_safe],
        scale: clamped.scale,
        candidateCount: 0,
        servoAId: resolved.servoAId,
        servoBId: resolved.servoBId,
        message: clamped.message,
      },
      qPrevBefore: null,
      qPrevAfter: null,
      mode: TEST_MODE_STATIC,
    }
  }
  const picked = chooseNearestIkCandidate(candidates, { qA_deg: 0, qB_deg: 0 })
  if (!picked) {
    return {
      ok: false,
      message: "Static IK：候选选择失败",
      diagnostics: null,
      qPrevBefore: null,
      qPrevAfter: null,
      mode: TEST_MODE_STATIC,
    }
  }
  const qA = picked.qA_deg
  const qB = picked.qB_deg
  const logicalPwmA = angleToBindingLogicalPwm(qA, resolved.bindingA)
  const logicalPwmB = angleToBindingLogicalPwm(qB, resolved.bindingB)
  let msg = clamped.message || ""
  if (clamped.scale < 1 - 1e-9 && !msg) {
    msg = "D_target 超出可达区，已 clamp"
  }
  const diagnostics = {
    enabled: true,
    ok: true,
    sideR: { x: nextSideR.x, y: nextSideR.y },
    D0: [...D0],
    D_raw: [...pad.D_raw],
    D_safe: [...D_safe],
    scale: clamped.scale,
    candidateCount: candidates.length,
    qRaw: { qA_deg: qA, qB_deg: qB },
    qCmd: { qA_deg: qA, qB_deg: qB },
    qRawA: qA,
    qRawB: qB,
    qCmdA: qA,
    qCmdB: qB,
    qA_deg: qA,
    qB_deg: qB,
    logicalPwmA,
    logicalPwmB,
    pwmA: logicalPwmA,
    pwmB: logicalPwmB,
    servoAId: resolved.servoAId,
    servoBId: resolved.servoBId,
    message: msg,
  }
  return {
    ok: true,
    message: "",
    diagnostics,
    qPrevBefore: null,
    qPrevAfter: null,
    mode: TEST_MODE_STATIC,
  }
}

/**
 * @param {{ profile: object }} props
 */
export default function RightMouthFiveBarTestPanel({ profile }) {
  const [sideR, setSideR] = useState({ x: 50, y: 50 })
  const [testMode, setTestMode] = useState(TEST_MODE_STATEFUL)
  const [testIk, setTestIk] = useState(null)

  const testFivebarStateRef = useRef(createRightMouthCornerFivebarState())
  const padRef = useRef(null)
  const resolvedRef = useRef(null)
  const testModeRef = useRef(testMode)
  const sideRRef = useRef(sideR)

  sideRRef.current = sideR
  testModeRef.current = testMode

  const normalizedProfile = useMemo(() => normalizeFaceRigProfile(profile), [profile])
  const resolved = useMemo(
    () => resolveRightMouthCornerKinematics(normalizedProfile),
    [normalizedProfile]
  )
  resolvedRef.current = resolved

  const Kx = Number(resolved.params?.Kx ?? 7)
  const Ky = Number(resolved.params?.Ky ?? 7)

  const evaluateTestPoint = useCallback((nextSideR) => {
    const r = resolvedRef.current
    const nx = { x: clampPct(nextSideR.x), y: clampPct(nextSideR.y) }
    const mode = testModeRef.current

    if (!r || !r.enabled) {
      setTestIk({
        ok: false,
        message: "右嘴角五杆 IK 未启用",
        diagnostics: null,
        qPrevBefore: mode === TEST_MODE_STATEFUL ? [0, 0] : null,
        qPrevAfter: mode === TEST_MODE_STATEFUL ? [0, 0] : null,
        mode,
      })
      setSideR(nx)
      return
    }
    if (!r.readyForIk) {
      setTestIk({
        ok: false,
        message: r.skipReason || "未找到 mouth_corner_r.x / y 绑定",
        diagnostics: null,
        qPrevBefore: mode === TEST_MODE_STATEFUL ? [0, 0] : null,
        qPrevAfter: mode === TEST_MODE_STATEFUL ? [0, 0] : null,
        mode,
      })
      setSideR(nx)
      return
    }

    if (mode === TEST_MODE_STATIC) {
      setTestIk(runStaticIk(r, nx))
    } else {
      setTestIk(runTestResolve(r, nx, testFivebarStateRef))
    }
    setSideR(nx)
  }, [])

  useLayoutEffect(() => {
    if (!resolved.enabled || !resolved.readyForIk) {
      setTestIk(null)
      return
    }
    evaluateTestPoint(sideRRef.current)
  }, [
    resolved.enabled,
    resolved.readyForIk,
    resolved.servoAId,
    resolved.servoBId,
    normalizedProfile.updatedAt,
    testMode,
    evaluateTestPoint,
  ])

  const ikResult = testIk ?? {
    ok: false,
    message: "",
    diagnostics: null,
    qPrevBefore: null,
    qPrevAfter: null,
    mode: testMode,
  }
  const d = ikResult.diagnostics
  const panelMode = ikResult.mode ?? testMode

  const uv =
    resolved.readyForIk && resolved.params ? normalizedUvFromPad(sideR, resolved.params) : null
  const dxy = d?.D0 && d?.D_raw ? dOffsetFromRaw(d.D0, d.D_raw) : null

  const handleResetQPrev = useCallback(() => {
    resetRightMouthCornerFivebarState(testFivebarStateRef.current)
    if (testModeRef.current === TEST_MODE_STATEFUL) {
      evaluateTestPoint(sideRRef.current)
    }
  }, [evaluateTestPoint])

  const handleCenterPadAndResetQPrev = useCallback(() => {
    resetRightMouthCornerFivebarState(testFivebarStateRef.current)
    evaluateTestPoint({ x: 50, y: 50 })
  }, [evaluateTestPoint])

  const applyPreset = useCallback(
    (x, y) => {
      evaluateTestPoint({ x: clampPct(x), y: clampPct(y) })
    },
    [evaluateTestPoint]
  )

  const startPadDrag = useCallback(
    (event) => {
      if (typeof event.button === "number" && event.button !== 0) {
        return
      }
      event.preventDefault()
      event.stopPropagation()
      tryCapturePointer(event.currentTarget, event.nativeEvent)

      function updateFromPointer(ev) {
        const el = padRef.current
        if (!el) {
          return
        }
        const rect = el.getBoundingClientRect()
        if (rect.width <= 0 || rect.height <= 0) {
          return
        }
        const next = pickPadClientXY(ev, rect)
        evaluateTestPoint(next)
      }

      updateFromPointer(event)
      attachDragSession({
        onMove: updateFromPointer,
      })
    },
    [evaluateTestPoint]
  )

  const validationRows = useMemo(
    () => VALIDATION_PAD_LABELS.map((label) => validationRowFromPadLabel(label, Kx, Ky)),
    [Kx, Ky]
  )

  const qPrevLabel =
    panelMode === TEST_MODE_STATIC ? "—（Static IK，无 qPrev）" : null

  return (
    <div className="sdk-servo-inspector-block sdk-servo-inspector-block--kinematics sdk-fivebar-test-panel">
      <h4 className="sdk-servo-inspector-subtitle">Right Mouth FiveBar Test</h4>
      <div className="sdk-fivebar-test-semantics">
        <p className="sdk-fivebar-test-hint sdk-fivebar-test-semantics-lead">
          Pad 50/50 是 Face Rig 嘴角中性点；Pad 0/0 是左上角边界点，不是零点。归一化 u/v=0/0 和机构 qA/qB=0°/0°
          才分别表示控制量中性与机构零位。
        </p>
        <p className="sdk-fivebar-test-hint">
          独立 <code>testFivebarStateRef</code>，不影响 Tracking / 关键帧 / WebSerial。
        </p>
      </div>

      {!resolved.enabled ? (
        <p className="sdk-servo-inspector-hint">右嘴角五杆 IK 未启用。</p>
      ) : !resolved.readyForIk ? (
        <p className="sdk-servo-inspector-hint">{resolved.skipReason || "绑定未就绪"}</p>
      ) : (
        <>
          <div className="sdk-fivebar-test-mode-bar" role="group" aria-label="测试模式">
            <span className="sdk-fivebar-test-mode-title">当前模式：</span>
            <label className="sdk-fivebar-test-mode-label">
              <input
                type="radio"
                name="fivebar-test-mode"
                checked={testMode === TEST_MODE_STATEFUL}
                onChange={() => setTestMode(TEST_MODE_STATEFUL)}
              />
              Stateful Output（qPrev + 连续 IK + 滤波）
            </label>
            <label className="sdk-fivebar-test-mode-label">
              <input
                type="radio"
                name="fivebar-test-mode"
                checked={testMode === TEST_MODE_STATIC}
                onChange={() => setTestMode(TEST_MODE_STATIC)}
              />
              Static IK（单帧 Pad→D→IK，无状态）
            </label>
          </div>

          <div className="sdk-fivebar-test-pad-wrap">
            <div
              ref={padRef}
              role="presentation"
              className="face-rig-corner-pad face-rig-mouth-corner-pad sdk-fivebar-test-pad"
              onPointerDown={startPadDrag}
            >
              <div
                className="face-rig-corner-cursor"
                style={{
                  left: `${sideR.x}%`,
                  top: `${sideR.y}%`,
                }}
              />
              <div className="face-rig-corner-label face-rig-corner-label-r">sideR</div>
            </div>
            <div className="sdk-fivebar-test-pad-readout">
              <span>x: {Math.round(sideR.x)}</span>
              <span>y: {Math.round(sideR.y)}</span>
            </div>
          </div>

          <div className="sdk-fivebar-test-actions">
            <button type="button" className="btn-secondary btn-tiny" onClick={handleResetQPrev}>
              重置 qPrev
            </button>
            <button
              type="button"
              className="btn-ghost btn-tiny"
              title="仅 Pad 中性点，不重置滤波状态"
              onClick={() => applyPreset(50, 50)}
            >
              Center 50/50（中性点）
            </button>
            <button
              type="button"
              className="btn-ghost btn-tiny"
              title="Pad 中性并重置滤波状态"
              onClick={handleCenterPadAndResetQPrev}
            >
              Center + 重置 qPrev（中性点 + 滤波归零）
            </button>
            {PAD_PRESETS.map((p) => (
              <button
                key={p.id}
                type="button"
                className="btn-ghost btn-tiny"
                title={p.title}
                onClick={() => applyPreset(p.x, p.y)}
              >
                {p.label}
              </button>
            ))}
          </div>

          <div className="sdk-fivebar-test-valid-table-wrap">
            <div className="sdk-fivebar-test-valid-table-title">坐标转换验证表（理论 u/v 与 D 偏移 mm，Kx={Kx} Ky={Ky}）</div>
            <table className="sdk-fivebar-test-valid-table">
              <thead>
                <tr>
                  <th>Pad x/y</th>
                  <th>u</th>
                  <th>v</th>
                  <th>D offset dx, dy</th>
                </tr>
              </thead>
              <tbody>
                {validationRows.map((row) => (
                  <tr key={row.pad}>
                    <td>{row.pad}</td>
                    <td>{row.u}</td>
                    <td>{row.v}</td>
                    <td>{row.off}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="sdk-fivebar-test-diag">
            <DiagRow
              label="面板模式"
              value={panelMode === TEST_MODE_STATIC ? "Static IK" : "Stateful Output"}
            />
            <DiagRow label="ok" value={String(ikResult.ok)} />
            <DiagRow
              label="Pad sideR.x / sideR.y"
              value={`${fmt2(sideR.x)} / ${fmt2(sideR.y)}（0~100；50/50 为中性）`}
            />
            <DiagRow
              label="Normalized u / v"
              value={
                uv ? `${fmt2(uv.u)} / ${fmt2(uv.v)}（中性为 0/0）` : "—"
              }
            />
            <DiagRow
              label="D offset dx / dy（mm）"
              value={
                dxy
                  ? `${fmt2(dxy.dx)} / ${fmt2(dxy.dy)}（D_raw − D0）`
                  : "—"
              }
            />
            <DiagRow label="D0" value={fmtPt(d?.D0)} />
            <DiagRow label="D_raw" value={fmtPt(d?.D_raw)} />
            <DiagRow label="D_safe" value={fmtPt(d?.D_safe)} />
            <DiagRow label="scale" value={fmt2(d?.scale)} />
            <DiagRow
              label="candidateCount"
              value={d?.candidateCount != null ? String(d.candidateCount) : "—"}
            />
            <DiagRow
              label="qPrevBefore A/B（deg）"
              value={
                qPrevLabel ||
                (ikResult.qPrevBefore
                  ? `${fmt2(ikResult.qPrevBefore[0])}° / ${fmt2(ikResult.qPrevBefore[1])}°`
                  : "—")
              }
            />
            <DiagRow
              label="qRaw A/B（deg，机构角度）"
              value={
                d?.qRaw
                  ? `${fmt2(d.qRaw.qA_deg)}° / ${fmt2(d.qRaw.qB_deg)}°`
                  : `${fmt2(d?.qRawA)}° / ${fmt2(d?.qRawB)}°`
              }
            />
            <DiagRow
              label="qCmd A/B（deg，滤波后机构角度）"
              value={
                `${d?.qCmd ? `${fmt2(d.qCmd.qA_deg)}° / ${fmt2(d.qCmd.qB_deg)}°` : `${fmt2(d?.qCmdA ?? d?.qA_deg)}° / ${fmt2(d?.qCmdB ?? d?.qB_deg)}°`}${
                  panelMode === TEST_MODE_STATIC ? "（Static：无滤波）" : ""
                }`
              }
            />
            <DiagRow
              label="qPrevAfter A/B（deg）"
              value={
                qPrevLabel ||
                (ikResult.qPrevAfter
                  ? `${fmt2(ikResult.qPrevAfter[0])}° / ${fmt2(ikResult.qPrevAfter[1])}°`
                  : "—")
              }
            />
            <DiagRow
              label="logicalPwmA / B"
              value={`${fmtInt(d?.logicalPwmA ?? d?.pwmA)} / ${fmtInt(d?.logicalPwmB ?? d?.pwmB)}`}
            />
            <DiagRow label="servoA / B" value={`${d?.servoAId ?? "—"} / ${d?.servoBId ?? "—"}`} />
            <DiagRow label="message" value={d?.message || ikResult.message || "—"} />
            {!ikResult.ok ? (
              <p className="sdk-servo-inspector-err sdk-fivebar-test-err">{ikResult.message || "IK 失败"}</p>
            ) : null}
          </div>
        </>
      )}
    </div>
  )
}
