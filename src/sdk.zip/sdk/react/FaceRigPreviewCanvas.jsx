import { useCallback, useMemo, useRef } from "react"
import FaceRigWorkspace from "../../components/FaceRigWorkspace.jsx"
import {
  clampPctLogicalCircleEyexy,
  jawOffsetPx,
  radarCursorCenterPx,
} from "../../hooks/useFaceRigInteraction.js"
import { normalizeEliteRig } from "../tracking/trackingMapper.js"

/**
 * 只读 Face Rig 控件预览：用于映射预览页等，不驱动 binding、不写串口。
 * @param {{ rig: object }} props
 */
export default function FaceRigPreviewCanvas({ rig }) {
  const padLRef = useRef(null)
  const padRRef = useRef(null)

  const normalized = useMemo(() => normalizeEliteRig(rig), [rig])

  const radarDisp = useMemo(
    () => clampPctLogicalCircleEyexy(normalized.sharedRadar?.x ?? 50, normalized.sharedRadar?.y ?? 50),
    [normalized]
  )
  const radarCxPx = radarCursorCenterPx(radarDisp, "x")
  const radarCyPx = radarCursorCenterPx(radarDisp, "y")
  const jawPx = jawOffsetPx(normalized.jaw?.val ?? 0)

  const noop = useCallback(() => {}, [])
  const startVerticalScrub = useCallback(() => {}, [])
  const startRadar = useCallback((e) => {
    e?.preventDefault?.()
    e?.stopPropagation?.()
  }, [])
  const startCorner = useCallback((e) => {
    e?.preventDefault?.()
    e?.stopPropagation?.()
  }, [])

  return (
    <div className="sdk-face-rig-preview-canvas" aria-label="Face Rig 映射预览（只读）">
      <FaceRigWorkspace
        rig={normalized}
        setRig={noop}
        setSelectedControlId={noop}
        padLRef={padLRef}
        padRRef={padRRef}
        startVerticalScrub={startVerticalScrub}
        startRadar={startRadar}
        startCorner={startCorner}
        radarCxPx={radarCxPx}
        radarCyPx={radarCyPx}
        jawPx={jawPx}
      />
    </div>
  )
}
