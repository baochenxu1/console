import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react"
import {
  addKeyframe,
  buildFrameProjectExport,
  copyKeyframe,
  createDefaultFrameProject,
  createKeyframe,
  createPoseFromServos,
  deleteKeyframe,
  insertKeyframe,
  loadFrameProject,
  moveKeyframe,
  normalizeFrameProject,
  saveFrameProject,
  updateExpressionName,
  updateKeyframe,
} from "../../core/frameProject.js"
import { buildStopAllCommand } from "../../core/servoProtocol.js"
import { webSerial } from "../../core/webSerial.js"
import {
  approximateEliteRigFromKeyframePositions,
  createInitialEliteRig,
  mapFaceRigToPose,
  rigValuesFromEliteRig,
} from "../../core/faceDofMapper.js"
import { useFaceRigInteraction } from "../../hooks/useFaceRigInteraction.js"
import { buildSingleExpressionExportFilename, exportJsonFile } from "../../utils/fileExport.js"
import ExpressionFramePanel from "./ExpressionFramePanel.jsx"
import ExpressionTimeline from "./ExpressionTimeline.jsx"
import FaceRigControls from "./FaceRigControls.jsx"
import { useRightMouthPadFiveBarDebug } from "../hooks/useRightMouthPadFiveBarDebug.js"
import { getKeyframeFiveBarPlaybackNote } from "../../core/actionPlayer.js"
import RightMouthFiveBarBaselineStatus from "./kinematics/RightMouthFiveBarBaselineStatus.jsx"
import FaceTrackingPanel from "./FaceTrackingPanel.jsx"
import "../style.css"
import {
  applyTrackingCalibration,
  createDefaultTrackingCalibration,
  createWebSocketTrackingAdapter,
} from "../tracking/index.js"

const DEFAULT_WS_TRACKING_URL = "ws://127.0.0.1:8766/tracking"
/** Drive Rig：定时取最新帧应用，与 WebSocket 接收解耦 */
const DRIVE_RIG_INTERVAL_MS = 40
const DEBUG_DISPLAY_INTERVAL_MS = 200
const DEBUG_DISPLAY_INTERVAL_LIGHT_MS = 300

export default function FaceExpressionEditor({
  configs = [],
  frameProject,
  onFrameProjectChange,
  currentPose,
  onCurrentPoseChange,
  servoConfigSnapshot = null,
}) {
  const rig = useFaceRigInteraction(configs)
  const trackingAdapterRef = useRef(null)

  const [trackingEnabled, setTrackingEnabled] = useState(false)
  const [driveRigEnabled, setDriveRigEnabled] = useState(false)
  const [trackingAdapterVersion, setTrackingAdapterVersion] = useState(0)
  const [trackingWsUrlDraft, setTrackingWsUrlDraft] = useState(DEFAULT_WS_TRACKING_URL)
  /** @type {React.MutableRefObject<{ frame: import("../tracking/trackingTypes.js").RigFrame; receivedAt: number; seq: number } | null>} */
  const lastTrackingFramePackRef = useRef(null)
  const trackingFrameSeqRef = useRef(0)
  const lastDriveAppliedSeqRef = useRef(-1)
  const setRigFromWebTrackingRef = useRef(rig.setRigFromWebTracking)
  setRigFromWebTrackingRef.current = rig.setRigFromWebTracking

  const driveRigApplyCountRef = useRef(0)
  const uiDebugCommitCountRef = useRef(0)
  const [lightDebugMode, setLightDebugMode] = useState(false)
  const [showFiveBarReachabilityOverlay, setShowFiveBarReachabilityOverlay] = useState(false)
  const padDebug = useRightMouthPadFiveBarDebug({
    profile: rig.normalizedProfile,
    configs,
    pad: rig.rig.mouth.sideR,
    enabled: showFiveBarReachabilityOverlay,
    outputMode: "static-target",
    mapStep: 2,
  })
  const [displayTrackingFrame, setDisplayTrackingFrame] = useState(
    /** @type {import("../tracking/trackingTypes.js").RigFrame | null} */ (null)
  )
  const [expressionTrackingFps, setExpressionTrackingFps] = useState(() => ({
    uiDebugFps: /** @type {number | null} */ (null),
    driveRigFps: /** @type {number | null} */ (null),
  }))
  const lastUiDisplayedSeqRef = useRef(-1)

  const trackingCalibrationRef = useRef(createDefaultTrackingCalibration())
  const prevCalibratedTrackingFrameRef = useRef(
    /** @type {null | ReturnType<typeof applyTrackingCalibration>} */ (null)
  )

  const trackingEnabledRef = useRef(false)

  if (!trackingAdapterRef.current) {
    trackingAdapterRef.current = createWebSocketTrackingAdapter({ url: DEFAULT_WS_TRACKING_URL })
  }

  useEffect(() => {
    trackingEnabledRef.current = trackingEnabled
  }, [trackingEnabled])

  const debugDisplayIntervalMs = lightDebugMode ? DEBUG_DISPLAY_INTERVAL_LIGHT_MS : DEBUG_DISPLAY_INTERVAL_MS

  useEffect(() => {
    if (!trackingEnabled) {
      lastTrackingFramePackRef.current = null
      lastUiDisplayedSeqRef.current = -1
      setDisplayTrackingFrame(null)
      setExpressionTrackingFps({ uiDebugFps: null, driveRigFps: null })
      return undefined
    }
    const id = window.setInterval(() => {
      const pack = lastTrackingFramePackRef.current
      if (!pack) {
        if (lastUiDisplayedSeqRef.current !== -1) {
          lastUiDisplayedSeqRef.current = -1
          setDisplayTrackingFrame(null)
          uiDebugCommitCountRef.current += 1
        }
        return
      }
      if (pack.seq === lastUiDisplayedSeqRef.current) {
        return
      }
      lastUiDisplayedSeqRef.current = pack.seq
      setDisplayTrackingFrame(pack.frame)
      uiDebugCommitCountRef.current += 1
    }, debugDisplayIntervalMs)
    return () => window.clearInterval(id)
  }, [trackingEnabled, debugDisplayIntervalMs])

  useEffect(() => {
    if (!trackingEnabled) {
      return undefined
    }
    const windowMs = 500
    const id = window.setInterval(() => {
      const ui = Math.round(uiDebugCommitCountRef.current / (windowMs / 1000))
      const dr = Math.round(driveRigApplyCountRef.current / (windowMs / 1000))
      uiDebugCommitCountRef.current = 0
      driveRigApplyCountRef.current = 0
      setExpressionTrackingFps({
        uiDebugFps: ui,
        driveRigFps: driveRigEnabled ? dr : null,
      })
    }, windowMs)
    return () => window.clearInterval(id)
  }, [trackingEnabled, driveRigEnabled])

  useEffect(() => {
    if (!trackingEnabled || !driveRigEnabled) {
      return undefined
    }
    const id = window.setInterval(() => {
      const pack = lastTrackingFramePackRef.current
      if (!pack || !pack.frame || typeof pack.frame !== "object") {
        return
      }
      if (pack.seq === lastDriveAppliedSeqRef.current) {
        return
      }
      const frame = pack.frame
      const calib = trackingCalibrationRef.current
      const prev = prevCalibratedTrackingFrameRef.current

      if (!frame.faceDetected) {
        const held = applyTrackingCalibration(frame, prev, calib)
        prevCalibratedTrackingFrameRef.current = held
        lastDriveAppliedSeqRef.current = pack.seq
        return
      }

      const next = applyTrackingCalibration(frame, prev, calib)
      prevCalibratedTrackingFrameRef.current = next
      setRigFromWebTrackingRef.current(structuredClone(next.rig))
      lastDriveAppliedSeqRef.current = pack.seq
      driveRigApplyCountRef.current += 1
    }, DRIVE_RIG_INTERVAL_MS)
    return () => window.clearInterval(id)
  }, [trackingEnabled, driveRigEnabled])

  useEffect(() => {
    return () => {
      const adapter = trackingAdapterRef.current
      if (adapter) {
        adapter.stop()
        adapter.dispose()
      }
      trackingAdapterRef.current = null
    }
  }, [])

  useEffect(() => {
    const adapter = trackingAdapterRef.current
    if (!adapter) {
      return undefined
    }
    if (!trackingEnabled) {
      adapter.stop()
      return undefined
    }
    adapter.start()
    return () => adapter.stop()
  }, [trackingEnabled, trackingAdapterVersion])

  /** WebSocket RX：仅写 ref，不 setState、不 Drive Rig（由定时器取最新帧）。 */
  const handleTrackingFrame = useCallback(
    /** @type {(frame: import("../tracking/trackingTypes.js").RigFrame) => void} */
    (frame) => {
      if (!frame || typeof frame !== "object") {
        lastTrackingFramePackRef.current = null
        return
      }
      const now = typeof performance !== "undefined" ? performance.now() : Date.now()
      trackingFrameSeqRef.current += 1
      lastTrackingFramePackRef.current = {
        frame,
        receivedAt: now,
        seq: trackingFrameSeqRef.current,
      }
    },
    []
  )

  const handleReplaceWithWebSocketTrackingAdapter = useCallback(() => {
    const wasRunning = trackingEnabledRef.current
    const url = trackingWsUrlDraft.trim() || DEFAULT_WS_TRACKING_URL

    trackingAdapterRef.current?.stop()
    trackingAdapterRef.current?.dispose()

    trackingAdapterRef.current = createWebSocketTrackingAdapter({ url })
    setTrackingAdapterVersion((value) => value + 1)
    prevCalibratedTrackingFrameRef.current = null
    lastDriveAppliedSeqRef.current = -1
    trackingFrameSeqRef.current = 0

    if (wasRunning) {
      trackingAdapterRef.current.start()
    }
  }, [trackingWsUrlDraft])

  const handleTrackingClearState = useCallback(() => {
    rig.resetRightMouthCornerFivebarKinematics?.()
    setTrackingEnabled(false)
    trackingAdapterRef.current?.stop()
    trackingAdapterRef.current?.clearState?.()
    prevCalibratedTrackingFrameRef.current = null
    lastTrackingFramePackRef.current = null
    lastDriveAppliedSeqRef.current = -1
    trackingFrameSeqRef.current = 0
    lastUiDisplayedSeqRef.current = -1
    setDisplayTrackingFrame(null)
  }, [])

  /** 仅前端：清空校准平滑上一帧、面控回中性；不停止 Tracking、不下发舵机、不清关键帧。 */
  const handleResetTrackingState = useCallback(() => {
    rig.resetRightMouthCornerFivebarKinematics?.()
    prevCalibratedTrackingFrameRef.current = null
    lastDriveAppliedSeqRef.current = -1
    trackingFrameSeqRef.current = 0
    lastUiDisplayedSeqRef.current = -1
    rig.setRig(createInitialEliteRig())
  }, [rig.setRig])
  const [selectedFrameIndex, setSelectedFrameIndex] = useState(0)
  const [mergeHint, setMergeHint] = useState("")
  const [defaultDurationMs, setDefaultDurationMs] = useState(500)
  const [sideTab, setSideTab] = useState("frame")
  const [keyframeDurationDraft, setKeyframeDurationDraft] = useState(null)
  const projectFileInputRef = useRef(null)
  const committedLogicalPoseJsonRef = useRef("")
  const lastKeyframeSyncTokenRef = useRef("")
  const [hasUnsavedRigPose, setHasUnsavedRigPose] = useState(false)

  useEffect(() => {
    const cur = JSON.stringify(rig.logicalPose)
    setHasUnsavedRigPose(cur !== committedLogicalPoseJsonRef.current)
  }, [rig.logicalPose])

  const commitRigPoseBaseline = useCallback(() => {
    committedLogicalPoseJsonRef.current = JSON.stringify(rig.logicalPose)
    setHasUnsavedRigPose(false)
  }, [rig.logicalPose])

  const currentControlInspect = useMemo(() => {
    const id = rig.selectedControlId
    if (!id) {
      return null
    }
    const ctrl = rig.normalizedProfile.controls.find((c) => c.controlId === id)
    const label = ctrl?.label ?? id
    const paths = rig.contributions.filter((c) => c.controlId === id)
    const servoIds = [...new Set(paths.map((p) => Number(p.servoId)))].sort((a, b) => a - b)
    const rv = rig.rigValues[id] || {}
    const parts = []
    const chans = ctrl?.channels || {}
    if (Object.prototype.hasOwnProperty.call(chans, "value")) {
      const v = rv.value
      parts.push(`value: ${v === undefined || v === null || Number.isNaN(Number(v)) ? "—" : String(v)}`)
    }
    if (Object.prototype.hasOwnProperty.call(chans, "x")) {
      const v = rv.x
      parts.push(`x: ${v === undefined || v === null || Number.isNaN(Number(v)) ? "—" : String(v)}`)
    }
    if (Object.prototype.hasOwnProperty.call(chans, "y")) {
      const v = rv.y
      parts.push(`y: ${v === undefined || v === null || Number.isNaN(Number(v)) ? "—" : String(v)}`)
    }
    const ch = rig.selectedChannel
    return {
      label,
      controlId: id,
      channelTag: `${id}.${ch}`,
      valueText: parts.length ? parts.join(" · ") : "—",
      outputPathCount: paths.length,
      servoIds,
    }
  }, [rig.selectedControlId, rig.normalizedProfile, rig.contributions, rig.rigValues, rig.selectedChannel])

  const normalizedProject = useMemo(
    () => normalizeFrameProject(frameProject, configs),
    [frameProject, configs]
  )
  const keyframes = normalizedProject.keyframes || []
  const totalDurationMs = useMemo(
    () => keyframes.reduce((a, f) => a + f.durationMs, 0),
    [keyframes]
  )

  useEffect(() => {
    if (selectedFrameIndex >= keyframes.length) {
      setSelectedFrameIndex(Math.max(0, keyframes.length - 1))
    }
  }, [keyframes.length, selectedFrameIndex])

  useEffect(() => {
    const d = keyframes[0]?.durationMs
    if (Number.isFinite(d) && d >= 20) {
      setDefaultDurationMs(d)
    }
  }, [normalizedProject.expressionId, keyframes[0]?.durationMs])

  const selectedKeyframe = keyframes[selectedFrameIndex] || null

  useEffect(() => {
    setKeyframeDurationDraft(null)
  }, [selectedKeyframe?.keyframeId])

  useLayoutEffect(() => {
    if (!selectedKeyframe) {
      lastKeyframeSyncTokenRef.current = ""
      return
    }
    const token = `${selectedKeyframe.keyframeId}:${JSON.stringify(selectedKeyframe.positions)}`
    if (lastKeyframeSyncTokenRef.current === token) {
      return
    }
    lastKeyframeSyncTokenRef.current = token
    const approx =
      selectedKeyframe.rigSnapshot && typeof selectedKeyframe.rigSnapshot === "object"
        ? structuredClone(selectedKeyframe.rigSnapshot)
        : approximateEliteRigFromKeyframePositions(
            selectedKeyframe.positions,
            rig.normalizedProfile,
            configs
          )
    rig.setRig(approx)
    const logicalSynced = mapFaceRigToPose(
      rigValuesFromEliteRig(approx),
      rig.normalizedProfile,
      configs,
      rig.mapFaceRigToPoseOptions
    ).logicalPose
    committedLogicalPoseJsonRef.current = JSON.stringify(logicalSynced)
    setHasUnsavedRigPose(false)
    rig.setSelectedControlId(null)
  }, [
    selectedKeyframe,
    rig.normalizedProfile,
    configs,
    rig.mapFaceRigToPoseOptions,
    rig.setRig,
    rig.setSelectedControlId,
  ])

  const emitProject = useCallback(
    (next) => {
      onFrameProjectChange?.(normalizeFrameProject(next, configs))
    },
    [onFrameProjectChange, configs]
  )

  const flashHint = useCallback((msg) => {
    setMergeHint(msg)
    window.setTimeout(() => setMergeHint(""), 2800)
  }, [])

  const handleStopAllServos = useCallback(async () => {
    try {
      if (!webSerial.getStatus().connected) {
        flashHint("串口未连接。")
        return
      }
      await webSerial.writeText(buildStopAllCommand())
      flashHint("已发送停止全部舵机命令。")
    } catch (error) {
      flashHint(`停止失败：${error.message}`)
    }
  }, [flashHint])

  const handleWriteCurrentKeyframe = useCallback(() => {
    if (!selectedKeyframe) {
      flashHint("请先选中一个关键帧。")
      return
    }
    const nextPositions = {
      ...selectedKeyframe.positions,
      ...rig.logicalPose,
    }
    const next = updateKeyframe(
      normalizedProject,
      selectedKeyframe.keyframeId,
      { positions: nextPositions, rigSnapshot: structuredClone(rig.rig) },
      configs
    )
    emitProject(next)
    const nextPose = { ...currentPose, ...rig.logicalPose }
    onCurrentPoseChange?.(nextPose)
    flashHint("已写入当前关键帧（positions 与 logicalPose 合并）。")
    commitRigPoseBaseline()
  }, [
    selectedKeyframe,
    rig.logicalPose,
    normalizedProject,
    configs,
    emitProject,
    currentPose,
    onCurrentPoseChange,
    flashHint,
    commitRigPoseBaseline,
  ])

  const handleSaveNewKeyframe = useCallback(() => {
    const positions = { ...currentPose, ...rig.logicalPose }
    const nextFrame = createKeyframe({
      name: `关键帧 ${keyframes.length + 1}`,
      durationMs: defaultDurationMs,
      positions,
      rigSnapshot: structuredClone(rig.rig),
      configs,
    })
    const next = addKeyframe(normalizedProject, nextFrame, configs)
    emitProject(next)
    setSelectedFrameIndex(next.keyframes.length - 1)
    onCurrentPoseChange?.(createPoseFromServos(configs, positions))
    flashHint("已保存为新关键帧并选中。")
    commitRigPoseBaseline()
  }, [
    currentPose,
    rig.logicalPose,
    keyframes.length,
    defaultDurationMs,
    normalizedProject,
    configs,
    emitProject,
    onCurrentPoseChange,
    flashHint,
    commitRigPoseBaseline,
  ])

  const handleApplyRigToPoseOnly = useCallback(() => {
    const nextPose = { ...currentPose, ...rig.logicalPose }
    onCurrentPoseChange?.(createPoseFromServos(configs, nextPose))
    flashHint("已将 Face Rig 输出合并到当前姿态（未改关键帧）。")
  }, [currentPose, rig.logicalPose, configs, onCurrentPoseChange, flashHint])

  const handleApplyRigToPoseAndPush = useCallback(async () => {
    const nextPose = { ...currentPose, ...rig.logicalPose }
    onCurrentPoseChange?.(createPoseFromServos(configs, nextPose))
    await rig.pushToServo({ realtime: false })
    flashHint("已合并到当前姿态并已尝试下发。")
  }, [currentPose, rig.logicalPose, rig.pushToServo, configs, onCurrentPoseChange, flashHint])

  const handleExpressionNameChange = useCallback(
    (value) => {
      emitProject(updateExpressionName(normalizedProject, value, configs))
    },
    [normalizedProject, configs, emitProject]
  )

  const handleNewExpression = useCallback(() => {
    emitProject(createDefaultFrameProject(configs))
    setSelectedFrameIndex(0)
    flashHint("已新建表情工程。")
  }, [configs, emitProject, flashHint])

  const handleSaveProject = useCallback(() => {
    const payload = saveFrameProject(normalizedProject, configs)
    emitProject(payload)
    flashHint("表情动作已保存到浏览器本地。")
  }, [normalizedProject, configs, emitProject, flashHint])

  const handleLoadProject = useCallback(() => {
    const loaded = loadFrameProject(configs)
    emitProject(loaded)
    setSelectedFrameIndex(0)
    flashHint("已从浏览器本地加载表情动作。")
  }, [configs, emitProject, flashHint])

  const handleExportProject = useCallback(() => {
    const payload = buildFrameProjectExport(normalizedProject, servoConfigSnapshot, configs)
    const filename = buildSingleExpressionExportFilename(
      normalizedProject.expressionName,
      normalizedProject.expressionId
    )
    exportJsonFile(filename, payload)
    flashHint(`工程已导出：${filename}`)
  }, [normalizedProject, servoConfigSnapshot, configs, flashHint])

  const handleProjectImportFile = useCallback(
    (event) => {
      const file = event.target.files?.[0]
      if (!file) return
      const reader = new FileReader()
      reader.onload = () => {
        try {
          const data = JSON.parse(String(reader.result || "{}"))
          const imported = normalizeFrameProject(data, configs)
          emitProject(imported)
          setSelectedFrameIndex(0)
          flashHint(`已导入：${file.name}`)
        } catch (error) {
          flashHint(`导入失败：${error.message}`)
        } finally {
          event.target.value = ""
        }
      }
      reader.readAsText(file)
    },
    [configs, emitProject, flashHint]
  )

  const updateSelectedKeyframeMeta = useCallback(
    (patch) => {
      if (!selectedKeyframe) return
      emitProject(updateKeyframe(normalizedProject, selectedKeyframe.keyframeId, patch, configs))
    },
    [selectedKeyframe, normalizedProject, configs, emitProject]
  )

  const handleAddKeyframe = useCallback(() => {
    const nextFrame = createKeyframe({
      name: `关键帧 ${keyframes.length + 1}`,
      durationMs: defaultDurationMs,
      positions: createPoseFromServos(configs, currentPose),
      configs,
    })
    const next = addKeyframe(normalizedProject, nextFrame, configs)
    emitProject(next)
    setSelectedFrameIndex(next.keyframes.length - 1)
    flashHint("已新增关键帧。")
  }, [
    keyframes.length,
    defaultDurationMs,
    normalizedProject,
    configs,
    currentPose,
    emitProject,
    flashHint,
  ])

  const handleCopyKeyframe = useCallback(() => {
    if (!selectedKeyframe) return
    const next = copyKeyframe(normalizedProject, selectedKeyframe.keyframeId, configs)
    emitProject(next)
    setSelectedFrameIndex(Math.min(selectedFrameIndex + 1, next.keyframes.length - 1))
    flashHint("已复制关键帧。")
  }, [selectedKeyframe, normalizedProject, configs, emitProject, selectedFrameIndex, flashHint])

  const handleDeleteKeyframe = useCallback(() => {
    if (!selectedKeyframe) return
    const next = deleteKeyframe(normalizedProject, selectedKeyframe.keyframeId, configs)
    emitProject(next)
    setSelectedFrameIndex(Math.max(0, selectedFrameIndex - 1))
    flashHint("已删除关键帧。")
  }, [selectedKeyframe, normalizedProject, configs, emitProject, selectedFrameIndex, flashHint])

  const handleInsertKeyframe = useCallback(
    (offset) => {
      const targetIndex =
        selectedFrameIndex < 0 ? keyframes.length : selectedFrameIndex + offset
      const newFrame = createKeyframe({
        name: `插入帧 ${targetIndex + 1}`,
        durationMs: defaultDurationMs,
        positions: createPoseFromServos(configs, currentPose),
        configs,
      })
      const next = insertKeyframe(normalizedProject, targetIndex, newFrame, configs)
      emitProject(next)
      setSelectedFrameIndex(targetIndex)
      flashHint("已插入关键帧。")
    },
    [
      selectedFrameIndex,
      keyframes.length,
      defaultDurationMs,
      normalizedProject,
      configs,
      currentPose,
      emitProject,
      flashHint,
    ]
  )

  const handleMoveKeyframe = useCallback(
    (delta) => {
      if (selectedFrameIndex < 0) return
      const nextIndex = selectedFrameIndex + delta
      const next = moveKeyframe(normalizedProject, selectedFrameIndex, nextIndex, configs)
      emitProject(next)
      setSelectedFrameIndex(nextIndex)
    },
    [selectedFrameIndex, normalizedProject, configs, emitProject]
  )

  const handleResetFullRig = useCallback(() => {
    rig.setRig(createInitialEliteRig())
    flashHint("已重置全部面控。")
  }, [rig.setRig, flashHint])

  const handleResetEyesOnly = useCallback(() => {
    const fresh = createInitialEliteRig()
    rig.setRig((prev) => ({
      ...prev,
      browL: fresh.browL,
      browR: fresh.browR,
      eyeL: fresh.eyeL,
      eyeR: fresh.eyeR,
      sharedRadar: fresh.sharedRadar,
    }))
    flashHint("已重置眼部控件。")
  }, [rig.setRig, flashHint])

  const handleResetMouthOnly = useCallback(() => {
    const fresh = createInitialEliteRig()
    rig.setRig((prev) => ({
      ...prev,
      mouth: fresh.mouth,
      tongue: fresh.tongue,
      jaw: fresh.jaw,
    }))
    flashHint("已重置口部控件。")
  }, [rig.setRig, flashHint])

  return (
    <section className="face-expression-page">
      <div className="face-expression-upper-dock">
        <div className="face-expression-top-cluster">
          <header className="face-expression-toolbar face-expression-toolbar--merged" aria-label="表情动画编辑器工具栏">
            <label className="face-expression-toolbar-name">
              <span className="face-expression-toolbar-label">表情名称</span>
              <input
                type="text"
                value={normalizedProject.expressionName}
                onChange={(e) => handleExpressionNameChange(e.target.value)}
              />
            </label>
            <div className="face-expression-toolbar-stats">
              <span>关键帧 {keyframes.length}</span>
              <span>总时长 {totalDurationMs} ms</span>
            </div>
            <div className="face-expression-realtime-group">
              <label
                className="face-expression-realtime face-expression-realtime--compact"
                title={`开启后按「实时下发」周期节流写串口。来自 MediaPipe（Drive Rig）时使用 T=${rig.realtimeTuning.servoMoveTimeMs} ms 与 minPWMΔ=${rig.realtimeTuning.minPwmDelta}；拖动面控仍用 T=300 ms。关闭则不再自动下发。`}
              >
                <input
                  type="checkbox"
                  className="face-expression-realtime-input"
                  checked={rig.realtimePreview}
                  onChange={(e) => rig.setRealtimePreview(e.target.checked)}
                />
                <span className="face-expression-realtime-switch" aria-hidden />
                <span className="face-expression-realtime-copy">
                  <span className="face-expression-realtime-title">实时预览</span>
                  <span className="face-expression-realtime-meta">
                    串口 · ~{rig.realtimeTuning.sendIntervalMs} ms
                  </span>
                </span>
              </label>
              <label className="face-expression-send-interval">
                <span className="face-expression-send-interval-label">实时下发</span>
                <select
                  className="face-expression-send-interval-select"
                  value={rig.realtimeTuning.sendIntervalMs}
                  onChange={(e) =>
                    rig.setRealtimeTuning((prev) => ({
                      ...prev,
                      sendIntervalMs: Number(e.target.value),
                    }))
                  }
                >
                  {[30, 40, 50, 80, 100].map((ms) => (
                    <option key={ms} value={ms}>
                      {ms} ms
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <div className="face-expression-toolbar-actions">
              <button type="button" className="btn-secondary btn-tiny" onClick={handleStopAllServos}>
                停止全部舵机
              </button>
            </div>
            {rig.sendStatus ? (
              <span className="hint face-expression-toolbar-status" title={rig.sendStatus}>
                {rig.sendStatus}
              </span>
            ) : null}
          </header>

          <div className="face-expression-tracking-embed">
            <label className="face-expression-tracking-light-debug">
              <input
                type="checkbox"
                checked={lightDebugMode}
                onChange={(e) => setLightDebugMode(e.target.checked)}
              />
              <span>轻量调试模式</span>
              <span className="hint face-expression-tracking-light-debug-hint">
                开启后 Debug 刷新 {DEBUG_DISPLAY_INTERVAL_LIGHT_MS}ms、可展开 MediaPipe Debug（默认折叠）；Drive 仍为 {DRIVE_RIG_INTERVAL_MS}ms。
              </span>
            </label>
            <RightMouthFiveBarBaselineStatus compact />
            {selectedKeyframe && getKeyframeFiveBarPlaybackNote(selectedKeyframe) ? (
              <p className="hint face-expression-keyframe-fivebar-warn">
                {getKeyframeFiveBarPlaybackNote(selectedKeyframe)}
              </p>
            ) : null}
            {lightDebugMode && (rig.kinematics?.rightMouthCorner || rig.kinematics?.rightMouthCornerFivebar) ? (
              <div className="face-expression-fivebar-runtime-diag hint">
                {(() => {
                  const k = rig.kinematics.rightMouthCorner || rig.kinematics.rightMouthCornerFivebar
                  return (
                    <>
                      <strong>Right Mouth FiveBar Runtime</strong>
                      {" · "}
                      source={k.source ?? "—"} runtimeSource={k.runtimeSource ?? "—"}
                      {" · "}
                      sideR {Number(rig.rig.mouth?.sideR?.x ?? 0).toFixed(1)}/
                      {Number(rig.rig.mouth?.sideR?.y ?? 0).toFixed(1)}
                      {" · "}
                      u/v {Number(k.u ?? 0).toFixed(2)}/{Number(k.v ?? 0).toFixed(2)}
                      {" · "}
                      expOff [
                      {Array.isArray(k.expectedDOffset)
                        ? `${Number(k.expectedDOffset[0]).toFixed(2)},${Number(k.expectedDOffset[1]).toFixed(2)}`
                        : "—"}
                      ]
                      {" · "}
                      qSend {Number(k.qSend?.qA_deg ?? 0).toFixed(1)}/{Number(k.qSend?.qB_deg ?? 0).toFixed(1)}°
                      {" · "}
                      logical {k.logicalPwmA ?? "—"}/{k.logicalPwmB ?? "—"}
                      {" · "}
                      actual {k.actualPwmA ?? "—"}/{k.actualPwmB ?? "—"}
                      {" · "}
                      Kx/Ky {Number(k.effectiveKx ?? 0).toFixed(2)}/{Number(k.effectiveKy ?? 0).toFixed(2)}
                    </>
                  )
                })()}
              </div>
            ) : null}
            <FaceTrackingPanel
              key={trackingAdapterVersion}
              adapter={trackingAdapterRef.current}
              trackingEnabled={trackingEnabled}
              onTrackingEnabledChange={setTrackingEnabled}
              driveRigEnabled={driveRigEnabled}
              onDriveRigEnabledChange={setDriveRigEnabled}
              onFrame={handleTrackingFrame}
              trackingWsUrl={trackingWsUrlDraft}
              onTrackingWsUrlChange={setTrackingWsUrlDraft}
              onReplaceWithWebSocketAdapter={handleReplaceWithWebSocketTrackingAdapter}
              onTrackingClear={handleTrackingClearState}
              onResetTrackingState={handleResetTrackingState}
              showMediaPipeDebug={lightDebugMode}
              showResetStateHint={false}
              showAdapterStatusRow={false}
              compactLayout
              trackingDebug={displayTrackingFrame?.debug ?? null}
              trackingLayerFps={{
                uiDebugFps: expressionTrackingFps.uiDebugFps,
                driveRigFps: driveRigEnabled ? expressionTrackingFps.driveRigFps : null,
                servoSendFps: rig.realtimePreview ? rig.realtimeServoFps : null,
              }}
              realtimePreviewActive={rig.realtimePreview}
            />
          </div>
        </div>

        <div className="face-expression-rig-actions" aria-label="Face Rig 快捷操作">
          <div className="face-expression-rig-actions-grid">
            <div className="face-expression-rig-actions-reset-wrap">
              <div className="face-expression-rig-actions-reset">
                <button type="button" className="btn-secondary face-expression-rig-reset-btn" onClick={handleResetFullRig}>
                  重置面控
                </button>
                <button type="button" className="btn-secondary face-expression-rig-reset-btn" onClick={handleResetEyesOnly}>
                  重置眼部
                </button>
                <button type="button" className="btn-secondary face-expression-rig-reset-btn" onClick={handleResetMouthOnly}>
                  重置口部
                </button>
              </div>
            </div>
            <label className="face-expression-fivebar-overlay-toggle">
              <input
                type="checkbox"
                checked={showFiveBarReachabilityOverlay}
                onChange={(e) => setShowFiveBarReachabilityOverlay(e.target.checked)}
              />
              右嘴角 FiveBar 可达区叠加
            </label>
            <div className="face-expression-rig-actions-primary">
              <button
                type="button"
                className="btn-primary btn-tiny face-expression-rig-push"
                onClick={() => rig.pushToServo({ realtime: false })}
              >
                下发 Face Rig
              </button>
              <button
                type="button"
                className="btn-primary btn-tiny face-expression-rig-write-inline"
                onClick={handleWriteCurrentKeyframe}
              >
                写入当前帧
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="face-expression-main">
        <FaceRigControls
          variant="console"
          rigState={rig.rig}
          onRigStateChange={rig.setRig}
          setSelectedControlId={rig.setSelectedControlId}
          selectedControlId={rig.selectedControlId}
          draggingControlId={rig.draggingControlId}
          padLRef={rig.padLRef}
          padRRef={rig.padRRef}
          startVerticalScrub={rig.startVerticalScrub}
          startRadar={rig.startRadar}
          startCorner={rig.startCorner}
          radarCxPx={rig.radarCxPx}
          radarCyPx={rig.radarCyPx}
          jawPx={rig.jawPx}
          showFiveBarReachabilityOverlay={showFiveBarReachabilityOverlay}
          rightMouthPadReachabilityMap={padDebug.reachabilityMap}
          rightMouthPadEval={padDebug.currentEval}
        />

        <ExpressionFramePanel
          sideTab={sideTab}
          setSideTab={setSideTab}
          mergeHint={mergeHint}
          hasUnsavedRigPose={hasUnsavedRigPose}
          rig={rig}
          keyframes={keyframes}
          selectedKeyframe={selectedKeyframe}
          selectedFrameIndex={selectedFrameIndex}
          keyframeDurationDraft={keyframeDurationDraft}
          setKeyframeDurationDraft={setKeyframeDurationDraft}
          updateSelectedKeyframeMeta={updateSelectedKeyframeMeta}
          handleWriteCurrentKeyframe={handleWriteCurrentKeyframe}
          handleSaveNewKeyframe={handleSaveNewKeyframe}
          handleApplyRigToPoseOnly={handleApplyRigToPoseOnly}
          handleApplyRigToPoseAndPush={handleApplyRigToPoseAndPush}
          currentControlInspect={currentControlInspect}
          handleAddKeyframe={handleAddKeyframe}
          handleCopyKeyframe={handleCopyKeyframe}
          handleInsertKeyframe={handleInsertKeyframe}
          handleMoveKeyframe={handleMoveKeyframe}
          handleDeleteKeyframe={handleDeleteKeyframe}
          defaultDurationMs={defaultDurationMs}
          setDefaultDurationMs={setDefaultDurationMs}
          handleNewExpression={handleNewExpression}
          handleSaveProject={handleSaveProject}
          handleLoadProject={handleLoadProject}
          handleExportProject={handleExportProject}
          handleProjectImportFile={handleProjectImportFile}
          projectFileInputRef={projectFileInputRef}
        />
      </div>

      <div className="face-expression-bottom face-expression-timeline-dock">
        <ExpressionTimeline
          project={frameProject}
          configs={configs}
          currentPose={currentPose}
          onProjectChange={onFrameProjectChange}
          onCurrentPoseChange={onCurrentPoseChange}
          servoConfigSnapshot={servoConfigSnapshot}
          selectedFrameIndex={selectedFrameIndex}
          onSelectedFrameIndexChange={setSelectedFrameIndex}
        />
      </div>
    </section>
  )
}
