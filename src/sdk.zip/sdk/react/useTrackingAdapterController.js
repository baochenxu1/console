import { useCallback, useEffect, useRef, useState } from "react"
import { createWebSocketTrackingAdapter } from "../tracking/index.js"
import { coerceToRigFrame, normalizeRigFrameMessage } from "../tracking/trackingMapper.js"

const DEFAULT_WS = "ws://127.0.0.1:8766/tracking"

function fallbackStatus() {
  return {
    running: false,
    source: "none",
    faceDetected: false,
    fps: 0,
    rxFps: 0,
    pythonFps: /** @type {number | null} */ (null),
    rawWsFps: 0,
    parsedFrameFps: 0,
    callbackFps: 0,
    receivedMessageCount: 0,
    receivedFrameCount: 0,
    parsedFrameCount: 0,
    callbackFrameCount: 0,
    lastFrameSeq: /** @type {number | null} */ (null),
    skippedFrameCount: 0,
    lastParseMs: /** @type {number | null} */ (null),
    lastNormalizeMs: /** @type {number | null} */ (null),
    lastCallbackMs: /** @type {number | null} */ (null),
    avgPayloadBytes: 0,
    lastPayloadBytes: /** @type {number | null} */ (null),
    lastClientReceiveAtMs: /** @type {number | null} */ (null),
    lastServerSentAtMs: /** @type {number | null} */ (null),
    estimatedNetworkDelayMs: /** @type {number | null} */ (null),
    lastFrameReceivedAt: 0,
    uiDebugFps: /** @type {number | null} */ (null),
    quality: 0,
    lastFrameAt: 0,
    error: null,
  }
}

/** @param {Record<string, unknown> | null | undefined} s */
export function pickExtendedAdapterFields(s) {
  if (!s || typeof s !== "object") {
    return {}
  }
  const num = (k, d = 0) => {
    const v = s[k]
    return Number.isFinite(Number(v)) ? Number(v) : d
  }
  const numOrNull = (k) => {
    const v = s[k]
    return v != null && Number.isFinite(Number(v)) ? Number(v) : null
  }
  return {
    rawWsFps: num("rawWsFps", 0),
    parsedFrameFps: num("parsedFrameFps", 0),
    callbackFps: num("callbackFps", 0),
    receivedMessageCount: num("receivedMessageCount", 0),
    receivedFrameCount: num("receivedFrameCount", 0),
    parsedFrameCount: num("parsedFrameCount", 0),
    callbackFrameCount: num("callbackFrameCount", 0),
    lastFrameSeq: numOrNull("lastFrameSeq"),
    skippedFrameCount: num("skippedFrameCount", 0),
    lastParseMs: numOrNull("lastParseMs"),
    lastNormalizeMs: numOrNull("lastNormalizeMs"),
    lastCallbackMs: numOrNull("lastCallbackMs"),
    avgPayloadBytes: num("avgPayloadBytes", 0),
    lastPayloadBytes: numOrNull("lastPayloadBytes"),
    lastClientReceiveAtMs: numOrNull("lastClientReceiveAtMs"),
    lastServerSentAtMs: numOrNull("lastServerSentAtMs"),
    estimatedNetworkDelayMs: numOrNull("estimatedNetworkDelayMs"),
  }
}

/**
 * 映射预览等场景：管理 WebSocket TrackingAdapter、lastFrame 与轮询状态。
 * 不涉及 WebSerial、关键帧或 binding。
 */
export function useTrackingAdapterController(options = {}) {
  const defaultWsUrl = typeof options.defaultWsUrl === "string" ? options.defaultWsUrl : DEFAULT_WS

  const adapterRef = useRef(null)
  const [trackingEnabled, setTrackingEnabled] = useState(false)
  const [wsUrlDraft, setWsUrlDraft] = useState(defaultWsUrl)
  const [adapterEpoch, setAdapterEpoch] = useState(0)
  const [lastFrame, setLastFrame] = useState(
    /** @type {import("../tracking/trackingTypes.js").RigFrame | null} */ (null)
  )
  const [status, setStatus] = useState(fallbackStatus)

  const uiFrameCountRef = useRef(0)
  const uiFpsWindowStartRef = useRef(
    typeof performance !== "undefined" ? performance.now() : Date.now()
  )
  const lastComputedUiFpsRef = useRef(/** @type {number | null} */ (null))

  if (!adapterRef.current) {
    adapterRef.current = createWebSocketTrackingAdapter({ url: defaultWsUrl })
  }

  const handleFrame = useCallback((frame) => {
    uiFrameCountRef.current += 1
    const normalized = normalizeRigFrameMessage(frame) ?? coerceToRigFrame(frame)
    setLastFrame(normalized && typeof normalized === "object" ? normalized : null)
  }, [])

  useEffect(() => {
    if (!trackingEnabled) {
      uiFrameCountRef.current = 0
      lastComputedUiFpsRef.current = null
      uiFpsWindowStartRef.current =
        typeof performance !== "undefined" ? performance.now() : Date.now()
    }
  }, [trackingEnabled])

  useEffect(() => {
    const id = window.setInterval(() => {
      try {
        const now =
          typeof performance !== "undefined" ? performance.now() : Date.now()
        if (trackingEnabled) {
          const dtMs = now - uiFpsWindowStartRef.current
          if (dtMs >= 500 && dtMs > 0) {
            lastComputedUiFpsRef.current = Math.round((uiFrameCountRef.current / dtMs) * 1000)
            uiFrameCountRef.current = 0
            uiFpsWindowStartRef.current = now
          }
        } else {
          lastComputedUiFpsRef.current = null
        }

        const s = adapterRef.current?.getStatus?.()
        setStatus(
          s && typeof s === "object"
            ? {
                running: Boolean(s.running),
                source: typeof s.source === "string" ? s.source : "none",
                faceDetected: Boolean(s.faceDetected),
                fps: Number.isFinite(Number(s.fps)) ? Number(s.fps) : 0,
                rxFps: Number.isFinite(Number(s.rxFps))
                  ? Number(s.rxFps)
                  : Number.isFinite(Number(s.fps))
                    ? Number(s.fps)
                    : 0,
                pythonFps:
                  s.pythonFps != null && Number.isFinite(Number(s.pythonFps))
                    ? Number(s.pythonFps)
                    : null,
                receivedFrameCount: Number.isFinite(Number(s.receivedFrameCount))
                  ? Number(s.receivedFrameCount)
                  : 0,
                lastFrameReceivedAt: Number.isFinite(Number(s.lastFrameReceivedAt))
                  ? Number(s.lastFrameReceivedAt)
                  : 0,
                uiDebugFps: trackingEnabled ? lastComputedUiFpsRef.current : null,
                quality: Number.isFinite(Number(s.quality)) ? Number(s.quality) : 0,
                lastFrameAt: Number.isFinite(Number(s.lastFrameAt)) ? Number(s.lastFrameAt) : 0,
                error: s.error != null ? String(s.error) : null,
                ...pickExtendedAdapterFields(s),
              }
            : fallbackStatus()
        )
      } catch {
        setStatus(fallbackStatus())
      }
    }, 120)
    return () => window.clearInterval(id)
  }, [adapterEpoch, trackingEnabled])

  useEffect(() => {
    const adapter = adapterRef.current
    if (!adapter || !trackingEnabled) {
      adapter?.stop?.()
      return undefined
    }
    adapter.onFrame?.(handleFrame)
    adapter.start?.()
    return () => {
      adapter.offFrame?.(handleFrame)
      adapter.stop?.()
    }
  }, [trackingEnabled, adapterEpoch, handleFrame])

  useEffect(() => {
    return () => {
      const a = adapterRef.current
      if (a) {
        try {
          a.stop?.()
          a.dispose?.()
        } catch {
          //
        }
      }
      adapterRef.current = null
    }
  }, [])

  const replaceWithWebSocket = useCallback(() => {
    const url = String(wsUrlDraft ?? "").trim() || defaultWsUrl
    adapterRef.current?.stop?.()
    adapterRef.current?.dispose?.()
    adapterRef.current = createWebSocketTrackingAdapter({ url })
    setAdapterEpoch((n) => n + 1)
  }, [wsUrlDraft, defaultWsUrl])

  const clearLastFrame = useCallback(() => {
    setLastFrame(null)
    try {
      adapterRef.current?.clearState?.()
    } catch {
      //
    }
  }, [])

  return {
    defaultWsUrl,
    adapterRef,
    trackingEnabled,
    setTrackingEnabled,
    wsUrlDraft,
    setWsUrlDraft,
    lastFrame,
    status,
    replaceWithWebSocket,
    clearLastFrame,
  }
}
