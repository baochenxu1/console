import { buildServoMovesFromLogicalPose } from "../../core/faceDofMapper.js"
import { buildMultiServoMoveCommand } from "../../core/servoProtocol.js"

export function buildServoMovesFromPose({ logicalPose, configs, timeMs = 500 }) {
  return buildServoMovesFromLogicalPose(logicalPose, configs, timeMs)
}

export function buildServoCommandFromPose({ logicalPose, configs, timeMs = 500 }) {
  const moves = buildServoMovesFromPose({ logicalPose, configs, timeMs })
  if (!moves.length) {
    return ""
  }
  return buildMultiServoMoveCommand(moves)
}
