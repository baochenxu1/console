import {
  BINDING_RANGE_MODE_CUSTOM,
  CURVE_LINEAR,
  bindingWithRestoredEndpointsVsNeutral,
  normalizeBinding,
  normalizeFaceRigProfile,
  rangeForControlId,
} from "../../core/faceRigProfile.js"
import { SERVO_COUNT } from "../../core/servoConfig.js"
import { clampNumber, toInt } from "../../utils/clamp.js"

function uid(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`
}

export function pickUnusedServoId(bindings, preferred = 0) {
  const used = new Set((bindings || []).map((b) => b.servoId))
  for (let i = 0; i < SERVO_COUNT; i += 1) {
    const id = (preferred + i) % SERVO_COUNT
    if (!used.has(id)) {
      return id
    }
  }
  return clampNumber(toInt(preferred, 0), 0, Math.max(0, SERVO_COUNT - 1))
}

function patchBinding(bindingId, patch, binding) {
  const forcesCustom =
    Object.prototype.hasOwnProperty.call(patch, "positiveTargetPwm") ||
    Object.prototype.hasOwnProperty.call(patch, "negativeTargetPwm") ||
    Object.prototype.hasOwnProperty.call(patch, "neutralPwm")
  const nextPatch = forcesCustom ? { ...patch, rangeMode: BINDING_RANGE_MODE_CUSTOM } : patch
  return normalizeBinding({ ...binding, ...nextPatch })
}

export function addBinding(profile, binding) {
  const p = normalizeFaceRigProfile(profile)
  const nextBinding = normalizeBinding({
    bindingId: binding?.bindingId || uid("bind"),
    ...binding,
  })
  return normalizeFaceRigProfile({
    ...p,
    bindings: [...(p.bindings || []), nextBinding],
    updatedAt: new Date().toISOString(),
  })
}

export function updateBinding(profile, bindingId, patch) {
  const p = normalizeFaceRigProfile(profile)
  const nextBindings = (p.bindings || []).map((b) =>
    b.bindingId === bindingId ? patchBinding(bindingId, patch, b) : b
  )
  return normalizeFaceRigProfile({
    ...p,
    bindings: nextBindings,
    updatedAt: new Date().toISOString(),
  })
}

export function deleteBinding(profile, bindingId) {
  const p = normalizeFaceRigProfile(profile)
  return normalizeFaceRigProfile({
    ...p,
    bindings: (p.bindings || []).filter((b) => b.bindingId !== bindingId),
    updatedAt: new Date().toISOString(),
  })
}

export function duplicateBinding(profile, bindingId) {
  const p = normalizeFaceRigProfile(profile)
  const idx = p.bindings.findIndex((b) => b.bindingId === bindingId)
  if (idx < 0) {
    return p
  }
  const b = p.bindings[idx]
  const copy = normalizeBinding({
    ...b,
    bindingId: uid("bind"),
  })
  const next = [...p.bindings]
  next.splice(idx + 1, 0, copy)
  return normalizeFaceRigProfile({
    ...p,
    bindings: next,
    updatedAt: new Date().toISOString(),
  })
}

function pickServoForReversedCopy(bindings, sourceBindingId) {
  const others = new Set(bindings.filter((x) => x.bindingId !== sourceBindingId).map((x) => x.servoId))
  const b = bindings.find((x) => x.bindingId === sourceBindingId)
  if (!b) {
    return 0
  }
  if (!others.has(b.servoId)) {
    return b.servoId
  }
  for (let i = 0; i < SERVO_COUNT; i += 1) {
    if (!others.has(i)) {
      return i
    }
  }
  return b.servoId
}

export function duplicateBindingAsReverse(profile, bindingId) {
  const p = normalizeFaceRigProfile(profile)
  const idx = p.bindings.findIndex((b) => b.bindingId === bindingId)
  if (idx < 0) {
    return p
  }
  const b = p.bindings[idx]
  const servoId = pickServoForReversedCopy(p.bindings, bindingId)
  const copy = normalizeBinding({
    bindingId: uid("bind"),
    controlId: b.controlId,
    channel: b.channel,
    servoId,
    neutralPwm: b.neutralPwm,
    positiveTargetPwm: b.negativeTargetPwm,
    negativeTargetPwm: b.positiveTargetPwm,
    weight: b.weight,
    curve: b.curve,
    enabled: true,
    rangeMode: BINDING_RANGE_MODE_CUSTOM,
  })
  const next = [...p.bindings]
  next.splice(idx + 1, 0, copy)
  return normalizeFaceRigProfile({
    ...p,
    bindings: next,
    updatedAt: new Date().toISOString(),
  })
}

export function reverseBinding(profile, bindingId) {
  const p = normalizeFaceRigProfile(profile)
  const nextBindings = (p.bindings || []).map((b) =>
    b.bindingId === bindingId
      ? normalizeBinding({
          ...b,
          positiveTargetPwm: b.negativeTargetPwm,
          negativeTargetPwm: b.positiveTargetPwm,
          rangeMode: BINDING_RANGE_MODE_CUSTOM,
        })
      : b
  )
  return normalizeFaceRigProfile({
    ...p,
    bindings: nextBindings,
    updatedAt: new Date().toISOString(),
  })
}

export function restoreBindingFullRange(profile, bindingId) {
  const p = normalizeFaceRigProfile(profile)
  const nextBindings = (p.bindings || []).map((b) =>
    b.bindingId === bindingId ? bindingWithRestoredEndpointsVsNeutral(b) : b
  )
  return normalizeFaceRigProfile({
    ...p,
    bindings: nextBindings,
    updatedAt: new Date().toISOString(),
  })
}

function logicalFromContributions(bindingId, contributions) {
  const c = contributions.find((x) => x && x.bindingId === bindingId)
  const lm = c?.logicalPwm
  return Number.isFinite(lm) ? lm : null
}

export function setBindingNeutralFromContribution(profile, bindingId, contributions) {
  const lm = logicalFromContributions(bindingId, contributions)
  if (!Number.isFinite(lm)) {
    return normalizeFaceRigProfile(profile)
  }
  return updateBinding(profile, bindingId, {
    neutralPwm: Math.round(lm),
    rangeMode: BINDING_RANGE_MODE_CUSTOM,
  })
}

export function setBindingPositiveFromContribution(profile, bindingId, contributions) {
  const lm = logicalFromContributions(bindingId, contributions)
  if (!Number.isFinite(lm)) {
    return normalizeFaceRigProfile(profile)
  }
  return updateBinding(profile, bindingId, {
    positiveTargetPwm: Math.round(lm),
    rangeMode: BINDING_RANGE_MODE_CUSTOM,
  })
}

export function setBindingNegativeFromContribution(profile, bindingId, contributions) {
  const lm = logicalFromContributions(bindingId, contributions)
  if (!Number.isFinite(lm)) {
    return normalizeFaceRigProfile(profile)
  }
  return updateBinding(profile, bindingId, {
    negativeTargetPwm: Math.round(lm),
    rangeMode: BINDING_RANGE_MODE_CUSTOM,
  })
}

/** 在当前控件新增一条默认绑定（与检视器逻辑一致）：需传入 controlId、channel */
export function addBindingForControlChannel(profile, controlId, channel, options = {}) {
  const p = normalizeFaceRigProfile(profile)
  const { neutral, pos, neg } = rangeForControlId(controlId)
  const servoId = pickUnusedServoId(p.bindings, options.preferredServoId ?? 0)
  return addBinding(profile, {
    controlId,
    channel,
    servoId,
    neutralPwm: neutral,
    positiveTargetPwm: pos,
    negativeTargetPwm: neg,
    weight: 1,
    curve: CURVE_LINEAR,
    enabled: true,
    rangeMode: undefined,
    ...options.bindingOverrides,
  })
}
