import { createInitialEliteRig } from "../../core/faceDofMapper.js"
import { TRACKING_FRAME_TYPE, createEmptyRigFrame } from "./trackingTypes.js"

function clampSigned100(n) {
  return Math.max(-100, Math.min(100, Number(n) || 0))
}

function clampPct(n) {
  return Math.max(0, Math.min(100, Number(n) ?? 50))
}

function safeGazeNum(v) {
  const n = Number(v)
  if (!Number.isFinite(n)) {
    return 0
  }
  return n
}

/**
 * 将任意 JSON 中的 rig 片段归一成与 createInitialEliteRig 一致的结构。
 * @param {unknown} raw
 */
export function normalizeEliteRig(raw) {
  const base = createInitialEliteRig()
  if (!raw || typeof raw !== "object") {
    return base
  }
  const o = raw

  return {
    browL: {
      tip: clampSigned100(o.browL?.tip),
      mid: clampSigned100(o.browL?.mid),
      tail: clampSigned100(o.browL?.tail),
    },
    browR: {
      tip: clampSigned100(o.browR?.tip),
      mid: clampSigned100(o.browR?.mid),
      tail: clampSigned100(o.browR?.tail),
    },
    eyeL: {
      up: clampSigned100(o.eyeL?.up),
      lo: clampSigned100(o.eyeL?.lo),
    },
    eyeR: {
      up: clampSigned100(o.eyeR?.up),
      lo: clampSigned100(o.eyeR?.lo),
    },
    sharedRadar: {
      x: clampPct(o.sharedRadar?.x),
      y: clampPct(o.sharedRadar?.y),
    },
    mouth: {
      UL: clampSigned100(o.mouth?.UL),
      UR: clampSigned100(o.mouth?.UR),
      LL: clampSigned100(o.mouth?.LL),
      LR: clampSigned100(o.mouth?.LR),
      sideL: {
        x: clampPct(o.mouth?.sideL?.x),
        y: clampPct(o.mouth?.sideL?.y),
      },
      sideR: {
        x: clampPct(o.mouth?.sideR?.x),
        y: clampPct(o.mouth?.sideR?.y),
      },
    },
    tongue: { val: clampSigned100(o.tongue?.val) },
    jaw: { val: clampSigned100(o.jaw?.val) },
  }
}

/**
 * 校验并归一 WebSocket / 外部 JSON 为 RigFrame；不合法时返回 null。
 * @param {unknown} data
 * @returns {import("./trackingTypes.js").RigFrame | null}
 */
export function normalizeRigFrameMessage(data) {
  if (!data || typeof data !== "object") {
    return null
  }
  if (data.type !== TRACKING_FRAME_TYPE) {
    return null
  }
  const source = typeof data.source === "string" ? data.source : "unknown"
  const timestampMs = Number.isFinite(Number(data.timestampMs)) ? Number(data.timestampMs) : performance.now()
  const frameSeq = Number.isFinite(Number(data.frameSeq)) ? Number(data.frameSeq) : undefined
  const serverSentAtMs =
    data.serverSentAtMs != null && Number.isFinite(Number(data.serverSentAtMs))
      ? Number(data.serverSentAtMs)
      : undefined
  const faceDetected = data.faceDetected !== false
  const quality =
    typeof data.quality === "number" && Number.isFinite(data.quality)
      ? Math.max(0, Math.min(1, data.quality))
      : 0
  const rig = normalizeEliteRig(data.rig)

  /** @type {import("./trackingTypes.js").RigFrame["debug"] | undefined} */
  let debug
  if (data.debug && typeof data.debug === "object") {
    const b = data.debug.blendshapes
    const m = data.debug.mapping
    const blendshapes =
      b && typeof b === "object"
        ? {
            jawOpen: safeBlendNum(b.jawOpen),
            eyeBlinkLeft: safeBlendNum(b.eyeBlinkLeft),
            eyeBlinkRight: safeBlendNum(b.eyeBlinkRight),
            eyeWideLeft: safeBlendNum(b.eyeWideLeft),
            eyeWideRight: safeBlendNum(b.eyeWideRight),
            mouthSmileLeft: safeBlendNum(b.mouthSmileLeft),
            mouthSmileRight: safeBlendNum(b.mouthSmileRight),
            mouthUpperUpLeft: safeBlendNum(b.mouthUpperUpLeft),
            mouthUpperUpRight: safeBlendNum(b.mouthUpperUpRight),
            mouthLowerDownLeft: safeBlendNum(b.mouthLowerDownLeft),
            mouthLowerDownRight: safeBlendNum(b.mouthLowerDownRight),
            mouthPucker: safeBlendNum(b.mouthPucker),
            mouthFunnel: safeBlendNum(b.mouthFunnel),
            mouthClose: safeBlendNum(b.mouthClose),
            browInnerUp: safeBlendNum(b.browInnerUp),
            browOuterUpLeft: safeBlendNum(b.browOuterUpLeft),
            browOuterUpRight: safeBlendNum(b.browOuterUpRight),
          }
        : undefined
    const mapping =
      m && typeof m === "object"
        ? {
            jaw: safeMapNum(m.jaw),
            blinkLeft: safeMapNum(m.blinkLeft),
            blinkRight: safeMapNum(m.blinkRight),
            smileLeft: safeMapNum(m.smileLeft),
            smileRight: safeMapNum(m.smileRight),
            browLeft: safeMapNum(m.browLeft),
            browRight: safeMapNum(m.browRight),
            eyeOpenBiasLeft: safeMapNum(m.eyeOpenBiasLeft),
            eyeOpenBiasRight: safeMapNum(m.eyeOpenBiasRight),
            eyeLUp: safeMapNum(m.eyeLUp),
            eyeLLo: safeMapNum(m.eyeLLo),
            eyeRUp: safeMapNum(m.eyeRUp),
            eyeRLo: safeMapNum(m.eyeRLo),
            browInner: safeMapNum(m.browInner),
            browOuterLeft: safeMapNum(m.browOuterLeft),
            browOuterRight: safeMapNum(m.browOuterRight),
            browLeftTip: safeMapNum(m.browLeftTip),
            browLeftMid: safeMapNum(m.browLeftMid),
            browLeftTail: safeMapNum(m.browLeftTail),
            browRightTip: safeMapNum(m.browRightTip),
            browRightMid: safeMapNum(m.browRightMid),
            browRightTail: safeMapNum(m.browRightTail),
            upperLipLeft: safeMapNum(m.upperLipLeft),
            upperLipRight: safeMapNum(m.upperLipRight),
            lowerLipLeft: safeMapNum(m.lowerLipLeft),
            lowerLipRight: safeMapNum(m.lowerLipRight),
            mouthPucker: safeMapNum(m.mouthPucker),
            mouthFunnel: safeMapNum(m.mouthFunnel),
            ...(Number.isFinite(Number(m.eyeLookX)) ? { eyeLookX: Number(m.eyeLookX) } : {}),
            ...(Number.isFinite(Number(m.eyeLookY)) ? { eyeLookY: Number(m.eyeLookY) } : {}),
            ...(Number.isFinite(Number(m.sharedRadarX)) ? { sharedRadarX: Number(m.sharedRadarX) } : {}),
            ...(Number.isFinite(Number(m.sharedRadarY)) ? { sharedRadarY: Number(m.sharedRadarY) } : {}),
          }
        : undefined

    const gz = data.debug.gaze
    const gaze =
      gz && typeof gz === "object"
        ? {
            available: Boolean(gz.available),
            eyeLookX: safeGazeNum(gz.eyeLookX),
            eyeLookY: safeGazeNum(gz.eyeLookY),
            leftEyeX: safeGazeNum(gz.leftEyeX),
            leftEyeY: safeGazeNum(gz.leftEyeY),
            rightEyeX: safeGazeNum(gz.rightEyeX),
            rightEyeY: safeGazeNum(gz.rightEyeY),
          }
        : undefined

    const pr = data.debug && typeof data.debug === "object" ? data.debug.performance : null
    /** @type {Record<string, number | null> | undefined} */
    let performance
    if (pr && typeof pr === "object") {
      const num = (k) => {
        const v = pr[k]
        return typeof v === "number" && Number.isFinite(v) ? v : null
      }
      performance = {
        captureMs: num("captureMs"),
        capReadMs: num("capReadMs"),
        preprocessMs: num("preprocessMs"),
        inferenceMs: num("inferenceMs"),
        mappingMs: num("mappingMs"),
        broadcastMs: num("broadcastMs"),
        loopMs: num("loopMs"),
        jsonEncodeMs: num("jsonEncodeMs"),
        encodeMs: num("encodeMs"),
        sleepMs: num("sleepMs"),
        totalPeriodMs: num("totalPeriodMs"),
        targetIntervalMs: num("targetIntervalMs"),
        fps: num("fps"),
        broadcastFps: num("broadcastFps"),
        broadcastFrameSeq: num("broadcastFrameSeq"),
        captureFps: num("captureFps"),
        inferenceFps: num("inferenceFps"),
        mappingFps: num("mappingFps"),
        generatedFrameFps: num("generatedFrameFps"),
        jsonEncodeFps: num("jsonEncodeFps"),
        broadcastAttemptFps: num("broadcastAttemptFps"),
        broadcastSuccessFps: num("broadcastSuccessFps"),
        perClientSendFps: num("perClientSendFps"),
        clientCount: num("clientCount"),
        frameSeq: num("frameSeq"),
        broadcastSeq: num("broadcastSeq"),
      }
    }

    if (blendshapes || mapping || gaze || performance) {
      debug = {}
      if (blendshapes) {
        debug.blendshapes = blendshapes
      }
      if (mapping) {
        debug.mapping = mapping
      }
      if (gaze) {
        debug.gaze = gaze
      }
      if (performance) {
        debug.performance = performance
      }
    }
  }

  /** @type {import("./trackingTypes.js").RigFrame} */
  const out = {
    type: TRACKING_FRAME_TYPE,
    source,
    timestampMs,
    faceDetected,
    quality,
    rig,
    ...(debug ? { debug } : {}),
  }
  if (frameSeq !== undefined) {
    out.frameSeq = frameSeq
  }
  if (serverSentAtMs !== undefined) {
    out.serverSentAtMs = serverSentAtMs
  }
  return out
}

function safeBlendNum(v) {
  const n = Number(v)
  if (!Number.isFinite(n)) {
    return 0
  }
  return Math.max(0, Math.min(1, n))
}

function safeMapNum(v) {
  const n = Number(v)
  if (!Number.isFinite(n)) {
    return 0
  }
  return n
}

/** 容错：若无 type 但含 rig，则补上 type（便于测试网关）。 */
export function coerceToRigFrame(data) {
  const direct = normalizeRigFrameMessage(data)
  if (direct) {
    return direct
  }
  if (data && typeof data === "object" && data.rig && typeof data.rig === "object") {
    return normalizeRigFrameMessage({
      ...createEmptyRigFrame(),
      ...data,
      type: TRACKING_FRAME_TYPE,
      rig: data.rig,
    })
  }
  return null
}
