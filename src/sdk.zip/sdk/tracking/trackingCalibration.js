import { createInitialEliteRig } from "../../core/faceDofMapper.js"
import { TRACKING_FRAME_TYPE, createEmptyRigFrame } from "./trackingTypes.js"

export function createDefaultTrackingCalibration() {
  return {
    smoothing: {
      enabled: false,
      alpha: 0.6,
    },
    deadzone: {
      enabled: true,
      defaultValue: 0.03,
    },
    gains: {},
    invert: {},
  }
}

/** @param {number} prev @param {number} next @param {number} alpha */
function ema(prev, next, alpha) {
  return prev + alpha * (next - prev)
}

function applyDeadzone(prev, next, enabled, dzNorm) {
  if (!enabled) {
    return next
  }
  const thr = dzNorm * 100
  if (Math.abs(next - prev) < thr) {
    return prev
  }
  return next
}

function smoothSigned(prev, next, cal) {
  const raw = applyDeadzone(prev, next, cal.deadzone.enabled, cal.deadzone.defaultValue)
  if (!cal.smoothing.enabled) {
    return raw
  }
  return ema(prev, raw, cal.smoothing.alpha)
}

function smoothPct(prev, next, cal) {
  // 与 smoothSigned 一致：defaultValue 如 0.03 → 阈值 3（0~100 轴上约 3 个百分点）。
  // 勿再 * 100，否则 thr=300 会导致嘴角 / radar 等百分比通道永远锁在上一帧。
  const raw = applyDeadzone(prev, next, cal.deadzone.enabled, cal.deadzone.defaultValue)
  if (!cal.smoothing.enabled) {
    return raw
  }
  return ema(prev, raw, cal.smoothing.alpha)
}

/** @param {ReturnType<typeof createInitialEliteRig>} prevRig @param {ReturnType<typeof createInitialEliteRig>} nextRig @param {ReturnType<typeof createDefaultTrackingCalibration>} cal */
function smoothRig(prevRig, nextRig, cal) {
  const p = prevRig
  const n = nextRig
  return {
    browL: {
      tip: smoothSigned(p.browL.tip, n.browL.tip, cal),
      mid: smoothSigned(p.browL.mid, n.browL.mid, cal),
      tail: smoothSigned(p.browL.tail, n.browL.tail, cal),
    },
    browR: {
      tip: smoothSigned(p.browR.tip, n.browR.tip, cal),
      mid: smoothSigned(p.browR.mid, n.browR.mid, cal),
      tail: smoothSigned(p.browR.tail, n.browR.tail, cal),
    },
    eyeL: {
      up: smoothSigned(p.eyeL.up, n.eyeL.up, cal),
      lo: smoothSigned(p.eyeL.lo, n.eyeL.lo, cal),
    },
    eyeR: {
      up: smoothSigned(p.eyeR.up, n.eyeR.up, cal),
      lo: smoothSigned(p.eyeR.lo, n.eyeR.lo, cal),
    },
    sharedRadar: {
      x: smoothPct(p.sharedRadar.x, n.sharedRadar.x, cal),
      y: smoothPct(p.sharedRadar.y, n.sharedRadar.y, cal),
    },
    mouth: {
      UL: smoothSigned(p.mouth.UL, n.mouth.UL, cal),
      UR: smoothSigned(p.mouth.UR, n.mouth.UR, cal),
      LL: smoothSigned(p.mouth.LL, n.mouth.LL, cal),
      LR: smoothSigned(p.mouth.LR, n.mouth.LR, cal),
      sideL: {
        x: smoothPct(p.mouth.sideL.x, n.mouth.sideL.x, cal),
        y: smoothPct(p.mouth.sideL.y, n.mouth.sideL.y, cal),
      },
      sideR: {
        x: smoothPct(p.mouth.sideR.x, n.mouth.sideR.x, cal),
        y: smoothPct(p.mouth.sideR.y, n.mouth.sideR.y, cal),
      },
    },
    tongue: { val: smoothSigned(p.tongue.val, n.tongue.val, cal) },
    jaw: { val: smoothSigned(p.jaw.val, n.jaw.val, cal) },
  }
}

/** 不修改入参 frame；返回新 RigFrame。 */
export function applyTrackingCalibration(frame, previousFrame, calibration) {
  const cal = calibration ?? createDefaultTrackingCalibration()

  const passthroughDebug =
    frame && typeof frame === "object" && frame.debug !== undefined && frame.debug !== null
      ? frame.debug
      : undefined

  if (!frame.faceDetected) {
    if (previousFrame) {
      return {
        ...previousFrame,
        type: TRACKING_FRAME_TYPE,
        timestampMs: frame.timestampMs,
        source: frame.source,
        faceDetected: false,
        quality: frame.quality,
        ...(passthroughDebug !== undefined ? { debug: passthroughDebug } : {}),
      }
    }
    const neutral = createEmptyRigFrame()
    return {
      ...neutral,
      source: frame.source,
      timestampMs: frame.timestampMs,
      faceDetected: false,
      quality: frame.quality,
      rig: createInitialEliteRig(),
      ...(passthroughDebug !== undefined ? { debug: passthroughDebug } : {}),
    }
  }

  const prevRig = previousFrame?.rig ?? createInitialEliteRig()
  const smoothed = smoothRig(prevRig, frame.rig, cal)

  return {
    type: TRACKING_FRAME_TYPE,
    source: frame.source,
    timestampMs: frame.timestampMs,
    faceDetected: true,
    quality: frame.quality,
    rig: smoothed,
    ...(passthroughDebug !== undefined ? { debug: passthroughDebug } : {}),
  }
}
