import { useCallback, useEffect, useMemo, useState } from "react"
import { buildStopAllCommand } from "../core/servoProtocol.js"
import { webSerial } from "../core/webSerial.js"
import {
  DRIVE_MODES,
  DEVICE_DRIVE_ARM_CONFIRM_MESSAGE,
  TRACKING_DEVICE_DRIVE_STOP_DEFAULTS,
  TRACKING_PREVIEW_TABS,
} from "../sdk/trackingPreview/trackingPreviewConstants.js"
import TrackingPreviewHeader from "../sdk/react/trackingPreview/TrackingPreviewHeader.jsx"
import LeftSourceColumn from "../sdk/react/trackingPreview/LeftSourceColumn.jsx"
import CameraPreviewPanel from "../sdk/react/trackingPreview/CameraPreviewPanel.jsx"
import VideoPreviewPanel from "../sdk/react/trackingPreview/VideoPreviewPanel.jsx"
import MotionTrackPanel from "../sdk/react/trackingPreview/MotionTrackPanel.jsx"
import FaceRigPreviewCard from "../sdk/react/trackingPreview/FaceRigPreviewCard.jsx"
import TrackingPreviewDeveloperDebug from "../sdk/react/trackingPreview/TrackingPreviewDeveloperDebug.jsx"
import { useTrackingPreviewCamera } from "../sdk/react/trackingPreview/useTrackingPreviewCamera.js"
import { useTrackingPreviewDeviceDrive } from "../sdk/react/trackingPreview/useTrackingPreviewDeviceDrive.js"
import { sendTrackingPreviewCenterServos } from "../sdk/trackingPreview/sendTrackingPreviewCenterServos.js"
import { isDeveloperDebugEnabled } from "../utils/developerDebug.js"
import "../styles/face-rig.css"
import "../styles/tracking-preview.css"

/**
 * Tracking Preview — Camera + Device Drive V1（全通道）。
 */
export default function TrackingPreviewPage({ configs = [] }) {
  const [activeTab, setActiveTab] = useState(
    /** @type {import("../sdk/trackingPreview/trackingPreviewConstants.js").TrackingPreviewTabId} */ (
      TRACKING_PREVIEW_TABS.CAMERA
    )
  )
  const [driveMode, setDriveMode] = useState(
    /** @type {import("../sdk/trackingPreview/trackingPreviewConstants.js").TrackingPreviewDriveMode} */ (
      DRIVE_MODES.PREVIEW_ONLY
    )
  )
  const [deviceDriveArmed, setDeviceDriveArmed] = useState(false)
  const [showDeveloperDebug] = useState(() => isDeveloperDebugEnabled())
  const [baudRate, setBaudRate] = useState(115200)
  const [lastCommand, setLastCommand] = useState("")
  const [lastSerialError, setLastSerialError] = useState("")
  const [stopBusy, setStopBusy] = useState(false)

  const camera = useTrackingPreviewCamera({
    configs,
    activeTab,
    driveMode,
  })

  const disarmDeviceDrive = useCallback(() => {
    setDeviceDriveArmed(false)
    setDriveMode((m) => (m === DRIVE_MODES.DEVICE_DRIVE ? DRIVE_MODES.PREVIEW_ONLY : m))
  }, [])

  const deviceDrive = useTrackingPreviewDeviceDrive({
    driveMode,
    deviceDriveArmed,
    previewRig: camera.previewRig,
    profile: camera.profile,
    configs,
    trackingStatus: camera.trackingStatus,
    cameraRunning: camera.cameraRunning,
    onCommandSent: setLastCommand,
    onSerialError: setLastSerialError,
  })

  const centerHardwareToNeutral = useCallback(
    async () => {
      try {
        const result = await sendTrackingPreviewCenterServos({
          profile: camera.profile,
          configs,
          baudRate,
        })
        if (result.ok) {
          setLastCommand(result.command)
          setLastSerialError("")
        } else if (result.reason === "not-connected") {
          setLastSerialError("串口未连接，舵机未能回中")
        } else if (result.reason === "empty-command") {
          setLastSerialError("无有效回中命令（检查绑定）")
        }
      } catch (e) {
        setLastSerialError(e?.message || String(e))
      }
    },
    [camera.profile, configs, baudRate]
  )

  const handleStopCameraTracking = useCallback(async () => {
    if (stopBusy) {
      return
    }
    setStopBusy(true)
    const wasDeviceDrive =
      deviceDriveArmed && driveMode === DRIVE_MODES.DEVICE_DRIVE
    deviceDrive.beginStopSequence?.()
    disarmDeviceDrive()
    setLastCommand("Stopping... Returning device to neutral...")
    try {
      if (wasDeviceDrive && TRACKING_DEVICE_DRIVE_STOP_DEFAULTS.stopReturnNeutralEnabled) {
        const mode = TRACKING_DEVICE_DRIVE_STOP_DEFAULTS.stopReturnNeutralMode
        if (mode === "face-neutral" || mode === "both") {
          const result = await sendTrackingPreviewCenterServos({
            profile: camera.profile,
            configs,
            baudRate,
            timeMs: TRACKING_DEVICE_DRIVE_STOP_DEFAULTS.stopReturnNeutralTimeMs,
          })
          if (result.ok) {
            setLastCommand("Camera stopped · Device neutral command sent")
            setLastSerialError("")
            const holdMs = Number(TRACKING_DEVICE_DRIVE_STOP_DEFAULTS.stopNeutralHoldMs) || 0
            if (holdMs > 0) {
              await new Promise((resolve) => window.setTimeout(resolve, holdMs))
            }
          } else if (result.reason === "not-connected") {
            setLastCommand("Camera stopped · Serial offline, neutral skipped")
          } else {
            setLastSerialError(`Neutral command failed: ${result.reason || "unknown"}`)
          }
        }
      }
    } finally {
      camera.stopCameraTracking()
      deviceDrive.endStopSequence?.()
      setStopBusy(false)
    }
  }, [
    stopBusy,
    deviceDrive,
    deviceDriveArmed,
    driveMode,
    camera,
    disarmDeviceDrive,
    configs,
    baudRate,
  ])

  const handleTabChange = useCallback(
    async (tabId) => {
      const wasDeviceDrive =
        deviceDriveArmed && driveMode === DRIVE_MODES.DEVICE_DRIVE
      setActiveTab(tabId)
      camera.stopCameraTracking()
      disarmDeviceDrive()
      if (wasDeviceDrive) {
        await centerHardwareToNeutral()
      }
    },
    [deviceDriveArmed, driveMode, camera, disarmDeviceDrive, centerHardwareToNeutral]
  )

  const handleDriveModeChange = useCallback((mode) => {
    if (mode === DRIVE_MODES.DEVICE_DRIVE) {
      if (driveMode === DRIVE_MODES.DEVICE_DRIVE && deviceDriveArmed) {
        return
      }
      const ok = window.confirm(DEVICE_DRIVE_ARM_CONFIRM_MESSAGE)
      if (!ok) {
        return
      }
      setDriveMode(DRIVE_MODES.DEVICE_DRIVE)
      setDeviceDriveArmed(true)
      return
    }
    setDeviceDriveArmed(false)
    setDriveMode(mode)
  }, [driveMode, deviceDriveArmed])

  const handleStopAllServo = useCallback(async () => {
    deviceDrive.beginStopSequence?.()
    disarmDeviceDrive()
    camera.stopCameraTracking()
    try {
      const st = webSerial.getStatus()
      if (!st.connected) {
        const opened = await webSerial.tryOpen({ baudRate: Number(baudRate) || 115200 })
        if (!opened) {
          setLastSerialError("串口未连接")
          return
        }
      }
      const stopCmd = buildStopAllCommand()
      await webSerial.writeText(stopCmd)
      await centerHardwareToNeutral()
      setLastCommand(stopCmd)
      setLastSerialError("")
    } catch (e) {
      setLastSerialError(e?.message || String(e))
    } finally {
      deviceDrive.endStopSequence?.()
    }
  }, [baudRate, camera, disarmDeviceDrive, centerHardwareToNeutral, deviceDrive])

  useEffect(() => {
    const prev = webSerial.onStatus
    webSerial.onStatus = (s) => {
      if (!s?.connected && deviceDriveArmed) {
        disarmDeviceDrive()
      }
      if (typeof prev === "function") {
        prev(s)
      }
    }
    return () => {
      webSerial.onStatus = prev
    }
  }, [deviceDriveArmed, disarmDeviceDrive])

  const deviceDriveNote = useMemo(() => {
    if (driveMode !== DRIVE_MODES.DEVICE_DRIVE) {
      return ""
    }
    const parts = []
    if (deviceDriveArmed) {
      parts.push("ARMED")
    }
    if (deviceDrive.sendFps != null) {
      parts.push(`tx ${deviceDrive.sendFps} fps`)
    }
    if (!deviceDrive.gates.canSend && deviceDrive.gates.note) {
      parts.push(deviceDrive.gates.note)
    } else if (deviceDrive.lastSkipReason) {
      parts.push(deviceDrive.lastSkipReason)
    }
    return parts.join(" · ")
  }, [driveMode, deviceDriveArmed, deviceDrive])

  const mappingDryRunResult = useMemo(() => {
    if (driveMode === DRIVE_MODES.DRY_RUN) {
      return camera.dryRunResult
    }
    if (driveMode === DRIVE_MODES.DEVICE_DRIVE && deviceDrive.uiDryRunResult) {
      return deviceDrive.uiDryRunResult
    }
    return camera.dryRunResult
  }, [driveMode, camera.dryRunResult, deviceDrive.uiDryRunResult])

  const sourcePanel = (() => {
    if (activeTab === TRACKING_PREVIEW_TABS.CAMERA) {
      return (
        <CameraPreviewPanel
          trackingEnabled={camera.cameraRunning}
          trackingStatus={camera.trackingStatus}
          onStart={camera.startCameraTracking}
          onStop={handleStopCameraTracking}
          showWsUrl={showDeveloperDebug}
          wsUrlDraft={camera.ctrl.wsUrlDraft}
          onWsUrlChange={camera.ctrl.setWsUrlDraft}
          onApplyWs={camera.ctrl.replaceWithWebSocket}
          wsUrl={camera.ctrl.wsUrlDraft}
        />
      )
    }
    if (activeTab === TRACKING_PREVIEW_TABS.VIDEO) {
      return <VideoPreviewPanel />
    }
    return <MotionTrackPanel />
  })()

  const deviceDriveActive = driveMode === DRIVE_MODES.DEVICE_DRIVE && deviceDriveArmed

  return (
    <section
      className={`tp-monitor${deviceDriveActive ? " tp-monitor--device-drive" : ""}${
        showDeveloperDebug ? " tp-monitor--dev" : ""
      }`}
    >
      <TrackingPreviewHeader
        activeTab={activeTab}
        onTabChange={handleTabChange}
        driveMode={driveMode}
        onDriveModeChange={handleDriveModeChange}
        deviceDriveArmed={deviceDriveArmed}
        deviceDriveNote={deviceDriveNote}
        baudRate={baudRate}
        onBaudRateChange={setBaudRate}
        lastCommand={lastCommand}
        lastError={lastSerialError}
        onStopAllServo={handleStopAllServo}
      />

      <div className="tracking-preview-grid">
        <div className="grid-column grid-column--left">
          <LeftSourceColumn
            activeTab={activeTab}
            sourcePanel={sourcePanel}
            previewRig={camera.previewRig}
            mapping={camera.mapping}
            lipGeometry={camera.lipGeometry}
            jawGeometry={camera.jawGeometry}
            showDeveloperDebug={showDeveloperDebug}
            cameraRunning={camera.cameraRunning}
            onSetLipNeutral={camera.requestLipNeutral}
            driveMode={driveMode}
            dryRunResult={mappingDryRunResult}
          />
        </div>

        <div className="grid-column grid-column--rig">
          <FaceRigPreviewCard rig={camera.previewRig} deviceDriveActive={deviceDriveActive} />
        </div>
      </div>

      {showDeveloperDebug ? (
        <TrackingPreviewDeveloperDebug
          className="tp-monitor-dev-overlay"
          lastFrame={camera.ctrl.lastFrame}
          calibratedFrame={camera.calibratedFrame}
          wsUrlDraft={camera.ctrl.wsUrlDraft}
          status={camera.ctrl.status}
          cameraRunning={camera.cameraRunning}
          onSetLipNeutral={camera.requestLipNeutral}
        />
      ) : null}
    </section>
  )
}
