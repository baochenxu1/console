import { useEffect, useMemo, useRef, useState } from "react"

function exportJsonFile(filename, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json;charset=utf-8" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

/**
 * @param {object} props
 * @param {import("../../tracking/trackingTypes.js").RigFrame | null} props.lastFrame
 * @param {import("../../tracking/trackingTypes.js").RigFrame | null} props.calibratedFrame
 * @param {string} props.wsUrlDraft
 * @param {object} props.status
 */
export default function TrackingPreviewDeveloperDebug({
  className = "",
  lastFrame,
  calibratedFrame,
  wsUrlDraft,
  status,
  onSetLipNeutral,
  cameraRunning = false,
}) {
  const mapv = lastFrame?.debug?.mapping
  const lipGeo = lastFrame?.debug?.lipGeometry
  const [recording, setRecording] = useState(false)
  const [recordUntil, setRecordUntil] = useState(0)
  const jawBufferRef = useRef([])

  useEffect(() => {
    if (!lastFrame?.timestampMs) return
    const jg = lastFrame?.debug?.jawGeometry
    const lg = lastFrame?.debug?.lipGeometry
    if (!jg) return
    const item = {
      timestamp: Number(lastFrame.timestampMs) || Date.now(),
      quality: Number(lastFrame.quality) || 0,
      pose: jg.pose || null,
      poseGate: jg.poseGate || null,
      aperture: Number(jg.current?.aperture) || 0,
      lowerInnerY: Number(jg.current?.lowerInnerY) || 0,
      lowerLipCenterY: Number(jg.current?.lowerLipCenterY) || 0,
      jawInput: Number(jg.raw) || Number(jg.curve?.beforeCurve) || 0,
      afterCurve: Number(jg.curved) || Number(jg.curve?.afterCurve) || 0,
      jawSmooth: Number(jg.jawSmooth) || Number(jg.stabilizer?.smooth) || 0,
      lipUpper: (Number(lg?.deltaSmooth?.upperL) + Number(lg?.deltaSmooth?.upperR)) * 0.5 || 0,
      lipLower: (Number(lg?.deltaSmooth?.lowerL) + Number(lg?.deltaSmooth?.lowerR)) * 0.5 || 0,
      rigWriteJaw: Number(jg?.rigWrite?.jaw ?? jg?.rigWrite) || 0,
    }
    jawBufferRef.current.push(item)
    const cutoff = item.timestamp - 8000
    jawBufferRef.current = jawBufferRef.current.filter((x) => x.timestamp >= cutoff)
  }, [lastFrame])

  useEffect(() => {
    if (!recording) return
    const now = Date.now()
    if (now < recordUntil) return
    const rows = jawBufferRef.current.filter((x) => x.timestamp >= now - 5000)
    exportJsonFile(`jaw-debug-5s-${now}.json`, { durationMs: 5000, frames: rows })
    setRecording(false)
  }, [lastFrame, recording, recordUntil])

  const jawSummary = useMemo(() => {
    const rows = jawBufferRef.current
    if (!rows.length) return "Jaw buffer: 0"
    const last = rows[rows.length - 1]
    return `Jaw buffer: ${rows.length} | last input=${(last.jawInput || 0).toFixed(2)} curve=${(last.afterCurve || 0).toFixed(2)} smooth=${(last.jawSmooth || 0).toFixed(2)}`
  }, [lastFrame])

  return (
    <details className={`tracking-preview-dev-debug tp-dev-debug${className ? ` ${className}` : ""}`}>
      <summary>Developer Debug</summary>
      <div className="tracking-preview-dev-debug-body">
        <p className="hint">
          开启方式：<code>localStorage facedev.showDeveloperDebug=1</code> 或 URL <code>?debug=1</code>
        </p>
        <p className="tracking-preview-status-grid">
          <span>WS: {wsUrlDraft}</span>
          <span>adapter running: {status?.running ? "yes" : "no"}</span>
        </p>
        {cameraRunning && typeof onSetLipNeutral === "function" ? (
          <p>
            <button type="button" className="tp-btn tp-btn--secondary" onClick={onSetLipNeutral}>
              Set Mouth Neutral
            </button>
            <span className="hint">
              {" "}
              — 自然闭嘴约 1 秒；neutralReady={lipGeo?.neutralReady ? "yes" : "no"}
            </span>
          </p>
        ) : null}
        <p>
          <button
            type="button"
            className="tp-btn tp-btn--secondary"
            onClick={() => {
              const now = Date.now()
              const rows = jawBufferRef.current.filter((x) => x.timestamp >= now - 3000)
              exportJsonFile(`jaw-debug-snapshot-${now}.json`, { durationMs: 3000, frames: rows })
            }}
          >
            Export Jaw Debug Snapshot
          </button>
          <button
            type="button"
            className="tp-btn tp-btn--secondary"
            style={{ marginLeft: 8 }}
            onClick={() => {
              setRecording(true)
              setRecordUntil(Date.now() + 5000)
            }}
          >
            {recording ? "Recording Jaw Debug..." : "Record Jaw Debug 5s"}
          </button>
          <span className="hint"> {jawSummary}</span>
        </p>
        <details>
          <summary>raw tracking.rigFrame</summary>
          <pre className="tracking-preview-json">
            {lastFrame ? JSON.stringify(lastFrame, null, 2) : "暂无"}
          </pre>
        </details>
        <details>
          <summary>calibrated frame</summary>
          <pre className="tracking-preview-json">
            {calibratedFrame ? JSON.stringify(calibratedFrame, null, 2) : "暂无"}
          </pre>
        </details>
        <details>
          <summary>debug.mapping JSON</summary>
          <pre className="tracking-preview-json">
            {mapv ? JSON.stringify(mapv, null, 2) : "暂无"}
          </pre>
        </details>
        <details>
          <summary>rawFrameRig JSON</summary>
          <pre className="tracking-preview-json">
            {lastFrame?.rig ? JSON.stringify(lastFrame.rig, null, 2) : "暂无"}
          </pre>
        </details>
      </div>
    </details>
  )
}
