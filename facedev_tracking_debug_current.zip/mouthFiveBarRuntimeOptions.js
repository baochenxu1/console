import { getLeftMouthFiveBarRuntime } from "./leftMouthFiveBarRuntime.js"
import { getRightMouthFiveBarRuntime } from "./rightMouthFiveBarRuntime.js"

function mouthRuntimeKinematicsSlice(rt) {
  return {
    enabled: rt.enabled,
    runtimeOutputMode: rt.runtime.outputMode,
    ...rt.params,
  }
}

/**
 * @param {{ rightState: import("./mouthCornerFivebar.js").RightMouthFivebarState, leftState: import("./mouthCornerFivebar.js").RightMouthFivebarState }} states
 */
export function buildMapFaceRigToPoseOptionsFromMouthRuntimes({ rightState, leftState }) {
  const rightRt = getRightMouthFiveBarRuntime()
  const leftRt = getLeftMouthFiveBarRuntime()
  return {
    rightMouthCornerFivebarState: rightState,
    leftMouthCornerFivebarState: leftState,
    rightMouthRuntime: rightRt,
    leftMouthRuntime: leftRt,
    mouthFiveBarRuntimes: {
      right: rightRt,
      left: leftRt,
    },
    mouthFiveBarStates: {
      right: rightState,
      left: leftState,
    },
    kinematics: {
      rightMouthCornerFiveBar: mouthRuntimeKinematicsSlice(rightRt),
      leftMouthCornerFiveBar: mouthRuntimeKinematicsSlice(leftRt),
    },
  }
}

/**
 * @param {import("./mouthCornerFivebar.js").RightMouthFivebarState} fiveBarState
 */
export function buildMapFaceRigToPoseOptionsFromRuntime(fiveBarState) {
  return buildMapFaceRigToPoseOptionsFromMouthRuntimes({
    rightState: fiveBarState,
    leftState: fiveBarState,
  })
}
