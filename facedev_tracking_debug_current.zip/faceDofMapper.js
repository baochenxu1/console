import { clampNumber } from "../utils/clamp.js"
import {
  SERVO_LOGICAL_MIN_PWM,
  SERVO_LOGICAL_MAX_PWM,
  STANDARD_CENTER_PWM,
  getServoConfig,
  logicalToActualPwm,
} from "./servoConfig.js"
import {
  CHANNEL_X,
  CHANNEL_Y,
  CURVE_LINEAR,
  CURVE_SMOOTHSTEP,
  resolveBindingTargetsForEvaluate,
} from "./faceRigProfile.js"
import {
  applyFaceRigKinematicsOverrides,
  computeMouthCornerFiveBarIk,
  contributionExcludedForMouthFiveBar,
  resolveLeftMouthCornerKinematics,
  resolveRightMouthCornerKinematics,
} from "../sdk/kinematics/mouthCornerKinematics.js"
import { getMouthCornerLabSide } from "../sdk/kinematics/mouthCornerFiveBarLabConfig.js"
import { getLeftMouthFiveBarRuntime } from "../sdk/kinematics/leftMouthFiveBarRuntime.js"
import { getRightMouthFiveBarRuntime } from "../sdk/kinematics/rightMouthFiveBarRuntime.js"

export function mergePose(basePose = {}, overlayLogicalByServoId = {}) {
  return {
    ...basePose,
    ...overlayLogicalByServoId,
  }
}

export function channelRawToDriver(raw, channelSpec) {
  const mode = channelSpec?.mode || "signed100"
  let n = Number(raw)

  const lo = channelSpec?.rawMin
  const hi = channelSpec?.rawMax
  if (Number.isFinite(lo)) {
    n = Math.max(lo, n)
  }
  if (Number.isFinite(hi)) {
    n = Math.min(hi, n)
  }

  if (mode === "percent") {
    return clampNumber((n - 50) / 50, -1, 1)
  }

  return clampNumber(n / 100, -1, 1)
}

export function evaluateBindingLogical(driver, binding) {
  const w = clampNumber(binding.weight ?? 1, 0, 4)
  let u = clampNumber(driver * w, -1, 1)

  const curve = binding.curve || CURVE_LINEAR
  const sign = u >= 0 ? 1 : -1
  let mag = Math.abs(u)
  if (curve === CURVE_SMOOTHSTEP) {
    mag = mag * mag * (3 - 2 * mag)
  }
  u = sign * mag

  const { neutralPwm: n, positiveTargetPwm: pos, negativeTargetPwm: neg } =
    resolveBindingTargetsForEvaluate(binding)

  let pwm = u >= 0 ? n + u * (pos - n) : n + u * (n - neg)
  pwm = Math.round(pwm)
  return clampNumber(pwm, SERVO_LOGICAL_MIN_PWM, SERVO_LOGICAL_MAX_PWM)
}

/**
 * @param {object[]} contributions
 * @param {string[]} warnings
 * @returns {Record<string, number>}
 */
function mergeContributionsToLogicalPose(contributions, warnings) {
  const byServo = new Map()
  for (const c of contributions) {
    const sid = c.servoId
    if (!byServo.has(sid)) {
      byServo.set(sid, [])
    }
    byServo.get(sid).push(c)
  }

  const logicalPose = {}

  for (const [sid, list] of byServo) {
    if (!Array.isArray(list) || list.length === 0) {
      continue
    }

    const baseNeutral = clampNumber(
      list[0]?.neutralPwm ?? STANDARD_CENTER_PWM,
      SERVO_LOGICAL_MIN_PWM,
      SERVO_LOGICAL_MAX_PWM
    )

    const neutralSet = new Set(list.map((item) => item.neutralPwm))

    if (neutralSet.size > 1) {
      warnings.push(
        `舵机 ${sid}：多条绑定的 neutralPwm 不一致，当前使用 ${baseNeutral} 作为合成基准。`
      )
    }

    const offsetSum = list.reduce((acc, item) => acc + item.deltaFromNeutral, 0)

    const merged =
      list.length === 1
        ? list[0].logicalPwm
        : baseNeutral + offsetSum

    logicalPose[String(sid)] = clampNumber(
      Math.round(merged),
      SERVO_LOGICAL_MIN_PWM,
      SERVO_LOGICAL_MAX_PWM
    )

    if (list.length > 1) {
      warnings.push(
        `舵机 ${sid}：${list.length} 条绑定；逻辑脉宽 = ${baseNeutral} + 增量之和（${offsetSum}）= ${logicalPose[String(sid)]}`
      )
    }
  }

  return logicalPose
}

function logicalPoseToActualPose(logicalPose, configs, warnings) {
  const actualPose = {}
  const cfgList = Array.isArray(configs) ? configs : []
  for (const [key, logical] of Object.entries(logicalPose)) {
    const servoId = Number(key)
    const cfg = getServoConfig(cfgList, servoId)
    if (cfg.enabled === false) {
      warnings.push(`舵机 ${key}：未启用，跳过实际脉宽映射`)
      continue
    }
    const r = logicalToActualPwm(logical, cfg)
    actualPose[key] = r.actualPwm
  }
  return actualPose
}

/**
 * @param {object} rigValues
 * @param {object} profile
 * @param {object[]} [configs]
 * @param {{
 *   kinematics?: object,
 *   rightMouthCornerFivebarState?: { qPrev: number[], lastOk: boolean, lastDiagnostics: object | null },
 *   leftMouthCornerFivebarState?: { qPrev: number[], lastOk: boolean, lastDiagnostics: object | null },
 *   rightMouthRuntime?: object,
 *   leftMouthRuntime?: object,
 * }} [options]
 */
export function mapFaceRigToPose(rigValues, profile, configs = [], options = {}) {
  const warnings = []
  const contributions = []
  const controlsById = new Map((profile.controls || []).map((c) => [c.controlId, c]))

  for (const binding of profile.bindings || []) {
    if (!binding.enabled) {
      continue
    }

    const ctrl = controlsById.get(binding.controlId)
    if (!ctrl) {
      warnings.push(`绑定 ${binding.bindingId}：未知控件 ${binding.controlId}`)
      continue
    }

    const spec = ctrl.channels?.[binding.channel]
    if (!spec) {
      warnings.push(`绑定 ${binding.bindingId}：控件 ${binding.controlId} 无通道 ${binding.channel}`)
      continue
    }

    const raw = rigValues[binding.controlId]?.[binding.channel]
    if (raw === undefined || raw === null || Number.isNaN(Number(raw))) {
      warnings.push(`绑定 ${binding.bindingId}：缺少数值 ${binding.controlId}.${binding.channel}`)
      continue
    }

    const driver = channelRawToDriver(raw, spec)
    const logicalPwm = evaluateBindingLogical(driver, binding)

    contributions.push({
      bindingId: binding.bindingId,
      controlId: binding.controlId,
      channel: binding.channel,
      servoId: binding.servoId,
      neutralPwm: binding.neutralPwm,
      logicalPwm,
      deltaFromNeutral: logicalPwm - binding.neutralPwm,
    })
  }

  const rightRt = options?.rightMouthRuntime ?? getRightMouthFiveBarRuntime()
  const leftRt = options?.leftMouthRuntime ?? getLeftMouthFiveBarRuntime()
  const rightResolved = resolveRightMouthCornerKinematics(profile, {
    runtimeParams: rightRt.params,
    runtimeBindingOverride: rightRt.bindingOverride,
    kinematics: options?.kinematics,
    runtimeSource: rightRt.source,
  })
  const leftResolved = resolveLeftMouthCornerKinematics(profile, {
    runtimeParams: leftRt.params,
    runtimeBindingOverride: leftRt.bindingOverride,
    kinematics: options?.kinematics,
    runtimeSource: leftRt.source,
  })

  const contribsForFiveBarMerge = contributions.filter((c) => {
    if (contributionExcludedForMouthFiveBar(c, rightResolved)) {
      return false
    }
    if (contributionExcludedForMouthFiveBar(c, leftResolved)) {
      return false
    }
    return true
  })

  /** @type {Record<string, object>} */
  const kinematics = {}
  const logicalPose = mergeContributionsToLogicalPose(contribsForFiveBarMerge, warnings)
  const actualPose = logicalPoseToActualPose(logicalPose, configs, warnings)
  const pose = {
    logicalPose,
    actualPose,
    contributions,
    warnings,
    kinematics,
  }

  const mouthSides = [
    {
      sideId: /** @type {const} */ ("right"),
      resolved: rightResolved,
      rt: rightRt,
      state:
        options?.rightMouthCornerFivebarState ?? options?.mouthFiveBarStates?.right,
    },
    {
      sideId: /** @type {const} */ ("left"),
      resolved: leftResolved,
      rt: leftRt,
      state: options?.leftMouthCornerFivebarState ?? options?.mouthFiveBarStates?.left,
    },
  ]

  for (const { sideId, resolved, rt, state } of mouthSides) {
    const side = getMouthCornerLabSide(sideId)
    if (!resolved.enabled) {
      pose.kinematics[sideId === "left" ? "leftMouthCorner" : "rightMouthCorner"] = {
        enabled: false,
        overrideNote: "",
        ikOk: null,
        ikMessage: "",
      }
      continue
    }
    if (!resolved.readyForIk) {
      if (resolved.skipReason) {
        pose.warnings.push(resolved.skipReason)
      }
      const skipDiag = {
        enabled: true,
        readyForIk: false,
        overrideNote: "",
        ikOk: null,
        ikMessage: resolved.skipReason || "未就绪",
        servoAId: resolved.servoAId,
        servoBId: resolved.servoBId,
      }
      if (sideId === "left") {
        pose.kinematics.leftMouthCorner = skipDiag
        pose.kinematics.leftMouthCornerFivebar = skipDiag
      } else {
        pose.kinematics.rightMouthCorner = skipDiag
        pose.kinematics.rightMouthCornerFivebar = skipDiag
      }
      continue
    }

    const ik = computeMouthCornerFiveBarIk(rigValues, resolved, state, sideId)
    if (ik.ok) {
      if (ik.diagnostics?.scale != null && Number(ik.diagnostics.scale) < 0.8) {
        pose.warnings.push(
          `${side.label}五杆：scale=${Number(ik.diagnostics.scale).toFixed(3)} < 0.8（D_target 已强钳位），输出可能偏离 Pad 意图`
        )
      }
      applyFaceRigKinematicsOverrides({
        rig: rigValues,
        profile,
        configs,
        pose,
        sideId,
        kinematics: options?.kinematics,
        ikResult: ik,
        rightMouthRuntime: sideId === "right" ? rt : undefined,
        leftMouthRuntime: sideId === "left" ? rt : undefined,
        rightMouthCornerFivebarState: sideId === "right" ? state : undefined,
        leftMouthCornerFivebarState: sideId === "left" ? state : undefined,
      })
    } else {
      pose.warnings.push(`${side.label}五杆 IK：${ik.message}`)
      if (sideId === "left") {
        pose.kinematics.leftMouthCorner = ik.diagnostics
        pose.kinematics.leftMouthCornerFivebar = ik.diagnostics
      } else {
        pose.kinematics.rightMouthCorner = ik.diagnostics
        pose.kinematics.rightMouthCornerFivebar = ik.diagnostics
      }
    }
  }

  const kinOut = pose.kinematics || {}
  if (kinOut.rightMouthCorner && !kinOut.rightMouthCornerFivebar) {
    kinOut.rightMouthCornerFivebar = kinOut.rightMouthCorner
  }
  if (kinOut.leftMouthCorner && !kinOut.leftMouthCornerFivebar) {
    kinOut.leftMouthCornerFivebar = kinOut.leftMouthCorner
  }

  return {
    logicalPose: pose.logicalPose,
    actualPose: pose.actualPose,
    contributions,
    warnings: pose.warnings,
    kinematics: kinOut,
  }
}

export function buildServoMovesFromLogicalPose(logicalPose, configs, timeMs = 500) {
  if (!Array.isArray(configs)) {
    return []
  }

  const moves = []

  for (const [idStr, logical] of Object.entries(logicalPose)) {
    const servoId = Number(idStr)
    const cfg = getServoConfig(configs, servoId)
    if (cfg.enabled === false) {
      continue
    }

    const r = logicalToActualPwm(logical, cfg)

    moves.push({
      servoId,
      pwm: r.actualPwm,
      timeMs,
      minPwm: cfg.actualMinPwm,
      maxPwm: cfg.actualMaxPwm,
    })
  }

  return moves
}

export function createInitialEliteRig() {
  return {
    browL: { tip: 0, mid: 0, tail: 0 },
    browR: { tip: 0, mid: 0, tail: 0 },
    eyeL: { up: 0, lo: 0 },
    eyeR: { up: 0, lo: 0 },
    sharedRadar: { x: 50, y: 50 },
    mouth: {
      UL: 0,
      UR: 0,
      LL: 0,
      LR: 0,
      sideL: { x: 50, y: 50 },
      sideR: { x: 50, y: 50 },
    },
    tongue: { val: 0 },
    jaw: { val: 0 },
  }
}

export function rigValuesFromEliteRig(rig) {
  if (!rig || typeof rig !== "object") {
    return {}
  }

  const rx = rig.sharedRadar?.x ?? 50
  const ry = rig.sharedRadar?.y ?? 50

  return {
    brow_l_tip: { value: rig.browL?.tip ?? 0 },
    brow_l_mid: { value: rig.browL?.mid ?? 0 },
    brow_l_tail: { value: rig.browL?.tail ?? 0 },
    brow_r_tip: { value: rig.browR?.tip ?? 0 },
    brow_r_mid: { value: rig.browR?.mid ?? 0 },
    brow_r_tail: { value: rig.browR?.tail ?? 0 },
    eye_l_up: { value: rig.eyeL?.up ?? 0 },
    eye_l_lo: { value: rig.eyeL?.lo ?? 0 },
    eye_r_up: { value: rig.eyeR?.up ?? 0 },
    eye_r_lo: { value: rig.eyeR?.lo ?? 0 },
    eye_xy: { x: rx, y: ry },
    mouth_ul: { value: rig.mouth?.UL ?? 0 },
    mouth_ur: { value: rig.mouth?.UR ?? 0 },
    mouth_ll: { value: rig.mouth?.LL ?? 0 },
    mouth_lr: { value: rig.mouth?.LR ?? 0 },
    mouth_corner_l: { x: rig.mouth?.sideL?.x ?? 50, y: rig.mouth?.sideL?.y ?? 50 },
    mouth_corner_r: { x: rig.mouth?.sideR?.x ?? 50, y: rig.mouth?.sideR?.y ?? 50 },
    tongue: { value: rig.tongue?.val ?? 0 },
    jaw: { value: rig.jaw?.val ?? 0 },
  }
}

function invertDriverForTargetLogicalPwm(targetPwm, binding) {
  const t = clampNumber(targetPwm, SERVO_LOGICAL_MIN_PWM, SERVO_LOGICAL_MAX_PWM)
  let best = 0
  let bestErr = Infinity
  for (let i = 0; i <= 72; i += 1) {
    const d = -1 + (2 * i) / 72
    const got = evaluateBindingLogical(d, binding)
    const err = Math.abs(got - t)
    if (err < bestErr) {
      bestErr = err
      best = d
    }
  }
  return best
}

function driverToChannelRawForSpec(driver, channelSpec) {
  const mode = channelSpec?.mode || "signed100"
  const u = clampNumber(driver, -1, 1)
  let raw = mode === "percent" ? 50 + u * 50 : u * 100
  const lo = channelSpec?.rawMin
  const hi = channelSpec?.rawMax
  if (Number.isFinite(lo)) {
    raw = Math.max(lo, raw)
  }
  if (Number.isFinite(hi)) {
    raw = Math.min(hi, raw)
  }
  return raw
}

function clampSigned100ish(n) {
  return Math.round(clampNumber(Number(n) || 0, -100, 100))
}

function clampPct100(n) {
  return clampNumber(Number(n) ?? 50, 0, 100)
}

/** 将单通道 raw 写回 elite rig 状态（与 FaceRigControlConsole 数据结构一致） */
export function setEliteRigControlRaw(rig, controlId, channel, rawNumeric) {
  return patchEliteFromControlChannel(rig, controlId, channel, rawNumeric)
}

function patchEliteFromControlChannel(rig, controlId, channel, rawNumeric) {
  const r = Number(rawNumeric)
  switch (controlId) {
    case "brow_l_tip":
      return { ...rig, browL: { ...rig.browL, tip: clampSigned100ish(r) } }
    case "brow_l_mid":
      return { ...rig, browL: { ...rig.browL, mid: clampSigned100ish(r) } }
    case "brow_l_tail":
      return { ...rig, browL: { ...rig.browL, tail: clampSigned100ish(r) } }
    case "brow_r_tip":
      return { ...rig, browR: { ...rig.browR, tip: clampSigned100ish(r) } }
    case "brow_r_mid":
      return { ...rig, browR: { ...rig.browR, mid: clampSigned100ish(r) } }
    case "brow_r_tail":
      return { ...rig, browR: { ...rig.browR, tail: clampSigned100ish(r) } }
    case "eye_l_up":
      return { ...rig, eyeL: { ...rig.eyeL, up: clampSigned100ish(r) } }
    case "eye_l_lo":
      return { ...rig, eyeL: { ...rig.eyeL, lo: clampSigned100ish(r) } }
    case "eye_r_up":
      return { ...rig, eyeR: { ...rig.eyeR, up: clampSigned100ish(r) } }
    case "eye_r_lo":
      return { ...rig, eyeR: { ...rig.eyeR, lo: clampSigned100ish(r) } }
    case "mouth_ul":
      return { ...rig, mouth: { ...rig.mouth, UL: clampSigned100ish(r) } }
    case "mouth_ur":
      return { ...rig, mouth: { ...rig.mouth, UR: clampSigned100ish(r) } }
    case "mouth_ll":
      return { ...rig, mouth: { ...rig.mouth, LL: clampSigned100ish(r) } }
    case "mouth_lr":
      return { ...rig, mouth: { ...rig.mouth, LR: clampSigned100ish(r) } }
    case "tongue":
      return { ...rig, tongue: { val: clampSigned100ish(r) } }
    case "jaw":
      return { ...rig, jaw: { val: clampSigned100ish(r) } }
    case "mouth_corner_l": {
      const sideL = { ...rig.mouth?.sideL }
      if (channel === CHANNEL_X) sideL.x = clampPct100(r)
      else if (channel === CHANNEL_Y) sideL.y = clampPct100(r)
      return { ...rig, mouth: { ...rig.mouth, sideL } }
    }
    case "mouth_corner_r": {
      const sideR = { ...rig.mouth?.sideR }
      if (channel === CHANNEL_X) sideR.x = clampPct100(r)
      else if (channel === CHANNEL_Y) sideR.y = clampPct100(r)
      return { ...rig, mouth: { ...rig.mouth, sideR } }
    }
    case "eye_xy": {
      const radar = { ...rig.sharedRadar }
      if (channel === CHANNEL_X) radar.x = clampPct100(r)
      else if (channel === CHANNEL_Y) radar.y = clampPct100(r)
      return { ...rig, sharedRadar: radar }
    }
    default:
      return rig
  }
}

function eyeRadarTotalError(rigTry, profile, configs, targetByServo, eyeBindings) {
  if (!eyeBindings.length) {
    return 0
  }
  const { logicalPose } = mapFaceRigToPose(rigValuesFromEliteRig(rigTry), profile, configs)
  let e = 0
  for (const b of eyeBindings) {
    const tid = targetByServo[String(b.servoId)]
    if (tid === undefined || tid === null) {
      continue
    }
    const got = logicalPose[String(b.servoId)]
    if (got === undefined || got === null) {
      continue
    }
    e += (Number(got) - Number(tid)) ** 2
  }
  return e
}

function refineEyeRadarFromTargets(rig, profile, configs, targetByServo) {
  const eyeBindings = (profile.bindings || []).filter((b) => b.enabled && b.controlId === "eye_xy")
  if (!eyeBindings.length) {
    return rig
  }
  let rx = clampPct100(rig.sharedRadar?.x ?? 50)
  let ry = clampPct100(rig.sharedRadar?.y ?? 50)
  const baseRig = rig
  const deltas = [-12, -8, -5, -3, -1, 0, 1, 3, 5, 8, 12]
  for (let iter = 0; iter < 48; iter += 1) {
    let bestRx = rx
    let bestErr = eyeRadarTotalError({ ...baseRig, sharedRadar: { x: rx, y: ry } }, profile, configs, targetByServo, eyeBindings)
    for (const d of deltas) {
      const nx = clampPct100(rx + d)
      const err = eyeRadarTotalError({ ...baseRig, sharedRadar: { x: nx, y: ry } }, profile, configs, targetByServo, eyeBindings)
      if (err < bestErr) {
        bestErr = err
        bestRx = nx
      }
    }
    rx = bestRx
    let bestRy = ry
    bestErr = eyeRadarTotalError({ ...baseRig, sharedRadar: { x: rx, y: ry } }, profile, configs, targetByServo, eyeBindings)
    for (const d of deltas) {
      const ny = clampPct100(ry + d)
      const err = eyeRadarTotalError({ ...baseRig, sharedRadar: { x: rx, y: ny } }, profile, configs, targetByServo, eyeBindings)
      if (err < bestErr) {
        bestErr = err
        bestRy = ny
      }
    }
    ry = bestRy
  }
  return { ...baseRig, sharedRadar: { x: rx, y: ry } }
}

/**
 * 根据关键帧中存储的舵机逻辑脉宽，反推 elite rig 控件状态，使时间轴选中关键帧后面部控件与 poses 大致一致。
 * 多绑定合成的舵机只做近似；eye_xy 用小步交替搜索。
 */
export function approximateEliteRigFromKeyframePositions(positions = {}, profile, configs = []) {
  let rig = createInitialEliteRig()
  const controlsById = new Map((profile.controls || []).map((c) => [c.controlId, c]))
  const bindings = (profile.bindings || []).filter((b) => b.enabled)

  const targetByServo = {}
  const posObj = positions && typeof positions === "object" ? positions : {}
  for (const key of Object.keys(posObj)) {
    const pwm = Number(posObj[key])
    if (Number.isFinite(pwm)) {
      targetByServo[String(key)] = clampNumber(pwm, SERVO_LOGICAL_MIN_PWM, SERVO_LOGICAL_MAX_PWM)
    }
  }

  const clusters = new Map()
  for (const b of bindings) {
    const k = `${b.controlId}\t${b.channel}`
    if (!clusters.has(k)) clusters.set(k, [])
    clusters.get(k).push(b)
  }

  const skippedMultiNonEye = []

  for (const [, binds] of clusters) {
    const b0 = binds[0]
    const { controlId, channel } = b0
    if (controlId === "eye_xy" && (channel === CHANNEL_X || channel === CHANNEL_Y) && binds.length > 1) {
      continue
    }
    if (binds.length !== 1) {
      skippedMultiNonEye.push(binds)
      continue
    }
    const pwmT = targetByServo[String(b0.servoId)]
    if (pwmT === undefined || pwmT === null) {
      continue
    }
    const ctrl = controlsById.get(controlId)
    if (!ctrl) {
      continue
    }
    const spec = ctrl.channels?.[channel]
    if (!spec) {
      continue
    }
    const driver = invertDriverForTargetLogicalPwm(pwmT, b0)
    const raw = driverToChannelRawForSpec(driver, spec)
    rig = patchEliteFromControlChannel(rig, controlId, channel, raw)
  }

  for (const binds of skippedMultiNonEye) {
    const b0 = binds[0]
    const pwmT = targetByServo[String(b0.servoId)]
    if (pwmT === undefined || pwmT === null) {
      continue
    }
    const ctrl = controlsById.get(b0.controlId)
    if (!ctrl) {
      continue
    }
    const spec = ctrl.channels?.[b0.channel]
    if (!spec) {
      continue
    }
    const driver = invertDriverForTargetLogicalPwm(pwmT, b0)
    const raw = driverToChannelRawForSpec(driver, spec)
    rig = patchEliteFromControlChannel(rig, b0.controlId, b0.channel, raw)
  }

  rig = refineEyeRadarFromTargets(rig, profile, configs, targetByServo)
  return rig
}
