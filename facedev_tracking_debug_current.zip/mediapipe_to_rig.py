"""
MediaPipe FaceLandmarkerResult → Elite Rig JSON（与前端 createInitialEliteRig / normalizeEliteRig 兼容）。
仅做数值映射；无舵机、无绑定。
阶段 2.5：blendshape / mapping / gaze（iris→sharedRadar）调试输出；眨眼仍用 blendshape，与视线分离。
jaw：`invert` 为语义强度取负写入 signed `jaw.val`；微笑见嘴角映射；机械方向以 Binding 为准。
"""

from __future__ import annotations

import math
import time
from typing import Any, Iterable

from mediapipe_mapping_config import (
    apply_deadzone,
    apply_gain,
    apply_invert_signed,
    apply_invert_unipolar,
    clamp,
    create_default_mapping_config,
    normalize_mapping_config,
)


def _safe_float(v: Any, fallback: float = 0.0) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return fallback
    if math.isnan(x) or math.isinf(x):
        return fallback
    return x


def _clamp_pct(v: float) -> float:
    return max(0.0, min(100.0, _safe_float(v, 0.0)))


def _clamp_signed100(v: float) -> float:
    """与前端 `clampSigned100ish` 一致：jaw.val ∈ [-100, 100]。"""
    return max(-100.0, min(100.0, _safe_float(v, 0.0)))


def create_neutral_rig() -> dict[str, Any]:
    """等价于前端 createInitialEliteRig() 的中性姿态。"""
    return {
        "browL": {"tip": 0.0, "mid": 0.0, "tail": 0.0},
        "browR": {"tip": 0.0, "mid": 0.0, "tail": 0.0},
        "eyeL": {"up": 0.0, "lo": 0.0},
        "eyeR": {"up": 0.0, "lo": 0.0},
        "sharedRadar": {"x": 50.0, "y": 50.0},
        "mouth": {
            "UL": 0.0,
            "UR": 0.0,
            "LL": 0.0,
            "LR": 0.0,
            "sideL": {"x": 50.0, "y": 50.0},
            "sideR": {"x": 50.0, "y": 50.0},
        },
        "tongue": {"val": 0.0},
        "jaw": {"val": 0.0},
    }


def _normalized_blend_key(name: str) -> str:
    return "".join(ch for ch in str(name).lower() if ch.isalnum())


def _iter_classification_entries(classification_list: Any) -> Iterable[tuple[str, float]]:
    """
    mediapipe ClassificationList：通常为 repeated Classification，
    字段名在不同版本可能是 category / classifications / classification。
    """
    if classification_list is None:
        return
    blob = (
        getattr(classification_list, "categories", None)
        or getattr(classification_list, "classifications", None)
        or getattr(classification_list, "classification", None)
        or getattr(classification_list, "category", None)
    )
    if blob is not None:
        for c in blob:
            nm = (
                getattr(c, "category_name", None)
                or getattr(c, "display_name", None)
                or getattr(c, "label", None)
                or ""
            )
            sc = getattr(c, "score", None)
            if nm:
                yield str(nm), _safe_float(sc, 0.0)
        return
    try:
        for c in classification_list:
            nm = (
                getattr(c, "category_name", None)
                or getattr(c, "display_name", None)
                or getattr(c, "label", None)
                or ""
            )
            sc = getattr(c, "score", None)
            if nm:
                yield str(nm), _safe_float(sc, 0.0)
    except TypeError:
        return


def _build_blendshape_lookup(result: Any) -> dict[str, float]:
    """首个人脸 blendshape → 归一化小写键与原始键均可查。"""
    scores: dict[str, float] = {}
    fbs = getattr(result, "face_blendshapes", None)
    if not fbs:
        return scores
    try:
        first_face_bs = list(fbs)[0]
    except (TypeError, IndexError):
        return scores

    for name, sc in _iter_classification_entries(first_face_bs):
        scores[name] = sc
        scores[_normalized_blend_key(name)] = sc
    return scores


def blendshape_entry_count(result: Any) -> int:
    fbs = getattr(result, "face_blendshapes", None)
    if not fbs:
        return 0
    try:
        first_face_bs = list(fbs)[0]
    except (TypeError, IndexError):
        return 0
    return sum(1 for _ in _iter_classification_entries(first_face_bs))


def get_blendshape_score(result: Any, name: str, default: float = 0.0) -> float:
    """
    从 FaceLandmarkerResult 读取指定 blendshape 分数；不存在则 default。
    兼容 category_name 大小写 / 下划线变体。
    """
    lut = _build_blendshape_lookup(result)
    if name in lut:
        return _safe_float(lut[name], default)
    nk = _normalized_blend_key(name)
    if nk in lut:
        return _safe_float(lut[nk], default)
    for alt in (name.replace("_", ""), name.lower(), name.upper()):
        if alt in lut:
            return _safe_float(lut[alt], default)
        a2 = _normalized_blend_key(alt)
        if a2 in lut:
            return _safe_float(lut[a2], default)
    return _safe_float(default, 0.0)


def landmarks_to_jaw_open(_landmarks: Any) -> float:
    return 0.0


def landmarks_to_mouth_corners(_landmarks: Any) -> tuple[float, float, float, float]:
    return 0.0, 0.0, 0.0, 0.0


def landmarks_to_blink(_landmarks: Any) -> tuple[float, float]:
    return 0.0, 0.0


def extract_landmarks(result: Any) -> list[Any] | None:
    """首张脸的 landmark 列表；失败或不存在返回 None。"""
    try:
        lm = getattr(result, "face_landmarks", None)
        if lm is None:
            return None
        faces = list(lm)
        if not faces:
            return None
        first = faces[0]
        pts = list(first)
        return pts
    except Exception:
        return None


def get_landmark_xy(landmarks: Any, index: int) -> tuple[float, float] | None:
    """读取单个归一化 landmark 的 (x,y)；索引越界或无效返回 None。"""
    try:
        if landmarks is None or index < 0:
            return None
        seq = list(landmarks)
        if index >= len(seq):
            return None
        p = seq[index]
        x = getattr(p, "x", None)
        y = getattr(p, "y", None)
        if x is None and isinstance(p, dict):
            x = p.get("x")
            y = p.get("y")
        if x is None and isinstance(p, (list, tuple)) and len(p) >= 2:
            x, y = p[0], p[1]
        xf = float(x)
        yf = float(y)
        if math.isnan(xf) or math.isnan(yf) or math.isinf(xf) or math.isinf(yf):
            return None
        return xf, yf
    except Exception:
        return None


def create_neutral_gaze() -> dict[str, Any]:
    """gaze 不可用时 debug.gaze 的占位结构。"""
    return {
        "available": False,
        "stable": False,
        "frozenByBlink": False,
        "heldLastValid": False,
        "limitedByMaxStep": False,
        "irisReliable": False,
        "freezeReason": "",
        "candidateSharedRadarX": None,
        "candidateSharedRadarY": None,
        "emittedSharedRadarX": 50.0,
        "emittedSharedRadarY": 50.0,
        "lastValidSharedRadarX": None,
        "lastValidSharedRadarY": None,
        "leftEyeHalfWidth": 0.0,
        "leftEyeHalfHeight": 0.0,
        "rightEyeHalfWidth": 0.0,
        "rightEyeHalfHeight": 0.0,
        "eyeBlinkLeftRaw": 0.0,
        "eyeBlinkRightRaw": 0.0,
        "blinkLeftMapping": 0.0,
        "blinkRightMapping": 0.0,
        "eyeLookX": 0.0,
        "eyeLookY": 0.0,
        "leftEyeX": 0.0,
        "leftEyeY": 0.0,
        "rightEyeX": 0.0,
        "rightEyeY": 0.0,
        "sharedRadarX": 50.0,
        "sharedRadarY": 50.0,
    }


def estimate_eye_gaze_from_landmarks(result: Any, config: dict[str, Any]) -> dict[str, Any]:
    """
    基于 iris + 眼眶参考点的简单几何视线（归一化图像坐标，约 [-1,1]）。
    无 landmarks / 点数不足 / 计算失败时 gazeAvailable=false，不抛异常。
    """
    out = create_neutral_gaze()
    try:
        gaze_cfg = config.get("gaze") if isinstance(config.get("gaze"), dict) else {}
        if not bool(gaze_cfg.get("enabled", True)):
            return out
        if not bool(gaze_cfg.get("preferIrisLandmarks", True)):
            return out

        lm = extract_landmarks(result)
        if not lm or len(lm) < 478:
            return out

        left_iris: list[tuple[float, float]] = []
        for i in range(468, 473):
            xy = get_landmark_xy(lm, i)
            if xy:
                left_iris.append(xy)
        right_iris: list[tuple[float, float]] = []
        for i in range(473, 478):
            xy = get_landmark_xy(lm, i)
            if xy:
                right_iris.append(xy)
        if len(left_iris) < 2 or len(right_iris) < 2:
            return out

        licx = sum(p[0] for p in left_iris) / len(left_iris)
        licy = sum(p[1] for p in left_iris) / len(left_iris)
        ricx = sum(p[0] for p in right_iris) / len(right_iris)
        ricy = sum(p[1] for p in right_iris) / len(right_iris)

        # 左眼 inner/outer/upper/lower（常见 FaceMesh 索引）
        left_idx = {"inner": 133, "outer": 33, "upper": 159, "lower": 145}
        right_idx = {"inner": 362, "outer": 263, "upper": 386, "lower": 374}

        min_extent = max(1e-6, _safe_float(gaze_cfg.get("minIrisEyeHalfExtent"), 0.003))

        def one_eye(
            idx: dict[str, int], iris_cx: float, iris_cy: float
        ) -> tuple[float, float, float, float] | None:
            inner = get_landmark_xy(lm, idx["inner"])
            outer = get_landmark_xy(lm, idx["outer"])
            upper = get_landmark_xy(lm, idx["upper"])
            lower = get_landmark_xy(lm, idx["lower"])
            if not inner or not outer or not upper or not lower:
                return None
            ecx = (inner[0] + outer[0]) * 0.5
            ecy = (inner[1] + outer[1]) * 0.5
            half_w = abs(inner[0] - outer[0]) * 0.5
            half_h = abs(lower[1] - upper[1]) * 0.5
            if half_w < 1e-6 or half_h < 1e-6:
                return None
            ex = (iris_cx - ecx) / half_w
            ey = (iris_cy - ecy) / half_h
            ex = max(-1.0, min(1.0, ex))
            ey = max(-1.0, min(1.0, ey))
            return ex, ey, float(half_w), float(half_h)

        le = one_eye(left_idx, licx, licy)
        re = one_eye(right_idx, ricx, ricy)
        if le is None or re is None:
            return out

        fuse_x = (le[0] + re[0]) * 0.5
        fuse_y = (le[1] + re[1]) * 0.5
        min_l = min(le[2], le[3])
        min_r = min(re[2], re[3])
        iris_reliable = bool(min_l >= min_extent and min_r >= min_extent)
        out["available"] = True
        out["irisReliable"] = iris_reliable
        out["leftEyeHalfWidth"] = float(le[2])
        out["leftEyeHalfHeight"] = float(le[3])
        out["rightEyeHalfWidth"] = float(re[2])
        out["rightEyeHalfHeight"] = float(re[3])
        out["leftEyeX"] = float(le[0])
        out["leftEyeY"] = float(le[1])
        out["rightEyeX"] = float(re[0])
        out["rightEyeY"] = float(re[1])
        out["eyeLookX"] = float(fuse_x)
        out["eyeLookY"] = float(fuse_y)
        return out
    except Exception:
        return create_neutral_gaze()


_DEBUG_BLEND_KEYS = (
    "jawOpen",
    "eyeBlinkLeft",
    "eyeBlinkRight",
    "eyeWideLeft",
    "eyeWideRight",
    "mouthSmileLeft",
    "mouthSmileRight",
    "mouthUpperUpLeft",
    "mouthUpperUpRight",
    "mouthLowerDownLeft",
    "mouthLowerDownRight",
    "mouthPucker",
    "mouthFunnel",
    "mouthClose",
    "browInnerUp",
    "browOuterUpLeft",
    "browOuterUpRight",
)


def extract_debug_blendshapes(result: Any) -> dict[str, float]:
    """原始 blendshape 0~1 附近；缺失为 0；无 NaN。"""
    out: dict[str, float] = {}
    for key in _DEBUG_BLEND_KEYS:
        if key == "jawOpen":
            jaw_open = max(
                get_blendshape_score(result, "jawOpen"),
                get_blendshape_score(result, "jaw_open"),
            )
            out["jawOpen"] = _safe_float(jaw_open, 0.0)
        else:
            out[key] = _safe_float(get_blendshape_score(result, key, 0.0), 0.0)
    return out


def _semantic_strength_base(
    centered: float,
    *,
    
    deadzone_thr: float,
    gain: float,
    lim_lo: float,
    lim_hi: float,
) -> float:
    """减 neutral 后的量 → deadzone / gain / ×100 → clamp 到 [lim_lo, lim_hi]，不含 invert。"""
    x = apply_deadzone(centered, deadzone_thr)
    x = apply_gain(x, gain)
    x = x * 100.0
    return clamp(x, lim_lo, lim_hi)


def _pipe_unipolar_strength(
    centered: float,
    *,
    deadzone_thr: float,
    gain: float,
    invert: bool,
    lim_lo: float,
    lim_hi: float,
) -> float:
    """
    语义强度落在 [lim_lo, lim_hi]（常为 0~100）后，invert 在**同一单极区间**内做反射：min+max−v。
    用于 blink / smile / brow 等仍须以非负强度喂给后续公式的通道；**jaw 勿用本函数**，见下。
    """
    x = _semantic_strength_base(
        centered,
        deadzone_thr=deadzone_thr,
        gain=gain,
        lim_lo=lim_lo,
        lim_hi=lim_hi,
    )
    return apply_invert_unipolar(x, invert, lim_lo, lim_hi)


def _norm_brow_slot(name: Any, fallback: str) -> str:
    s = str(name or fallback).strip().lower()
    return s if s in ("tip", "tail") else fallback


def _apply_gaze_shared_radar(
    *,
    rig: dict[str, Any],
    mapping: dict[str, float],
    gaze_dbg: dict[str, Any],
    blend: dict[str, float],
    blink_l: float,
    blink_r: float,
    cfg: dict[str, Any],
    gaze_state: dict[str, Any] | None,
    neutral: dict[str, Any],
    gains: dict[str, Any],
    invert: dict[str, Any],
    deadzone: dict[str, Any],
    limits: dict[str, Any],
) -> None:
    """
    候选 gaze → 可用性 / iris / 眨眼 → emitted；支持 disableGuardForDebug 全旁路。
    """
    lim_x = limits.get("eyeLookX", [30.0, 70.0])
    lim_y = limits.get("eyeLookY", [30.0, 70.0])
    lo_x, hi_x = _safe_float(lim_x[0], 30.0), _safe_float(lim_x[1], 70.0)
    lo_y, hi_y = _safe_float(lim_y[0], 30.0), _safe_float(lim_y[1], 70.0)

    st = gaze_state if gaze_state is not None else {}
    if "last_emit" not in st:
        st["last_emit"] = {"x": 50.0, "y": 50.0}
    lemit = st["last_emit"]
    lx0 = _clamp_pct(_safe_float(lemit.get("x"), 50.0))
    ly0 = _clamp_pct(_safe_float(lemit.get("y"), 50.0))

    gz = cfg.get("gaze") if isinstance(cfg.get("gaze"), dict) else {}
    guard_off = bool(gz.get("disableGuardForDebug", False))
    freeze_on = bool(gz.get("freezeOnBlink", True))
    eff_freeze = bool(freeze_on and not guard_off)
    raw_thr = _safe_float(gz.get("blinkFreezeThreshold"), 0.75)
    map_thr = _safe_float(gz.get("blinkMappingFreezeThreshold"), 70.0)
    max_step = max(0.0, _safe_float(gz.get("maxStepPerFrame"), 12.0))

    raw_l = _safe_float(blend.get("eyeBlinkLeft"), 0.0)
    raw_r = _safe_float(blend.get("eyeBlinkRight"), 0.0)
    gaze_dbg["eyeBlinkLeftRaw"] = float(raw_l)
    gaze_dbg["eyeBlinkRightRaw"] = float(raw_r)
    gaze_dbg["blinkLeftMapping"] = float(blink_l)
    gaze_dbg["blinkRightMapping"] = float(blink_r)

    gaze_avail = bool(gaze_dbg.get("available"))
    iris_ok = bool(gaze_dbg.get("irisReliable", True)) if gaze_avail else False

    cand_x: float | None = None
    cand_y: float | None = None
    gx1 = 0.0
    gy1 = 0.0
    if gaze_avail:
        gx0 = _safe_float(gaze_dbg.get("eyeLookX"), 0.0) - _safe_float(neutral.get("eyeLookX"), 0.0)
        gy0 = _safe_float(gaze_dbg.get("eyeLookY"), 0.0) - _safe_float(neutral.get("eyeLookY"), 0.0)
        dz_g = _safe_float(deadzone.get("eyeLook"), 0.03)
        gx1 = apply_deadzone(gx0, dz_g)
        gy1 = apply_deadzone(gy0, dz_g)
        gx1 = apply_gain(gx1, _safe_float(gains.get("eyeLookX"), 1.0))
        gy1 = apply_gain(gy1, _safe_float(gains.get("eyeLookY"), 1.0))
        gx1 = apply_invert_signed(gx1, bool(invert.get("eyeLookX")))
        gy1 = apply_invert_signed(gy1, bool(invert.get("eyeLookY")))
        cand_x = float(clamp(50.0 + gx1 * 50.0, lo_x, hi_x))
        cand_y = float(clamp(50.0 + gy1 * 50.0, lo_y, hi_y))

    gaze_dbg["candidateSharedRadarX"] = cand_x
    gaze_dbg["candidateSharedRadarY"] = cand_y

    last_valid: dict[str, Any] | None = st.get("last_valid")

    freeze_reason = ""
    frozen_by_blink = False
    held_last = False
    limited_by_step = False
    emit_x = 50.0
    emit_y = 50.0
    map_ex = None
    map_ey = None

    def _emit(rx: float, ry: float, mex: float | None, mey: float | None) -> None:
        nonlocal emit_x, emit_y, map_ex, map_ey
        emit_x = _clamp_pct(rx)
        emit_y = _clamp_pct(ry)
        map_ex = mex
        map_ey = mey

    # ----- 调试旁路：candidate 直通 rig -----
    if guard_off:
        freeze_reason = ""
        frozen_by_blink = False
        held_last = False
        limited_by_step = False
        if gaze_avail and cand_x is not None and cand_y is not None:
            _emit(cand_x, cand_y, float(gx1), float(gy1))
            st["last_valid"] = {
                "x": float(emit_x),
                "y": float(emit_y),
                "eyeLookX": float(gx1),
                "eyeLookY": float(gy1),
                "updatedAt": float(time.time()),
            }
        elif last_valid is not None:
            _emit(
                _safe_float(last_valid.get("x"), 50.0),
                _safe_float(last_valid.get("y"), 50.0),
                float(last_valid["eyeLookX"]) if isinstance(last_valid.get("eyeLookX"), (int, float)) else None,
                float(last_valid["eyeLookY"]) if isinstance(last_valid.get("eyeLookY"), (int, float)) else None,
            )
        else:
            _emit(50.0, 50.0, None, None)
    else:
        raw_bl = raw_l > raw_thr or raw_r > raw_thr
        map_bl = blink_l > map_thr or blink_r > map_thr

        if not gaze_avail:
            freeze_reason = "gaze_unavailable"
            if last_valid is not None:
                held_last = True
                mx = last_valid.get("eyeLookX")
                my = last_valid.get("eyeLookY")
                _emit(
                    _safe_float(last_valid.get("x"), 50.0),
                    _safe_float(last_valid.get("y"), 50.0),
                    float(mx) if isinstance(mx, (int, float)) else None,
                    float(my) if isinstance(my, (int, float)) else None,
                )
            else:
                _emit(50.0, 50.0, None, None)
        elif eff_freeze and raw_bl:
            freeze_reason = "blink_raw"
            frozen_by_blink = True
            if last_valid is not None:
                mx = last_valid.get("eyeLookX")
                my = last_valid.get("eyeLookY")
                _emit(
                    _safe_float(last_valid.get("x"), 50.0),
                    _safe_float(last_valid.get("y"), 50.0),
                    float(mx) if isinstance(mx, (int, float)) else None,
                    float(my) if isinstance(my, (int, float)) else None,
                )
            else:
                _emit(50.0, 50.0, None, None)
        elif eff_freeze and map_bl:
            freeze_reason = "blink_mapping"
            frozen_by_blink = True
            if last_valid is not None:
                mx = last_valid.get("eyeLookX")
                my = last_valid.get("eyeLookY")
                _emit(
                    _safe_float(last_valid.get("x"), 50.0),
                    _safe_float(last_valid.get("y"), 50.0),
                    float(mx) if isinstance(mx, (int, float)) else None,
                    float(my) if isinstance(my, (int, float)) else None,
                )
            else:
                _emit(50.0, 50.0, None, None)
        elif eff_freeze and gaze_avail and (not iris_ok):
            freeze_reason = "iris_unreliable"
            if last_valid is not None:
                mx = last_valid.get("eyeLookX")
                my = last_valid.get("eyeLookY")
                _emit(
                    _safe_float(last_valid.get("x"), 50.0),
                    _safe_float(last_valid.get("y"), 50.0),
                    float(mx) if isinstance(mx, (int, float)) else None,
                    float(my) if isinstance(my, (int, float)) else None,
                )
            else:
                _emit(50.0, 50.0, None, None)
        else:
            # 可用且未冻结：首帧无 lastValid 则不做 maxStep
            assert cand_x is not None and cand_y is not None
            if last_valid is None:
                _emit(cand_x, cand_y, float(gx1), float(gy1))
                limited_by_step = False
            else:
                nx = float(clamp(float(cand_x), lx0 - max_step, lx0 + max_step))
                ny = float(clamp(float(cand_y), ly0 - max_step, ly0 + max_step))
                limited_by_step = abs(nx - cand_x) > 1e-6 or abs(ny - cand_y) > 1e-6
                _emit(nx, ny, float(gx1), float(gy1))
            st["last_valid"] = {
                "x": float(emit_x),
                "y": float(emit_y),
                "eyeLookX": float(gx1),
                "eyeLookY": float(gy1),
                "updatedAt": float(time.time()),
            }

    rig["sharedRadar"]["x"] = float(emit_x)
    rig["sharedRadar"]["y"] = float(emit_y)
    mapping["sharedRadarX"] = float(emit_x)
    mapping["sharedRadarY"] = float(emit_y)
    if map_ex is not None:
        mapping["eyeLookX"] = float(map_ex)
    if map_ey is not None:
        mapping["eyeLookY"] = float(map_ey)
    lemit["x"] = float(emit_x)
    lemit["y"] = float(emit_y)

    gaze_dbg["freezeReason"] = freeze_reason
    gaze_dbg["frozenByBlink"] = bool(frozen_by_blink)
    gaze_dbg["heldLastValid"] = bool(held_last)
    gaze_dbg["limitedByMaxStep"] = bool(limited_by_step)
    gaze_dbg["emittedSharedRadarX"] = float(emit_x)
    gaze_dbg["emittedSharedRadarY"] = float(emit_y)
    gaze_dbg["lastValidSharedRadarX"] = float(st["last_valid"]["x"]) if st.get("last_valid") else None
    gaze_dbg["lastValidSharedRadarY"] = float(st["last_valid"]["y"]) if st.get("last_valid") else None

    gaze_dbg["stable"] = bool(
        (guard_off and gaze_avail)
        or (
            not guard_off
            and gaze_avail
            and iris_ok
            and not frozen_by_blink
            and not held_last
            and freeze_reason == ""
        )
    )

    gaze_dbg["sharedRadarX"] = float(emit_x)
    gaze_dbg["sharedRadarY"] = float(emit_y)
    if "eyeLookX" in mapping:
        gaze_dbg["eyeLookX"] = float(mapping["eyeLookX"])
    if "eyeLookY" in mapping:
        gaze_dbg["eyeLookY"] = float(mapping["eyeLookY"])


def mediapipe_result_to_rig(
    result: Any,
    config: dict[str, Any] | None = None,
    gaze_state: dict[str, Any] | None = None,
    lip_state: dict[str, Any] | None = None,
    jaw_state: dict[str, Any] | None = None,
    *,
    timestamp_ms: float | None = None,
) -> dict[str, Any]:
    """
    将带 blendshapes 的 FaceLandmarkerResult 转为 Elite Rig，并附带 debug。

    返回: { "rig": dict, "debug": { "blendshapes": {...}, "mapping": {...} } }
    """
    cfg = normalize_mapping_config(config) if config is not None else create_default_mapping_config()
    neutral = cfg["neutral"]
    gains = cfg["gains"]
    invert = cfg["invert"]
    deadzone = cfg["deadzone"]
    limits = cfg["limits"]

    blend = extract_debug_blendshapes(result)
    rig = create_neutral_rig()
    mapping: dict[str, float] = {}

    lim_bl = limits.get("blink", [0.0, 100.0])
    lo_b, hi_b = _safe_float(lim_bl[0], 0.0), _safe_float(lim_bl[1], 100.0)

    ebl = blend["eyeBlinkLeft"]
    ebl_cent = ebl - _safe_float(neutral.get("eyeBlinkLeft"), 0.0)
    blink_l = _pipe_unipolar_strength(
        ebl_cent,
        deadzone_thr=_safe_float(deadzone.get("blink"), 0.03),
        gain=_safe_float(gains.get("blinkLeft"), 1.0),
        invert=bool(invert.get("blinkLeft")),
        lim_lo=lo_b,
        lim_hi=hi_b,
    )

    ebr = blend["eyeBlinkRight"]
    ebr_cent = ebr - _safe_float(neutral.get("eyeBlinkRight"), 0.0)
    blink_r = _pipe_unipolar_strength(
        ebr_cent,
        deadzone_thr=_safe_float(deadzone.get("blink"), 0.03),
        gain=_safe_float(gains.get("blinkRight"), 1.0),
        invert=bool(invert.get("blinkRight")),
        lim_lo=lo_b,
        lim_hi=hi_b,
    )

    eye_cfg = cfg.get("eye") if isinstance(cfg.get("eye"), dict) else {}
    bias_l = _safe_float(eye_cfg.get("openBiasLeft"), 20.0)
    bias_r = _safe_float(eye_cfg.get("openBiasRight"), 20.0)
    ratio_open = _safe_float(eye_cfg.get("lowerLidOpenRatio"), 0.25)
    ratio_close = _safe_float(eye_cfg.get("lowerLidCloseRatio"), 0.5)
    use_wide = bool(eye_cfg.get("useEyeWide"))
    wide_scale = _safe_float(eye_cfg.get("eyeWideScale"), 30.0)
    mapping["eyeOpenBiasLeft"] = float(bias_l)
    mapping["eyeOpenBiasRight"] = float(bias_r)

    wide_l = 0.0
    wide_r = 0.0
    if use_wide:
        wide_l = max(
            0.0,
            blend["eyeWideLeft"] - _safe_float(neutral.get("eyeWideLeft"), 0.0),
        )
        wide_r = max(
            0.0,
            blend["eyeWideRight"] - _safe_float(neutral.get("eyeWideRight"), 0.0),
        )
    boost_l = wide_l * wide_scale if use_wide else 0.0
    boost_r = wide_r * wide_scale if use_wide else 0.0

    rig["eyeL"]["up"] = _clamp_signed100(bias_l - blink_l + boost_l)
    rig["eyeL"]["lo"] = _clamp_signed100(blink_l * ratio_close - bias_l * ratio_open)
    mapping["blinkLeft"] = blink_l
    mapping["eyeLUp"] = float(rig["eyeL"]["up"])
    mapping["eyeLLo"] = float(rig["eyeL"]["lo"])

    rig["eyeR"]["up"] = _clamp_signed100(bias_r - blink_r + boost_r)
    rig["eyeR"]["lo"] = _clamp_signed100(blink_r * ratio_close - bias_r * ratio_open)
    mapping["blinkRight"] = blink_r
    mapping["eyeRUp"] = float(rig["eyeR"]["up"])
    mapping["eyeRLo"] = float(rig["eyeR"]["lo"])

    lim_sm = limits.get("smile", [0.0, 100.0])
    lo_s, hi_s = _safe_float(lim_sm[0], 0.0), _safe_float(lim_sm[1], 100.0)

    smile_l_raw = blend["mouthSmileLeft"]
    smile_l_cent = smile_l_raw - _safe_float(neutral.get("mouthSmileLeft"), 0.0)
    smile_l_val = _pipe_unipolar_strength(
        smile_l_cent,
        deadzone_thr=_safe_float(deadzone.get("smile"), 0.03),
        gain=_safe_float(gains.get("smileLeft"), 1.0),
        invert=bool(invert.get("smileLeft")),
        lim_lo=lo_s,
        lim_hi=hi_s,
    )
    # Face Rig v1 嘴角 pad：x=50 中心（左减右增），y=50 中心（上减下增，微笑时略向上提）。
    # mapping.smileLeft/Right 仍为 0~100 语义强度，仅此处写入 rig.mouth.side*。
    rig["mouth"]["sideL"]["x"] = _clamp_pct(50.0 - smile_l_val * 0.35)
    rig["mouth"]["sideL"]["y"] = _clamp_pct(50.0 - smile_l_val * 0.25)
    mapping["smileLeft"] = smile_l_val

    smile_r_raw = blend["mouthSmileRight"]
    smile_r_cent = smile_r_raw - _safe_float(neutral.get("mouthSmileRight"), 0.0)
    smile_r_val = _pipe_unipolar_strength(
        smile_r_cent,
        deadzone_thr=_safe_float(deadzone.get("smile"), 0.03),
        gain=_safe_float(gains.get("smileRight"), 1.0),
        invert=bool(invert.get("smileRight")),
        lim_lo=lo_s,
        lim_hi=hi_s,
    )
    rig["mouth"]["sideR"]["x"] = _clamp_pct(50.0 + smile_r_val * 0.35)
    rig["mouth"]["sideR"]["y"] = _clamp_pct(50.0 - smile_r_val * 0.25)
    mapping["smileRight"] = smile_r_val

    from jaw_geometry import apply_jaw_geometry_drive
    from lip_geometry import apply_lip_geometry_drive

    lip_quality = estimate_tracking_quality(result, True)
    lip_neutral_ready = bool(lip_state.get("neutral_ready")) if isinstance(lip_state, dict) else False

    jaw_geometry_dbg = apply_jaw_geometry_drive(
        result=result,
        cfg=cfg,
        jaw_state=jaw_state,
        rig=rig,
        mapping=mapping,
        blend=blend,
        neutral_bs=neutral,
        gains=gains,
        invert_jaw=bool(invert.get("jaw")),
        deadzone=deadzone,
        limits=limits,
        quality=float(lip_quality),
        face_detected=True,
        timestamp_ms=timestamp_ms,
        lip_neutral_ready=lip_neutral_ready,
    )
    lip_geometry_dbg = apply_lip_geometry_drive(
        result=result,
        rig=rig,
        mapping=mapping,
        cfg=cfg,
        lip_state=lip_state,
        blend=blend,
        neutral=neutral,
        gains=gains,
        invert=invert,
        deadzone=deadzone,
        limits=limits,
        quality=float(lip_quality),
        face_detected=True,
        timestamp_ms=timestamp_ms,
    )

    puck_dbg = max(0.0, blend["mouthPucker"] - _safe_float(neutral.get("mouthPucker"), 0.0))
    funnel_dbg = max(0.0, blend["mouthFunnel"] - _safe_float(neutral.get("mouthFunnel"), 0.0))
    mapping["mouthPucker"] = float(_clamp_pct(puck_dbg * 100.0))
    mapping["mouthFunnel"] = float(_clamp_pct(funnel_dbg * 100.0))

    brow_cfg = cfg.get("brow") if isinstance(cfg.get("brow"), dict) else {}
    lim_bp = limits.get("browPoint", [0.0, 100.0])
    lo_bp, hi_bp = _safe_float(lim_bp[0], 0.0), _safe_float(lim_bp[1], 100.0)
    dzb = _safe_float(deadzone.get("brow"), 0.03)

    bi_s = max(0.0, blend["browInnerUp"] - _safe_float(neutral.get("browInnerUp"), 0.0))
    bi_v = _pipe_unipolar_strength(
        bi_s,
        deadzone_thr=dzb,
        gain=_safe_float(gains.get("browInner"), 1.0),
        invert=bool(invert.get("browInner")),
        lim_lo=lo_bp,
        lim_hi=hi_bp,
    )
    bol_s = max(
        0.0,
        blend["browOuterUpLeft"] - _safe_float(neutral.get("browOuterUpLeft"), 0.0),
    )
    bol_v = _pipe_unipolar_strength(
        bol_s,
        deadzone_thr=dzb,
        gain=_safe_float(gains.get("browOuterLeft"), 1.0),
        invert=bool(invert.get("browOuterLeft")),
        lim_lo=lo_bp,
        lim_hi=hi_bp,
    )
    bor_s = max(
        0.0,
        blend["browOuterUpRight"] - _safe_float(neutral.get("browOuterUpRight"), 0.0),
    )
    bor_v = _pipe_unipolar_strength(
        bor_s,
        deadzone_thr=dzb,
        gain=_safe_float(gains.get("browOuterRight"), 1.0),
        invert=bool(invert.get("browOuterRight")),
        lim_lo=lo_bp,
        lim_hi=hi_bp,
    )

    w_in = _safe_float(brow_cfg.get("midInnerWeight"), 0.4)
    w_out = _safe_float(brow_cfg.get("midOuterWeight"), 0.6)

    tip_l_raw = bi_v * _safe_float(gains.get("browTipLeft"), 1.0)
    tail_l_raw = bol_v * _safe_float(gains.get("browTailLeft"), 1.0)
    tip_l = _clamp_pct(
        apply_invert_unipolar(_clamp_pct(tip_l_raw), bool(invert.get("browTipLeft")), 0.0, 100.0)
    )
    tail_l = _clamp_pct(
        apply_invert_unipolar(_clamp_pct(tail_l_raw), bool(invert.get("browTailLeft")), 0.0, 100.0)
    )
    mid_l = _clamp_pct(bi_v * w_in + bol_v * w_out)

    tip_r_raw = bi_v * _safe_float(gains.get("browTipRight"), 1.0)
    tail_r_raw = bor_v * _safe_float(gains.get("browTailRight"), 1.0)
    tip_r = _clamp_pct(
        apply_invert_unipolar(_clamp_pct(tip_r_raw), bool(invert.get("browTipRight")), 0.0, 100.0)
    )
    tail_r = _clamp_pct(
        apply_invert_unipolar(_clamp_pct(tail_r_raw), bool(invert.get("browTailRight")), 0.0, 100.0)
    )
    mid_r = _clamp_pct(bi_v * w_in + bor_v * w_out)

    lt_tip = _norm_brow_slot(brow_cfg.get("leftTipChannel"), "tip")
    lt_tail = _norm_brow_slot(brow_cfg.get("leftTailChannel"), "tail")
    if lt_tip == lt_tail:
        lt_tail = "tail" if lt_tip == "tip" else "tip"
    rig["browL"][lt_tip] = tip_l
    rig["browL"][lt_tail] = tail_l
    rig["browL"]["mid"] = mid_l

    rt_tip = _norm_brow_slot(brow_cfg.get("rightTipChannel"), "tip")
    rt_tail = _norm_brow_slot(brow_cfg.get("rightTailChannel"), "tail")
    if rt_tip == rt_tail:
        rt_tail = "tail" if rt_tip == "tip" else "tip"
    rig["browR"][rt_tip] = tip_r
    rig["browR"][rt_tail] = tail_r
    rig["browR"]["mid"] = mid_r

    mapping["browInner"] = float(bi_v)
    mapping["browOuterLeft"] = float(bol_v)
    mapping["browOuterRight"] = float(bor_v)
    mapping["browLeftTip"] = float(rig["browL"]["tip"])
    mapping["browLeftMid"] = float(rig["browL"]["mid"])
    mapping["browLeftTail"] = float(rig["browL"]["tail"])
    mapping["browRightTip"] = float(rig["browR"]["tip"])
    mapping["browRightMid"] = float(rig["browR"]["mid"])
    mapping["browRightTail"] = float(rig["browR"]["tail"])
    mapping["browLeft"] = float(mid_l)
    mapping["browRight"] = float(mid_r)

    gaze_dbg = estimate_eye_gaze_from_landmarks(result, cfg)
    _apply_gaze_shared_radar(
        rig=rig,
        mapping=mapping,
        gaze_dbg=gaze_dbg,
        blend=blend,
        blink_l=blink_l,
        blink_r=blink_r,
        cfg=cfg,
        gaze_state=gaze_state,
        neutral=neutral,
        gains=gains,
        invert=invert,
        deadzone=deadzone,
        limits=limits,
    )

    rig["tongue"]["val"] = 0.0

    return {
        "rig": rig,
        "debug": {
            "blendshapes": blend,
            "mapping": mapping,
            "gaze": gaze_dbg,
            "jawGeometry": jaw_geometry_dbg,
            "lipGeometry": lip_geometry_dbg,
        },
    }


def estimate_tracking_quality(result: Any, face_detected: bool) -> float:
    """有人脸时 0.8~1.0；blendshape 齐全时略调高。"""
    if not face_detected:
        return 0.0
    n = blendshape_entry_count(result)
    if n >= 48:
        return 0.96
    if n >= 35:
        return 0.93
    if n >= 12:
        return 0.88
    if n > 0:
        return 0.82
    return 0.8
