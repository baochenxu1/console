"""
嘴唇 Landmark Geometry Driver：局部嘴坐标 + 自动/手动 neutral + 抗漂移 + 输出稳定器。
"""

from __future__ import annotations

import math
import time
from typing import Any

from mediapipe_mapping_config import _safe_float, clamp

_LIP_KEYS = ("upperL", "upperR", "lowerL", "lowerR")

_DEFAULT_LIP_GEOMETRY: dict[str, Any] = {
    "enabled": True,
    "neutralFrames": 30,
    "neutralWarmupFrames": 8,
    "minMouthWidth": 0.03,
    "autoNeutralOnStart": True,
    "requireNeutralReadyForOutput": True,
    "neutralMaxJaw": 8.0,
    "neutralMaxJawOpen": 8.0,
    "neutralMaxSmile": 12.0,
    "neutralMaxSideOffset": 10.0,
    "neutralMaxLipDelta": 8.0,
    "neutralMaxLipVelocity": 3.0,
    "neutralStableFrames": 10,
    "neutralTrackMinQuality": 0.5,
    "driftCorrectionEnabled": True,
    "driftCorrectionAlpha": 0.015,
    "driftCorrectionMaxStep": 0.0008,
    "driftCorrectionStartAfterMs": 1500.0,
    "upperGain": 900.0,
    "lowerGain": 900.0,
    "upperSign": 1.0,
    "lowerSign": 1.0,
    "deadzone": 1.0,
    "snapToZero": 0.8,
    "alphaSlow": 0.30,
    "alphaFast": 0.84,
    "fastDelta": 8.0,
    "outputHoldDeadband": 1.2,
    "outputReleaseThreshold": 2.4,
    "maxStepPerFrame": 22.0,
    "minOutputDelta": 0.0,
    "stableHoldFrames": 0,
    "blendshapeMix": 0.05,
    "useApertureForLip": False,
    "useJawForLip": False,
    "removeJawFromLip": False,
    "jawToUpperCompensation": 0.18,
    "jawToLowerCompensation": 0.35,
    "reAddJawToLip": False,
    "jawToUpperLipGain": 0.10,
    "jawToLowerLipGain": 0.18,
    "crossTalkSuppressionEnabled": False,
    "crossTalkRatio": 1.8,
    "crossTalkPassiveMax": 12.0,
    "crossTalkAttenuation": 0.25,
    "upperLeftIndices": [40, 80, 81],
    "upperRightIndices": [270, 310, 311],
    "lowerLeftIndices": [91, 88, 178],
    "lowerRightIndices": [321, 318, 402],
    "leftCornerIndex": 61,
    "rightCornerIndex": 291,
    "chinIndex": 152,
}

_BOOL_LIP_KEYS = (
    "enabled",
    "autoNeutralOnStart",
    "requireNeutralReadyForOutput",
    "driftCorrectionEnabled",
    "useApertureForLip",
    "useJawForLip",
    "removeJawFromLip",
    "reAddJawToLip",
    "crossTalkSuppressionEnabled",
)


def _rig_helpers():
    from mediapipe_to_rig import (
        _clamp_signed100,
        _pipe_unipolar_strength,
        extract_landmarks,
        get_landmark_xy,
    )

    return (
        _clamp_signed100,
        _pipe_unipolar_strength,
        extract_landmarks,
        get_landmark_xy,
    )


def _axis4_zero() -> dict[str, float]:
    return {"upperL": 0.0, "upperR": 0.0, "lowerL": 0.0, "lowerR": 0.0}


def _axis4_copy(src: dict[str, float] | None) -> dict[str, float]:
    if not isinstance(src, dict):
        return _axis4_zero()
    return {k: float(src.get(k, 0.0)) for k in _LIP_KEYS}


def default_lip_geometry_config() -> dict[str, Any]:
    return dict(_DEFAULT_LIP_GEOMETRY)


def create_lip_geometry_state() -> dict[str, Any]:
    z = _axis4_zero()
    return {
        "neutral_ready": False,
        "neutral_mode": "idle",
        "neutral_count": 0,
        "neutral_warmup_count": 0,
        "neutral_sum": dict(z),
        "neutral": dict(z),
        "prev": dict(z),
        "prev_raw": dict(z),
        "locked_to_zero": {k: True for k in _LIP_KEYS},
        "last_calibrated_at": 0.0,
        "last_drift_update_at": 0.0,
        "neutral_stable_count": 0,
        "force_recalibrate": False,
        "auto_calibrate_requested": False,
        "last_debug": {},
        "drift_hold_reason": "",
    }


def reset_lip_geometry_state(state: dict[str, Any] | None) -> dict[str, Any]:
    fresh = create_lip_geometry_state()
    if state is not None:
        state.clear()
        state.update(fresh)
    return fresh


def start_lip_neutral_calibration(state: dict[str, Any] | None, reason: str = "manual") -> None:
    """开始嘴唇 neutral 采集（自动 Start 或手动 Set Lip Neutral）。"""
    if state is None:
        return
    reset_lip_geometry_state(state)
    auto_reasons = ("startCameraTracking", "autoLipNeutralOnStart", "auto_start", "mouthNeutral")
    state["neutral_mode"] = "auto_start" if str(reason) in auto_reasons else "manual"
    state["auto_calibrate_requested"] = state["neutral_mode"] == "auto_start"
    state["neutral_ready"] = False


def request_lip_neutral_recalibration(state: dict[str, Any] | None) -> None:
    start_lip_neutral_calibration(state, "manual")


def normalize_lip_geometry_config(raw: Any) -> dict[str, Any]:
    base = default_lip_geometry_config()
    if not isinstance(raw, dict):
        return base
    for k, v in _DEFAULT_LIP_GEOMETRY.items():
        if k in _BOOL_LIP_KEYS:
            base[k] = bool(raw.get(k, v))
        elif k.endswith("Indices") or k.endswith("Index"):
            arr = raw.get(k, v)
            if isinstance(arr, (list, tuple)):
                base[k] = [int(x) for x in arr]
            else:
                base[k] = list(v) if isinstance(v, (list, tuple)) else v
        elif isinstance(v, (int, float)):
            base[k] = _safe_float(raw.get(k), float(v))
        else:
            base[k] = raw.get(k, v)
    return base


def _vec2_sub(a: tuple[float, float], b: tuple[float, float]) -> tuple[float, float]:
    return (a[0] - b[0], a[1] - b[1])


def _vec2_norm(v: tuple[float, float]) -> float:
    return math.hypot(v[0], v[1])


def _vec2_normalize(v: tuple[float, float]) -> tuple[float, float] | None:
    n = _vec2_norm(v)
    if n < 1e-9:
        return None
    return (v[0] / n, v[1] / n)


def _vec2_dot(a: tuple[float, float], b: tuple[float, float]) -> float:
    return a[0] * b[0] + a[1] * b[1]


def _perpendicular(v: tuple[float, float]) -> tuple[float, float]:
    return (-v[1], v[0])


def _average_landmark_xy(
    landmarks: Any, indices: list[int], get_landmark_xy
) -> tuple[float, float] | None:
    pts: list[tuple[float, float]] = []
    for i in indices:
        xy = get_landmark_xy(landmarks, int(i))
        if xy is not None:
            pts.append(xy)
    if not pts:
        return None
    return (
        sum(p[0] for p in pts) / len(pts),
        sum(p[1] for p in pts) / len(pts),
    )


def _build_mouth_frame(
    landmarks: Any, lg: dict[str, Any], get_landmark_xy
) -> tuple[dict[str, Any] | None, float]:
    lc = int(lg.get("leftCornerIndex", 61))
    rc = int(lg.get("rightCornerIndex", 291))
    chin_i = int(lg.get("chinIndex", 152))
    corner_l = get_landmark_xy(landmarks, lc)
    corner_r = get_landmark_xy(landmarks, rc)
    chin = get_landmark_xy(landmarks, chin_i)
    if corner_l is None or corner_r is None or chin is None:
        return None, 0.0

    mouth_center = (
        (corner_l[0] + corner_r[0]) * 0.5,
        (corner_l[1] + corner_r[1]) * 0.5,
    )
    x_axis = _vec2_normalize(_vec2_sub(corner_r, corner_l))
    if x_axis is None:
        return None, 0.0
    y_axis = _perpendicular(x_axis)
    chin_rel = _vec2_sub(chin, mouth_center)
    if _vec2_dot(y_axis, chin_rel) < 0:
        y_axis = (-y_axis[0], -y_axis[1])
    y_axis_toward_chin = _vec2_dot(y_axis, chin_rel) > 0

    mouth_width = _vec2_norm(_vec2_sub(corner_r, corner_l))
    min_w = max(1e-6, _safe_float(lg.get("minMouthWidth"), 0.03))
    if mouth_width < min_w:
        return None, mouth_width

    def project_y(point: tuple[float, float]) -> float:
        rel = _vec2_sub(point, mouth_center)
        return _vec2_dot(rel, y_axis) / mouth_width

    return {
        "mouth_center": mouth_center,
        "x_axis": x_axis,
        "y_axis": y_axis,
        "y_axis_toward_chin": bool(y_axis_toward_chin),
        "project_y": project_y,
    }, mouth_width


def _lip_sign_from_config(lg: dict[str, Any], key: str, default: float = 1.0) -> float:
    s = _safe_float(lg.get(key), default)
    if abs(s) < 1e-9:
        return default
    return 1.0 if s > 0 else -1.0


def _geo_delta_raw(
    neutral_y: float,
    current_y: float,
    gain: float,
    sign: float,
    clamp_fn,
) -> float:
    return clamp_fn(float(sign) * (neutral_y - current_y) * gain)


def _cfg_max_jaw(lg: dict[str, Any]) -> float:
    if "neutralMaxJaw" in lg:
        return _safe_float(lg.get("neutralMaxJaw"), 8.0)
    return _safe_float(lg.get("neutralMaxJawOpen"), 8.0)


def _frame_info_from_rig(
    *,
    rig: dict[str, Any],
    mapping: dict[str, float],
    blend: dict[str, float],
    mouth_width: float,
    quality: float,
    face_detected: bool,
) -> dict[str, Any]:
    mouth = rig.get("mouth") if isinstance(rig.get("mouth"), dict) else {}
    side_l = mouth.get("sideL") if isinstance(mouth.get("sideL"), dict) else {}
    side_r = mouth.get("sideR") if isinstance(mouth.get("sideR"), dict) else {}
    jaw_val = _safe_float((rig.get("jaw") or {}).get("val"), 0.0)
    return {
        "face_detected": bool(face_detected),
        "quality": float(quality),
        "mouth_width": float(mouth_width),
        "jaw_val": jaw_val,
        "smile_l": _safe_float(mapping.get("smileLeft"), 0.0),
        "smile_r": _safe_float(mapping.get("smileRight"), 0.0),
        "side_l_x": _safe_float(side_l.get("x"), 50.0),
        "side_l_y": _safe_float(side_l.get("y"), 50.0),
        "side_r_x": _safe_float(side_r.get("x"), 50.0),
        "side_r_y": _safe_float(side_r.get("y"), 50.0),
        "blend_jaw": _safe_float(blend.get("jawOpen"), 0.0),
    }


def is_lip_neutral_candidate(frame_info: dict[str, Any], lg: dict[str, Any]) -> bool:
    if not frame_info.get("face_detected"):
        return False
    min_q = _safe_float(lg.get("neutralTrackMinQuality"), 0.5)
    if float(frame_info.get("quality", 0.0)) < min_q:
        return False
    min_w = max(1e-6, _safe_float(lg.get("minMouthWidth"), 0.03))
    if float(frame_info.get("mouth_width", 0.0)) < min_w:
        return False

    max_jaw = _cfg_max_jaw(lg)
    jaw = abs(float(frame_info.get("jaw_val", 0.0)))
    if jaw > max_jaw:
        return False

    max_smile = _safe_float(lg.get("neutralMaxSmile"), 12.0)
    if max(abs(float(frame_info.get("smile_l", 0.0))), abs(float(frame_info.get("smile_r", 0.0)))) > max_smile:
        return False

    max_side = _safe_float(lg.get("neutralMaxSideOffset"), 10.0)
    for k in ("side_l_x", "side_l_y", "side_r_x", "side_r_y"):
        if abs(float(frame_info.get(k, 50.0)) - 50.0) > max_side:
            return False
    return True


def is_lip_drift_update_allowed(
    *,
    st: dict[str, Any],
    lg: dict[str, Any],
    frame_info: dict[str, Any],
    delta_smooth: dict[str, float],
    now_ms: float,
) -> tuple[bool, str]:
    if not bool(lg.get("driftCorrectionEnabled", True)):
        return False, "disabled"
    if not st.get("neutral_ready"):
        return False, "not-ready"
    last_cal = float(st.get("last_calibrated_at", 0.0))
    if last_cal <= 0 or (now_ms - last_cal) < _safe_float(lg.get("driftCorrectionStartAfterMs"), 1500.0):
        return False, "warmup-after-calibration"

    if not is_lip_neutral_candidate(frame_info, lg):
        return False, "not-neutral-candidate"

    max_delta = _safe_float(lg.get("neutralMaxLipDelta"), 8.0)
    for k in _LIP_KEYS:
        if abs(float(delta_smooth.get(k, 0.0))) > max_delta:
            return False, "lip-delta-active"

    prev_s = st.get("prev") if isinstance(st.get("prev"), dict) else {}
    max_vel = _safe_float(lg.get("neutralMaxLipVelocity"), 3.0)
    for k in _LIP_KEYS:
        if abs(float(delta_smooth.get(k, 0.0)) - float(prev_s.get(k, 0.0))) > max_vel:
            return False, "lip-velocity-high"

    need_stable = max(1, int(lg.get("neutralStableFrames", 10)))
    if int(st.get("neutral_stable_count", 0)) < need_stable:
        return False, "stabilizing"
    return True, "ok"


def _apply_drift_correction(
    st: dict[str, Any],
    lg: dict[str, Any],
    current_y: dict[str, float],
    now_ms: float,
) -> dict[str, float]:
    """极慢更新 neutral absoluteY；返回每通道 step。"""
    alpha = _safe_float(lg.get("driftCorrectionAlpha"), 0.015)
    max_step = _safe_float(lg.get("driftCorrectionMaxStep"), 0.0008)
    neu = st["neutral"]
    steps = _axis4_zero()
    for k in _LIP_KEYS:
        err = float(current_y[k]) - float(neu[k])
        step = clamp(alpha * err, -max_step, max_step)
        neu[k] = float(neu[k]) + step
        steps[k] = float(step)
    st["last_drift_update_at"] = now_ms
    return steps


def stabilize_lip_channel(
    key: str,
    raw: float,
    st: dict[str, Any],
    lg: dict[str, Any],
) -> tuple[float, dict[str, Any]]:
    prev = float(st["prev"].get(key, 0.0))
    prev_raw = float(st["prev_raw"].get(key, 0.0))
    locked = bool(st["locked_to_zero"].get(key, True))

    dz = max(0.0, _safe_float(lg.get("deadzone"), 1.0))
    snap = max(0.0, _safe_float(lg.get("snapToZero"), 0.6))
    hold_db = max(0.0, _safe_float(lg.get("outputHoldDeadband"), 1.2))
    release_thr = max(hold_db, _safe_float(lg.get("outputReleaseThreshold"), 2.2))
    alpha_slow = clamp(_safe_float(lg.get("alphaSlow"), 0.32), 0.0, 1.0)
    alpha_fast = clamp(_safe_float(lg.get("alphaFast"), 0.82), 0.0, 1.0)
    fast_delta = max(1e-6, _safe_float(lg.get("fastDelta"), 10.0))
    max_step = max(1e-6, _safe_float(lg.get("maxStepPerFrame"), 18.0))

    raw_adj = 0.0 if abs(raw) < dz else float(raw)

    if locked:
        if abs(raw_adj) >= release_thr:
            locked = False
            target = raw_adj
        else:
            target = 0.0
    else:
        if abs(raw_adj) < hold_db:
            locked = True
            target = 0.0
        else:
            target = raw_adj

    delta_mag = abs(target - prev)
    t = min(1.0, delta_mag / fast_delta)
    alpha = alpha_slow + (alpha_fast - alpha_slow) * t
    y = prev + alpha * (target - prev)

    step = clamp(y - prev, -max_step, max_step)
    y = prev + step

    if abs(y) < snap:
        y = 0.0
        locked = True

    min_od = max(0.0, _safe_float(lg.get("minOutputDelta"), 0.0))
    if min_od > 0 and abs(y - prev) < min_od:
        y = float(prev)

    velocity = abs(raw_adj - prev_raw)
    st["prev"][key] = float(y)
    st["prev_raw"][key] = float(raw_adj)
    st["locked_to_zero"][key] = locked

    ch_dbg = {
        "locked": locked,
        "raw": float(raw_adj),
        "smooth": float(y),
        "velocity": float(velocity),
        "alpha": float(alpha),
    }
    return float(y), ch_dbg


def _stabilize_all_channels(
    delta_raw: dict[str, float],
    st: dict[str, Any],
    lg: dict[str, Any],
) -> tuple[dict[str, float], dict[str, Any]]:
    smooth = _axis4_zero()
    stabilizer: dict[str, Any] = {"lockedToZero": {}, "raw": {}, "smooth": {}, "velocity": {}, "alpha": {}}
    for k in _LIP_KEYS:
        y, ch = stabilize_lip_channel(k, float(delta_raw[k]), st, lg)
        smooth[k] = y
        stabilizer["lockedToZero"][k] = ch["locked"]
        stabilizer["raw"][k] = ch["raw"]
        stabilizer["smooth"][k] = ch["smooth"]
        stabilizer["velocity"][k] = ch["velocity"]
        stabilizer["alpha"][k] = ch["alpha"]
    return smooth, stabilizer


def _blendshape_lip_signed_deltas(
    blend: dict[str, float],
    neutral: dict[str, float],
    *,
    gains: dict[str, Any],
    invert: dict[str, Any],
    deadzone: dict[str, Any],
    limits: dict[str, Any],
    dz_lip: float,
    lo_lp: float,
    hi_lp: float,
    up_scale: float,
    lo_scale: float,
    _clamp_signed100,
    _pipe_unipolar_strength,
) -> tuple[float, float, float, float]:
    ull_s = max(0.0, blend["mouthUpperUpLeft"] - _safe_float(neutral.get("mouthUpperUpLeft"), 0.0))
    ulr_s = max(0.0, blend["mouthUpperUpRight"] - _safe_float(neutral.get("mouthUpperUpRight"), 0.0))
    lll_s = max(0.0, blend["mouthLowerDownLeft"] - _safe_float(neutral.get("mouthLowerDownLeft"), 0.0))
    llr_s = max(0.0, blend["mouthLowerDownRight"] - _safe_float(neutral.get("mouthLowerDownRight"), 0.0))

    ull_v = _pipe_unipolar_strength(
        ull_s, deadzone_thr=dz_lip, gain=_safe_float(gains.get("upperLipLeft"), 1.0),
        invert=bool(invert.get("upperLipLeft")), lim_lo=lo_lp, lim_hi=hi_lp,
    )
    ulr_v = _pipe_unipolar_strength(
        ulr_s, deadzone_thr=dz_lip, gain=_safe_float(gains.get("upperLipRight"), 1.0),
        invert=bool(invert.get("upperLipRight")), lim_lo=lo_lp, lim_hi=hi_lp,
    )
    lll_v = _pipe_unipolar_strength(
        lll_s, deadzone_thr=dz_lip, gain=_safe_float(gains.get("lowerLipLeft"), 1.0),
        invert=False, lim_lo=lo_lp, lim_hi=hi_lp,
    )
    llr_v = _pipe_unipolar_strength(
        llr_s, deadzone_thr=dz_lip, gain=_safe_float(gains.get("lowerLipRight"), 1.0),
        invert=False, lim_lo=lo_lp, lim_hi=hi_lp,
    )
    return (
        _clamp_signed100(abs(ull_v * up_scale)),
        _clamp_signed100(abs(ulr_v * up_scale)),
        _clamp_signed100(-abs(lll_v * lo_scale)),
        _clamp_signed100(-abs(llr_v * lo_scale)),
    )


def _zero_lip_outputs(rig: dict[str, Any], mapping: dict[str, float]) -> None:
    rig["mouth"]["UL"] = 0.0
    rig["mouth"]["UR"] = 0.0
    rig["mouth"]["LL"] = 0.0
    rig["mouth"]["LR"] = 0.0
    mapping["lipGeoUpperL"] = 0.0
    mapping["lipGeoUpperR"] = 0.0
    mapping["lipGeoLowerL"] = 0.0
    mapping["lipGeoLowerR"] = 0.0
    mapping["upperLipLeft"] = 0.0
    mapping["upperLipRight"] = 0.0
    mapping["lowerLipLeft"] = 0.0
    mapping["lowerLipRight"] = 0.0


def _apply_lip_cross_talk(
    d: dict[str, float],
    lg: dict[str, Any],
) -> tuple[dict[str, float], dict[str, Any]]:
    if not bool(lg.get("crossTalkSuppressionEnabled", True)):
        return dict(d), {"suppressedUpper": False, "suppressedLower": False}
    ratio = max(1.001, _safe_float(lg.get("crossTalkRatio"), 1.8))
    passive_max = max(0.0, _safe_float(lg.get("crossTalkPassiveMax"), 12.0))
    atten = clamp(_safe_float(lg.get("crossTalkAttenuation"), 0.25), 0.0, 1.0)

    upper_mag = max(abs(float(d["upperL"])), abs(float(d["upperR"])))
    lower_mag = max(abs(float(d["lowerL"])), abs(float(d["lowerR"])))
    out = {k: float(d[k]) for k in _LIP_KEYS}
    suppressed_upper = False
    suppressed_lower = False

    if upper_mag > lower_mag * ratio and lower_mag < passive_max:
        out["lowerL"] *= atten
        out["lowerR"] *= atten
        suppressed_lower = True

    if lower_mag > upper_mag * ratio and upper_mag < passive_max:
        out["upperL"] *= atten
        out["upperR"] *= atten
        suppressed_upper = True

    return out, {
        "suppressedUpper": suppressed_upper,
        "suppressedLower": suppressed_lower,
        "upperMag": float(upper_mag),
        "lowerMag": float(lower_mag),
        "ratio": float(ratio),
    }


def _neutral_state_debug(st: dict[str, Any]) -> dict[str, Any]:
    return {
        "mode": str(st.get("neutral_mode", "idle")),
        "neutralReady": bool(st.get("neutral_ready")),
        "neutralCount": int(st.get("neutral_count", 0)),
        "neutralWarmupCount": int(st.get("neutral_warmup_count", 0)),
        "stableCount": int(st.get("neutral_stable_count", 0)),
        "autoCalibrateRequested": bool(st.get("auto_calibrate_requested")),
        "forceRecalibrate": bool(st.get("force_recalibrate")),
        "lastCalibratedAt": float(st.get("last_calibrated_at", 0.0)),
    }


def _pack_lip_debug(
    *,
    lg: dict[str, Any],
    st: dict[str, Any],
    mouth_width: float,
    current_y: dict[str, float],
    neutral_y: dict[str, float],
    delta_raw: dict[str, float],
    delta_smooth: dict[str, float],
    rig_write: dict[str, float],
    blend_term: dict[str, float],
    sign_convention: dict[str, Any] | None = None,
    drift_correction: dict[str, Any] | None = None,
    stabilizer: dict[str, Any] | None = None,
    source_breakdown: dict[str, Any] | None = None,
    cross_talk: dict[str, Any] | None = None,
    skipped: str = "",
) -> dict[str, Any]:
    sc = sign_convention if isinstance(sign_convention, dict) else {}
    iso_u = max(abs(float(delta_smooth.get("upperL", 0.0))), abs(float(delta_smooth.get("upperR", 0.0))))
    iso_l = max(abs(float(delta_smooth.get("lowerL", 0.0))), abs(float(delta_smooth.get("lowerR", 0.0))))
    denom = iso_u + iso_l + 1e-6
    isolation = float((iso_u - iso_l) / denom)
    out = {
        "enabled": bool(lg.get("enabled", True)),
        "neutralReady": bool(st.get("neutral_ready")),
        "neutralCount": int(st.get("neutral_count", 0)),
        "mouthWidth": float(mouth_width),
        "neutralState": _neutral_state_debug(st),
        "driftCorrection": dict(drift_correction or {}),
        "stabilizer": dict(stabilizer or {}),
        "signConvention": dict(sc),
        "currentY": dict(current_y),
        "neutralY": dict(neutral_y),
        "deltaRaw": dict(delta_raw),
        "deltaSmooth": dict(delta_smooth),
        "rigWrite": dict(rig_write),
        "blendshapeTerm": dict(blend_term),
        "skipped": skipped,
        "upperL": float(delta_smooth.get("upperL", 0.0)),
        "upperR": float(delta_smooth.get("upperR", 0.0)),
        "lowerL": float(delta_smooth.get("lowerL", 0.0)),
        "lowerR": float(delta_smooth.get("lowerR", 0.0)),
        "upperLRaw": float(delta_raw.get("upperL", 0.0)),
        "upperRRaw": float(delta_raw.get("upperR", 0.0)),
        "lowerLRaw": float(delta_raw.get("lowerL", 0.0)),
        "lowerRRaw": float(delta_raw.get("lowerR", 0.0)),
        "isolation": isolation,
    }
    if source_breakdown:
        out["sourceBreakdown"] = source_breakdown
    if cross_talk:
        out["crossTalk"] = cross_talk
    return out


def _process_neutral_calibration(
    st: dict[str, Any],
    lg: dict[str, Any],
    *,
    current_y: dict[str, float],
    candidate: bool,
    now_ms: float,
) -> tuple[bool, bool, str]:
    """返回 (still_calibrating, just_completed, ui_hint)。"""
    if st.get("neutral_ready"):
        return False, False, "ready"

    warmup_need = max(0, int(lg.get("neutralWarmupFrames", 8)))
    n_frames = max(1, int(lg.get("neutralFrames", 30)))

    if not candidate:
        st["neutral_stable_count"] = 0
        return True, False, "waiting-stable-mouth"

    wc = int(st.get("neutral_warmup_count", 0))
    if wc < warmup_need:
        st["neutral_warmup_count"] = wc + 1
        return True, False, "warmup"

    ns = st["neutral_sum"]
    for k in _LIP_KEYS:
        ns[k] += current_y[k]
    nc = int(st.get("neutral_count", 0)) + 1
    st["neutral_count"] = nc

    if nc < n_frames:
        return True, False, "calibrating"

    st["neutral"] = {k: ns[k] / nc for k in _LIP_KEYS}
    st["neutral_ready"] = True
    st["neutral_mode"] = "ready"
    st["prev"] = _axis4_zero()
    st["prev_raw"] = _axis4_zero()
    st["locked_to_zero"] = {k: True for k in _LIP_KEYS}
    st["last_calibrated_at"] = now_ms
    st["neutral_stable_count"] = 0
    st["auto_calibrate_requested"] = False
    return False, True, "just-completed"


def apply_lip_geometry_drive(
    *,
    result: Any,
    rig: dict[str, Any],
    mapping: dict[str, float],
    cfg: dict[str, Any],
    lip_state: dict[str, Any] | None,
    blend: dict[str, float],
    neutral: dict[str, float],
    gains: dict[str, Any],
    invert: dict[str, Any],
    deadzone: dict[str, Any],
    limits: dict[str, Any],
    quality: float = 0.0,
    face_detected: bool = True,
    timestamp_ms: float | None = None,
    jaw_semantic_open: float = 0.0,
) -> dict[str, Any]:
    """写入 rig.mouth.UL/UR/LL/LR；返回 debug.lipGeometry。"""
    (
        _clamp_signed100,
        _pipe_unipolar_strength,
        extract_landmarks,
        get_landmark_xy,
    ) = _rig_helpers()

    now_ms = float(timestamp_ms) if timestamp_ms is not None else time.time() * 1000.0
    lip_cfg = cfg.get("lip") if isinstance(cfg.get("lip"), dict) else {}
    lip_on = bool(lip_cfg.get("enabled", True))
    lim_lip = limits.get("lip", [0.0, 100.0])
    lo_lp, hi_lp = _safe_float(lim_lip[0], 0.0), _safe_float(lim_lip[1], 100.0)
    dz_lip = _safe_float(deadzone.get("lip"), 0.03)
    up_scale = _safe_float(lip_cfg.get("upperScale"), 100.0) / 100.0
    lo_scale = _safe_float(lip_cfg.get("lowerScale"), 100.0) / 100.0

    lg = normalize_lip_geometry_config(cfg.get("lipGeometry"))
    st = lip_state if lip_state is not None else create_lip_geometry_state()
    upper_sign = _lip_sign_from_config(lg, "upperSign", 1.0)
    lower_sign = _lip_sign_from_config(lg, "lowerSign", 1.0)
    require_ready = bool(lg.get("requireNeutralReadyForOutput", True))

    empty_y = _axis4_zero()
    drift_dbg: dict[str, Any] = {
        "enabled": bool(lg.get("driftCorrectionEnabled", True)),
        "allowed": False,
        "updated": False,
        "reason": "",
        "stepUpperL": 0.0,
        "stepUpperR": 0.0,
        "stepLowerL": 0.0,
        "stepLowerR": 0.0,
    }
    sign_conv_base = {
        "upperOpenPositive": True,
        "lowerOpenNegative": True,
        "upperSign": float(upper_sign),
        "lowerSign": float(lower_sign),
        "yAxisTowardChin": False,
    }

    blend_ul, blend_ur, blend_ll, blend_lr = _blendshape_lip_signed_deltas(
        blend, neutral, gains=gains, invert=invert, deadzone=deadzone, limits=limits,
        dz_lip=dz_lip, lo_lp=lo_lp, hi_lp=hi_lp, up_scale=up_scale, lo_scale=lo_scale,
        _clamp_signed100=_clamp_signed100, _pipe_unipolar_strength=_pipe_unipolar_strength,
    )
    blend_term = {"upperL": float(blend_ul), "upperR": float(blend_ur), "lowerL": float(blend_ll), "lowerR": float(blend_lr)}

    def _finish_dbg(**kwargs) -> dict[str, Any]:
        dbg = _pack_lip_debug(
            lg=lg, st=st, mouth_width=float(kwargs.get("mouth_width", 0.0)),
            current_y=kwargs.get("current_y", empty_y),
            neutral_y=kwargs.get("neutral_y", empty_y),
            delta_raw=kwargs.get("delta_raw", empty_y),
            delta_smooth=kwargs.get("delta_smooth", empty_y),
            rig_write=kwargs.get("rig_write", empty_y),
            blend_term=blend_term,
            sign_convention=kwargs.get("sign_convention", sign_conv_base),
            drift_correction=kwargs.get("drift_correction", drift_dbg),
            stabilizer=kwargs.get("stabilizer", {}),
            source_breakdown=kwargs.get("source_breakdown"),
            cross_talk=kwargs.get("cross_talk"),
            skipped=kwargs.get("skipped", ""),
        )
        st["last_debug"] = dbg
        return dbg

    if not lip_on:
        _zero_lip_outputs(rig, mapping)
        return _finish_dbg(skipped="lip-disabled")

    if not bool(lg.get("enabled", True)):
        rig["mouth"]["UL"] = blend_ul
        rig["mouth"]["UR"] = blend_ur
        rig["mouth"]["LL"] = blend_ll
        rig["mouth"]["LR"] = blend_lr
        mapping["upperLipLeft"] = float(blend_ul)
        mapping["upperLipRight"] = float(blend_ur)
        mapping["lowerLipLeft"] = float(blend_ll)
        mapping["lowerLipRight"] = float(blend_lr)
        return _finish_dbg(skipped="lipGeometry-disabled", rig_write=blend_term)

    lm = extract_landmarks(result)
    if lm is None:
        _zero_lip_outputs(rig, mapping)
        return _finish_dbg(skipped="no-landmarks")

    frame, mouth_width = _build_mouth_frame(lm, lg, get_landmark_xy)
    y_axis_toward_chin = bool(frame.get("y_axis_toward_chin")) if frame else False
    sign_convention = {**sign_conv_base, "yAxisTowardChin": y_axis_toward_chin}
    if frame is None:
        _zero_lip_outputs(rig, mapping)
        return _finish_dbg(mouth_width=mouth_width, sign_convention=sign_convention, skipped="mouth-frame-invalid")

    py = frame["project_y"]
    upper_l_pt = _average_landmark_xy(lm, list(lg.get("upperLeftIndices", [])), get_landmark_xy)
    upper_r_pt = _average_landmark_xy(lm, list(lg.get("upperRightIndices", [])), get_landmark_xy)
    lower_l_pt = _average_landmark_xy(lm, list(lg.get("lowerLeftIndices", [])), get_landmark_xy)
    lower_r_pt = _average_landmark_xy(lm, list(lg.get("lowerRightIndices", [])), get_landmark_xy)
    if None in (upper_l_pt, upper_r_pt, lower_l_pt, lower_r_pt):
        _zero_lip_outputs(rig, mapping)
        return _finish_dbg(mouth_width=mouth_width, skipped="lip-points-missing")

    current_y = {
        "upperL": float(py(upper_l_pt)),
        "upperR": float(py(upper_r_pt)),
        "lowerL": float(py(lower_l_pt)),
        "lowerR": float(py(lower_r_pt)),
    }
    frame_info = _frame_info_from_rig(
        rig=rig, mapping=mapping, blend=blend,
        mouth_width=float(mouth_width), quality=float(quality), face_detected=bool(face_detected),
    )
    candidate = is_lip_neutral_candidate(frame_info, lg)

    still_cal, just_done, cal_hint = _process_neutral_calibration(
        st, lg, current_y=current_y, candidate=candidate, now_ms=now_ms,
    )
    neu_y = _axis4_copy(st["neutral"]) if st.get("neutral_ready") else empty_y

    if still_cal or just_done or (require_ready and not st.get("neutral_ready")):
        _zero_lip_outputs(rig, mapping)
        skip = "neutral-calibrating" if still_cal else ("neutral-just-completed" if just_done else "neutral-not-ready")
        return _finish_dbg(
            mouth_width=mouth_width, current_y=current_y, neutral_y=neu_y,
            sign_convention=sign_convention, skipped=f"{skip}:{cal_hint}",
        )

    neu = st["neutral"]
    upper_gain = _safe_float(lg.get("upperGain"), 900.0)
    lower_gain = _safe_float(lg.get("lowerGain"), 900.0)

    prev_smooth = _axis4_copy(st["prev"])
    if is_lip_neutral_candidate(frame_info, lg):
        st["neutral_stable_count"] = int(st.get("neutral_stable_count", 0)) + 1
    else:
        st["neutral_stable_count"] = 0
        st["drift_hold_reason"] = "not-neutral-candidate"

    drift_allowed, drift_reason = is_lip_drift_update_allowed(
        st=st, lg=lg, frame_info=frame_info, delta_smooth=prev_smooth, now_ms=now_ms,
    )
    drift_dbg["allowed"] = drift_allowed
    drift_dbg["reason"] = drift_reason
    if drift_allowed:
        steps = _apply_drift_correction(st, lg, current_y, now_ms)
        drift_dbg["updated"] = True
        drift_dbg["stepUpperL"] = steps["upperL"]
        drift_dbg["stepUpperR"] = steps["upperR"]
        drift_dbg["stepLowerL"] = steps["lowerL"]
        drift_dbg["stepLowerR"] = steps["lowerR"]
        neu = st["neutral"]

    delta_raw = {
        "upperL": float(_geo_delta_raw(neu["upperL"], current_y["upperL"], upper_gain, upper_sign, _clamp_signed100)),
        "upperR": float(_geo_delta_raw(neu["upperR"], current_y["upperR"], upper_gain, upper_sign, _clamp_signed100)),
        "lowerL": float(_geo_delta_raw(neu["lowerL"], current_y["lowerL"], lower_gain, lower_sign, _clamp_signed100)),
        "lowerR": float(_geo_delta_raw(neu["lowerR"], current_y["lowerR"], lower_gain, lower_sign, _clamp_signed100)),
    }

    # Lip Geometry V2: jaw 与 lip 完全解耦。jaw 不参与 lip 计算。
    delta_geo = {
        "upperL": float(delta_raw["upperL"]),
        "upperR": float(delta_raw["upperR"]),
        "lowerL": float(delta_raw["lowerL"]),
        "lowerR": float(delta_raw["lowerR"]),
    }

    delta_xtalk, xt_dbg = _apply_lip_cross_talk(delta_geo, lg)
    delta_smooth, stabilizer = _stabilize_all_channels(delta_xtalk, st, lg)

    mix = clamp(_safe_float(lg.get("blendshapeMix"), 0.08), 0.0, 1.0)
    w_geo = 1.0 - mix
    rig_write = {
        "upperL": float(_clamp_signed100(delta_smooth["upperL"] * w_geo + blend_ul * mix)),
        "upperR": float(_clamp_signed100(delta_smooth["upperR"] * w_geo + blend_ur * mix)),
        "lowerL": float(_clamp_signed100(delta_smooth["lowerL"] * w_geo + blend_ll * mix)),
        "lowerR": float(_clamp_signed100(delta_smooth["lowerR"] * w_geo + blend_lr * mix)),
    }

    src_breakdown = {
        "upperGeometry": {"upperL": delta_raw["upperL"], "upperR": delta_raw["upperR"]},
        "lowerGeometry": {"lowerL": delta_raw["lowerL"], "lowerR": delta_raw["lowerR"]},
        "jawContributionToLip": 0.0,
        "apertureTerm": 0.0,
        "jawTerm": 0.0,
    }

    rig["mouth"]["UL"] = rig_write["upperL"]
    rig["mouth"]["UR"] = rig_write["upperR"]
    rig["mouth"]["LL"] = rig_write["lowerL"]
    rig["mouth"]["LR"] = rig_write["lowerR"]

    mapping["lipGeoUpperL"] = delta_smooth["upperL"]
    mapping["lipGeoUpperR"] = delta_smooth["upperR"]
    mapping["lipGeoLowerL"] = delta_smooth["lowerL"]
    mapping["lipGeoLowerR"] = delta_smooth["lowerR"]
    mapping["upperLipLeft"] = rig_write["upperL"]
    mapping["upperLipRight"] = rig_write["upperR"]
    mapping["lowerLipLeft"] = rig_write["lowerL"]
    mapping["lowerLipRight"] = rig_write["lowerR"]

    return _finish_dbg(
        mouth_width=mouth_width,
        current_y=current_y,
        neutral_y=_axis4_copy(neu),
        delta_raw=delta_raw,
        delta_smooth=delta_smooth,
        rig_write=rig_write,
        sign_convention=sign_convention,
        drift_correction=drift_dbg,
        stabilizer=stabilizer,
        source_breakdown=src_breakdown,
        cross_talk=xt_dbg,
        skipped="",
    )


def lip_geometry_overlay_indices(cfg: dict[str, Any] | None = None) -> tuple[int, ...]:
    lg = normalize_lip_geometry_config(
        cfg.get("lipGeometry") if isinstance(cfg, dict) else None
    )
    indices: set[int] = {
        int(lg.get("leftCornerIndex", 61)),
        int(lg.get("rightCornerIndex", 291)),
        int(lg.get("chinIndex", 152)),
    }
    for key in ("upperLeftIndices", "upperRightIndices", "lowerLeftIndices", "lowerRightIndices"):
        for i in lg.get(key) or []:
            indices.add(int(i))
    return tuple(sorted(indices))
