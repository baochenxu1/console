﻿function fmt2(v) {
  if (v == null || Number.isNaN(Number(v))) return "0.00"
  return Number.isFinite(Number(v)) ? Number(v).toFixed(2) : "0.00"
}

function lipNeutralHint(lipGeometry, jawGeometry, cameraRunning) {
  if (!cameraRunning || !lipGeometry) return null
  const jawOk = !jawGeometry || jawGeometry.neutralReady
  if (!lipGeometry.neutralReady || !jawOk) {
    const skipped = String(lipGeometry.skipped || "")
    if (skipped.includes("waiting-stable")) return "请保持自然闭嘴，等待稳定采样…"
    return "嘴部零点校准中（唇+下颌）：请自然闭嘴约 1 秒"
  }
  if (lipGeometry.driftCorrection?.updated) return "嘴唇零点缓慢校正中"
  return "嘴部零点已完成（唇+下颌）"
}

function deltaSmooth(lipGeometry, key) {
  const ds = lipGeometry?.deltaSmooth
  if (ds && Number.isFinite(Number(ds[key]))) return ds[key]
  if (lipGeometry && Number.isFinite(Number(lipGeometry[key]))) return lipGeometry[key]
  return 0
}

function DataSection({ title, rows }) {
  if (!rows.length) return null
  return (
    <>
      <h3 className="mapping-category-title">{title}</h3>
      {rows.map(([name, value]) => (
        <div key={name} className="mapping-item">
          <span className="mapping-item-key">{name}</span>
          <span className="mapping-item-value">{value}</span>
        </div>
      ))}
    </>
  )
}

function truncateCmd(cmd, max = 72) {
  const s = String(cmd || "")
  if (s.length <= max) return s || "—"
  return `${s.slice(0, max)}…`
}

export default function MappingSummaryCard({
  previewRig,
  mapping,
  lipGeometry = null,
  jawGeometry = null,
  showDeveloperDebug = false,
  cameraRunning = false,
  onSetLipNeutral,
  driveMode,
  dryRunResult = null,
}) {
  const rig = previewRig || {}
  const mapv = mapping && typeof mapping === "object" ? mapping : null
  const k = dryRunResult?.diagnostics?.kinematics

  const mouthRows = [
    ["mouth.sideL", `${fmt2(rig.mouth?.sideL?.x)} / ${fmt2(rig.mouth?.sideL?.y)}`],
    ["mouth.sideR", `${fmt2(rig.mouth?.sideR?.x)} / ${fmt2(rig.mouth?.sideR?.y)}`],
    ["jaw.val", fmt2(rig.jaw?.val)],
  ]
  if (mapv) mouthRows.push(["mapping.jaw", fmt2(mapv.jaw)])

  const eyeRows = [
    ["eyeL up/lo", `${fmt2(rig.eyeL?.up)} / ${fmt2(rig.eyeL?.lo)}`],
    ["eyeR up/lo", `${fmt2(rig.eyeR?.up)} / ${fmt2(rig.eyeR?.lo)}`],
    ["sharedRadar", `${fmt2(rig.sharedRadar?.x)} / ${fmt2(rig.sharedRadar?.y)}`],
  ]
  if (mapv) {
    eyeRows.push(
      ["blink L/R", `${fmt2(mapv.blinkLeft)} / ${fmt2(mapv.blinkRight)}`],
      ["map radar", `${fmt2(mapv.sharedRadarX)} / ${fmt2(mapv.sharedRadarY)}`]
    )
  }

  const browRows = [
    ["browL tip/mid/tail", `${fmt2(rig.browL?.tip)} / ${fmt2(rig.browL?.mid)} / ${fmt2(rig.browL?.tail)}`],
    ["browR tip/mid/tail", `${fmt2(rig.browR?.tip)} / ${fmt2(rig.browR?.mid)} / ${fmt2(rig.browR?.tail)}`],
  ]

  const lipRows = [
    ["rigWrite UL/UR", `${fmt2(mapv?.upperLipLeft ?? rig.mouth?.UL)} / ${fmt2(mapv?.upperLipRight ?? rig.mouth?.UR)}`],
    ["rigWrite LL/LR", `${fmt2(mapv?.lowerLipLeft ?? rig.mouth?.LL)} / ${fmt2(mapv?.lowerLipRight ?? rig.mouth?.LR)}`],
    ["tongue.val", fmt2(rig.tongue?.val)],
  ]

  const lipNeutralStatus = lipNeutralHint(lipGeometry, jawGeometry, cameraRunning)
  const jawGeoRows = [
    ["jaw", fmt2(rig.jaw?.val)],
    ["raw", fmt2(jawGeometry?.raw)],
    ["curve", fmt2(jawGeometry?.curved)],
    ["poseGate", jawGeometry?.poseGate?.active ? "active" : "off"],
    ["neutralReady", jawGeometry?.neutralReady ? "yes" : "no"],
    ["mode", jawGeometry?.neutralState?.mode ? String(jawGeometry.neutralState.mode) : "—"],
  ]
  if (showDeveloperDebug && jawGeometry) {
    jawGeoRows.push(
      ["semanticOpen", fmt2(jawGeometry.semanticOpen)],
      ["smoothSem", fmt2(jawGeometry.smoothSemantic)],
      ["skipped", jawGeometry.skipped || "—"]
    )
  }

  const lipGeoRows = []
  if (lipNeutralStatus) lipGeoRows.push(["status", lipNeutralStatus])
  lipGeoRows.push(
    ["upperL", fmt2(deltaSmooth(lipGeometry, "upperL"))],
    ["upperR", fmt2(deltaSmooth(lipGeometry, "upperR"))],
    ["lowerL", fmt2(deltaSmooth(lipGeometry, "lowerL"))],
    ["lowerR", fmt2(deltaSmooth(lipGeometry, "lowerR"))],
    ["isolation", Number.isFinite(Number(lipGeometry?.isolation)) ? fmt2(lipGeometry.isolation) : "—"]
  )

  return (
    <details className="tp-mapping-fold">
      <summary className="tp-mapping-fold-summary">
        <span className="tp-mapping-fold-label">Mapping Diagnostics (映射数据诊断)</span>
        <span className="tp-mapping-fold-chevron" aria-hidden>
          ▼
        </span>
      </summary>
      <div className="tp-mapping-fold-body">
        <div className="mapping-list-container">
          <DataSection title="Mouth / Jaw" rows={mouthRows} />
          <DataSection title="Eyes" rows={eyeRows} />
          <DataSection title="Brows" rows={browRows} />
          <DataSection title="Lip / Tongue (rigWrite)" rows={lipRows} />
          <DataSection title="Jaw Geometry" rows={jawGeoRows} />
          <DataSection title="Lip Geometry (delta)" rows={lipGeoRows} />

          {cameraRunning && typeof onSetLipNeutral === "function" ? (
            <div className="tp-lip-neutral-row">
              <button
                type="button"
                className="tp-btn tp-btn--secondary tp-btn--compact"
                onClick={onSetLipNeutral}
              >
                Set Mouth Neutral
              </button>
              <p className="hint tp-lip-neutral-hint">
                请保持自然闭嘴约 1 秒，系统会重新校准嘴部（唇+下颌）中性位。
              </p>
            </div>
          ) : null}

          {(driveMode === "dry-run" || driveMode === "device-drive") && dryRunResult ? (
            <DataSection
              title={driveMode === "device-drive" ? "Device Drive" : "Dry Run"}
              rows={[
                ["logicalPose", String(Object.keys(dryRunResult.logicalPose || {}).length)],
                ["actualPose", String(Object.keys(dryRunResult.actualPose || {}).length)],
                ["command", truncateCmd(dryRunResult.commandPreview)],
                ["warnings", dryRunResult.warnings?.length ? String(dryRunResult.warnings.length) : "0"],
                ...(k?.rightMouthCorner
                  ? [["rightMouth PWM", `${k.logicalPwmA ?? "—"} / ${k.logicalPwmB ?? "—"}`]]
                  : []),
                ...(k?.leftMouthCorner
                  ? [["leftMouth PWM", `${k.logicalPwmA ?? "—"} / ${k.logicalPwmB ?? "—"}`]]
                  : []),
              ]}
            />
          ) : null}
        </div>
      </div>
    </details>
  )
}
