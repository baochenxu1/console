import { createInitialEliteRig } from "../../core/faceDofMapper.js"

export const TRACKING_FRAME_TYPE = "tracking.rigFrame"

/** @typedef {ReturnType<createInitialEliteRig>} EliteRigState */

/**
 * @typedef {Object} RigFrameDebugBlendshapes
 * @property {number} jawOpen
 * @property {number} eyeBlinkLeft
 * @property {number} eyeBlinkRight
 * @property {number} eyeWideLeft
 * @property {number} eyeWideRight
 * @property {number} mouthSmileLeft
 * @property {number} mouthSmileRight
 * @property {number} mouthUpperUpLeft
 * @property {number} mouthUpperUpRight
 * @property {number} mouthLowerDownLeft
 * @property {number} mouthLowerDownRight
 * @property {number} mouthPucker
 * @property {number} mouthFunnel
 * @property {number} mouthClose
 * @property {number} browInnerUp
 * @property {number} browOuterUpLeft
 * @property {number} browOuterUpRight
 */

/**
 * @typedef {Object} RigFrameDebugMapping
 * @property {number} jaw
 * @property {number} blinkLeft
 * @property {number} blinkRight
 * @property {number} smileLeft
 * @property {number} smileRight
 * @property {number} browLeft
 * @property {number} browRight
 * @property {number} eyeOpenBiasLeft
 * @property {number} eyeOpenBiasRight
 * @property {number} eyeLUp
 * @property {number} eyeLLo
 * @property {number} eyeRUp
 * @property {number} eyeRLo
 * @property {number} browInner
 * @property {number} browOuterLeft
 * @property {number} browOuterRight
 * @property {number} browLeftTip
 * @property {number} browLeftMid
 * @property {number} browLeftTail
 * @property {number} browRightTip
 * @property {number} browRightMid
 * @property {number} browRightTail
 * @property {number} upperLipLeft
 * @property {number} upperLipRight
 * @property {number} lowerLipLeft
 * @property {number} lowerLipRight
 * @property {number} [lipGeoUpperL] — landmark geometry 平滑后（signed100 语义）
 * @property {number} [lipGeoUpperR]
 * @property {number} [lipGeoLowerL]
 * @property {number} [lipGeoLowerR]
 * @property {number} mouthPucker - 仅调试 0～100，第一版不参与 rig
 * @property {number} mouthFunnel - 同上
 * @property {number} [eyeLookX] — 视线语义水平分量（约 −1～1，经 deadzone/gain/invert 后）
 * @property {number} [eyeLookY] — 视线语义垂直分量
 * @property {number} [sharedRadarX] — 映射到 rig.sharedRadar.x 的 0～100
 * @property {number} [sharedRadarY] — 映射到 rig.sharedRadar.y 的 0～100
 */

/**
 * @typedef {Object} RigFrameDebugGaze
 * @property {boolean} available
 * @property {number} eyeLookX
 * @property {number} eyeLookY
 * @property {number} leftEyeX
 * @property {number} leftEyeY
 * @property {number} rightEyeX
 * @property {number} rightEyeY
 */

/**
 * @typedef {Object} RigFrameLipAxis4
 * @property {number} upperL
 * @property {number} upperR
 * @property {number} lowerL
 * @property {number} lowerR
 */

/**
 * @typedef {Object} RigFrameDebugLipGeometry
 * @property {boolean} enabled
 * @property {boolean} neutralReady
 * @property {number} neutralCount
 * @property {number} mouthWidth
 * @property {RigFrameLipAxis4} deltaSmooth — 闭嘴时应接近 0
 * @property {RigFrameLipAxis4} deltaRaw
 * @property {RigFrameLipAxis4} currentY
 * @property {RigFrameLipAxis4} neutralY
 * @property {RigFrameLipAxis4} rigWrite — 写入 rig 的最终值
 * @property {RigFrameLipAxis4} blendshapeTerm
 * @property {{ upperOpenPositive?: boolean, lowerOpenNegative?: boolean, upperSign?: number, lowerSign?: number, yAxisTowardChin?: boolean }} [signConvention]
 * @property {number} [upperL] — 扁平兼容，同 deltaSmooth.upperL
 * @property {number} [upperR]
 * @property {number} [lowerL]
 * @property {number} [lowerR]
 * @property {number} [upperLRaw]
 * @property {number} [upperRRaw]
 * @property {number} [lowerLRaw]
 * @property {number} [lowerRRaw]
 * @property {number} [isolation] — (upperMag−lowerMag) / sum；正负粗略区分主导唇轴
 * @property {{ suppressedUpper?: boolean, suppressedLower?: boolean }} [crossTalk]
 * @property {Record<string, unknown>} [sourceBreakdown]
 * @property {string} [skipped]
 */

/**
 * @typedef {Object} RigFrameDebugJawGeometry
 * @property {boolean} [enabled]
 * @property {boolean} [neutralReady]
 * @property {number} [semanticOpen] — 张嘴语义 0～100（独立 jaw 通道）
 * @property {number | {jaw?: number}} [rigWrite]
 * @property {number} [smoothSemantic]
 * @property {number} [raw]
 * @property {number} [curved]
 * @property {number} [jawSigned]
 * @property {number} [jawSmooth]
 * @property {"3d" | "2d_fallback" | string} [coordinateMode]
 * @property {string} [skipped]
 * @property {Record<string, unknown>} [pose]
 * @property {Record<string, unknown>} [poseGate]
 * @property {Record<string, unknown>} [neutralState]
 * @property {Record<string, unknown>} [components]
 * @property {Record<string, unknown>} [gating]
 * @property {Record<string, unknown>} [curve]
 * @property {Record<string, unknown>} [stabilizer]
 * @property {{ internalOpenPositive?: boolean, jawOutputSign?: number, rigOpenNegative?: boolean, yAxisTowardChin?: boolean }} [signConvention]
 */

/**
 * @typedef {Object} RigFrameDebug
 * @property {RigFrameDebugBlendshapes} [blendshapes]
 * @property {RigFrameDebugMapping} [mapping]
 * @property {RigFrameDebugGaze} [gaze]
 * @property {RigFrameDebugLipGeometry} [lipGeometry]
 * @property {RigFrameDebugJawGeometry} [jawGeometry]
 */

/**
 * @typedef {Object} RigFrame
 * @property {"tracking.rigFrame"} type
 * @property {"none"|"mediapipe-web"|"python-websocket"|"python-mediapipe"|string} source
 * @property {number} timestampMs
 * @property {number} [frameSeq] — 服务端单调序号，用于丢帧检测
 * @property {number} [serverSentAtMs] — 服务端发送时刻（毫秒 epoch）
 * @property {boolean} faceDetected
 * @property {number} quality
 * @property {EliteRigState} rig
 * @property {RigFrameDebug} [debug] — Python MediaPipe 等可选调试；不参与 rig 驱动与舵机。
 */

/**
 * @typedef {Object} TrackingStatus
 * @property {boolean} running
 * @property {string} source
 * @property {boolean} faceDetected
 * @property {number} fps
 * @property {number} quality
 * @property {number} lastFrameAt
 * @property {string | null} error
 */

/**
 * @typedef {Object} TrackingAdapter
 * @property {() => void} start
 * @property {() => void} stop
 * @property {() => void} dispose
 * @property {() => boolean} isRunning
 * @property {(cb: (frame: RigFrame) => void) => void} onFrame
 * @property {(cb: (frame: RigFrame) => void) => void} offFrame
 * @property {() => TrackingStatus} getStatus
 * @property {() => void} [clearState]
 */

/**
 * @returns {RigFrame}
 */
export function createEmptyRigFrame() {
  return {
    type: TRACKING_FRAME_TYPE,
    source: "none",
    timestampMs: 0,
    faceDetected: false,
    quality: 0,
    rig: createInitialEliteRig(),
  }
}
