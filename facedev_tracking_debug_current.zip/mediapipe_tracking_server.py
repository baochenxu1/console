"""
MediaPipe Face Landmarker + WebSocket：输出统一 tracking.rigFrame（source=python-mediapipe）。
不写舵机、不涉及绑定与 WebSerial。
阶段 2.5：mapping JSON、debug 字段、命令行中性脸校准。
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import copy
import json
import signal
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

import cv2
import numpy as np

try:
    import mediapipe as mp
except ImportError as exc:  # pragma: no cover
    print(
        "错误：未安装 mediapipe。请执行: pip install -r requirements.txt\n"
        f"原始错误: {exc}",
        file=sys.stderr,
    )
    sys.exit(3)

import websockets

try:
    from websockets.exceptions import ConnectionClosed
except ImportError:  # pragma: no cover
    ConnectionClosed = Exception  # type: ignore[misc,assignment]

from mediapipe_mapping_config import load_mapping_config, save_mapping_config
from jaw_geometry import (
    create_jaw_geometry_state,
    reset_jaw_geometry_state,
    start_jaw_neutral_calibration,
)
from lip_geometry import (
    create_lip_geometry_state,
    reset_lip_geometry_state,
    start_lip_neutral_calibration,
)
from mediapipe_to_rig import (
    create_neutral_rig,
    estimate_eye_gaze_from_landmarks,
    estimate_tracking_quality,
    extract_debug_blendshapes,
    extract_landmarks,
    mediapipe_result_to_rig,
)
from preview_landmark_overlay import (
    PreviewOverlayConfig,
    draw_preview_landmark_overlay,
    resolve_preview_overlay_config,
)

TRACKING_FRAME_TYPE = "tracking.rigFrame"
SOURCE = "python-mediapipe"

_SCRIPT_DIR = Path(__file__).resolve().parent
_DEFAULT_MAPPING = _SCRIPT_DIR / "mediapipe_mapping.default.json"
_DEFAULT_SAVE_MAPPING = _SCRIPT_DIR / "models" / "mediapipe_mapping.json"
_CALIB_FRAMES = 30
_DEFAULT_PREVIEW_PATH = "/preview.mjpg"

_FPS_WINDOW_SEC = 0.55


class _SlidingFps:
    """滑窗内事件 tick 次数 → 近似 FPS（与前端 adapter 500ms 窗口同量级）。"""

    __slots__ = ("_w", "_t")

    def __init__(self, window_sec: float = _FPS_WINDOW_SEC) -> None:
        self._w = float(window_sec)
        self._t: list[float] = []

    def tick(self) -> None:
        now = time.perf_counter()
        self._t.append(now)
        self._trim(now)

    def _trim(self, now: float) -> None:
        while self._t and now - self._t[0] > self._w:
            self._t.pop(0)

    def fps(self) -> float:
        now = time.perf_counter()
        self._trim(now)
        if len(self._t) < 2:
            return 0.0
        return (len(self._t) - 1) / max(1e-9, self._t[-1] - self._t[0])


def _handle_tracking_control_message(session: Any, message: str) -> None:
    """客户端 tracking.control 消息（如 Set Lip Neutral）。"""
    try:
        data = json.loads(message)
    except (json.JSONDecodeError, TypeError):
        return
    if not isinstance(data, dict) or data.get("type") != "tracking.control":
        return
    action = str(data.get("action") or "").strip()
    if action in (
        "resetLipNeutral",
        "setLipNeutral",
        "resetLipGeometry",
        "autoLipNeutralOnStart",
    ):
        reason = str(data.get("reason") or action)
        start_lip_neutral_calibration(getattr(session, "_lip_state", None), reason)
        start_jaw_neutral_calibration(getattr(session, "_jaw_state", None), reason)
        print(f"[mediapipe] mouth (lip+jaw) neutral calibration started ({reason})", flush=True)


def _connection_path(websocket) -> str:
    req = getattr(websocket, "request", None)
    if req is not None:
        return getattr(req, "path", "/") or "/"
    return getattr(websocket, "path", "/") or "/"


def _parse_fourcc_arg(s: str) -> int | None:
    t = (s or "").strip().upper()
    if len(t) < 4:
        return None
    return cv2.VideoWriter_fourcc(t[0], t[1], t[2], t[3])


def _fourcc_prop_to_str(v: float) -> str:
    try:
        i = int(round(float(v)))
        return "".join(chr((i >> (8 * k)) & 0xFF) for k in range(4)).strip("\x00") or "?"
    except Exception:
        return "?"


def _open_video_capture(camera_index: int, backend: str) -> tuple[Any, str]:
    b = (backend or "auto").strip().lower()
    api: int | None = None
    name = "ANY"
    if b == "dshow" and hasattr(cv2, "CAP_DSHOW"):
        api = int(cv2.CAP_DSHOW)
        name = "DSHOW"
    elif b == "msmf" and hasattr(cv2, "CAP_MSMF"):
        api = int(cv2.CAP_MSMF)
        name = "MSMF"
    elif b == "auto" and sys.platform == "win32" and hasattr(cv2, "CAP_DSHOW"):
        api = int(cv2.CAP_DSHOW)
        name = "DSHOW"
    if api is not None:
        cap = cv2.VideoCapture(camera_index, api)
    else:
        cap = cv2.VideoCapture(camera_index)
        name = "ANY"
    return cap, name


def _print_camera_props(
    cap: Any,
    *,
    req_w: int,
    req_h: int,
    req_fps: float,
    fourcc_req: str,
    backend_name: str,
    buffer_req: int,
) -> None:
    try:
        aw = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        ah = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        afps = float(cap.get(cv2.CAP_PROP_FPS))
        buf = int(cap.get(cv2.CAP_PROP_BUFFERSIZE))
        fcv = float(cap.get(cv2.CAP_PROP_FOURCC))
        fstr = _fourcc_prop_to_str(fcv)
    except Exception:
        aw = ah = 0
        afps = 0.0
        buf = 0
        fstr = "?"
    fq = (fourcc_req or "").strip().upper() or "—"
    print(
        f"[CAMERA] requested={req_w}x{req_h}@{req_fps:g} fourcc={fq} backend={backend_name} buffer={buffer_req}",
        flush=True,
    )
    print(
        f"[CAMERA] actual={aw}x{ah} fps={afps:g} fourcc={fstr} backend={backend_name} buffer={buf}",
        flush=True,
    )


def _resolve_mp_image_api():
    Image = getattr(mp, "Image", None)
    ImageFormat = getattr(mp, "ImageFormat", None)
    if Image is not None and ImageFormat is not None:
        return Image, ImageFormat
    raise RuntimeError(
        "当前 mediapipe 版本缺少 mp.Image / mp.ImageFormat。\n"
        "请升级 mediapipe>=0.10（见 requirements.txt）。"
    )


def _resolve_face_landmarker_api():
    try:
        BaseOptions = mp.tasks.BaseOptions
        FaceLandmarker = mp.tasks.vision.FaceLandmarker
        FaceLandmarkerOptions = mp.tasks.vision.FaceLandmarkerOptions
        RunningMode = mp.tasks.vision.RunningMode
    except AttributeError as exc:  # pragma: no cover
        raise RuntimeError(
            "mediapipe.tasks API 不可用；请安装 mediapipe>=0.10。\n" f"详情: {exc}"
        ) from exc
    return BaseOptions, FaceLandmarker, FaceLandmarkerOptions, RunningMode


def _make_frame_dict(
    *,
    timestamp_ms: float,
    face_detected: bool,
    quality: float,
    rig: dict,
    debug: dict | None = None,
) -> dict:
    d: dict = {
        "type": TRACKING_FRAME_TYPE,
        "source": SOURCE,
        "timestampMs": timestamp_ms,
        "faceDetected": bool(face_detected),
        "quality": float(quality),
        "rig": rig,
    }
    if face_detected and debug is not None:
        d["debug"] = debug
    return d


def _compact_frame_dict(d: dict) -> dict:
    """仅保留实时驱动与轻量 performance；不含 blendshapes / mapping / gaze。"""
    out: dict = {
        "type": d["type"],
        "source": d["source"],
        "timestampMs": d["timestampMs"],
        "faceDetected": bool(d["faceDetected"]),
        "quality": float(d["quality"]),
        "rig": d["rig"],
    }
    if "frameSeq" in d:
        out["frameSeq"] = int(d["frameSeq"])
    if "serverSentAtMs" in d:
        out["serverSentAtMs"] = float(d["serverSentAtMs"])
    dbg = d.get("debug")
    if isinstance(dbg, dict) and isinstance(dbg.get("performance"), dict):
        p = dbg["performance"]
        slim: dict[str, Any] = {}
        for k in (
            "fps",
            "broadcastFps",
            "broadcastFrameSeq",
            "captureFps",
            "inferenceFps",
            "mappingFps",
            "generatedFrameFps",
            "jsonEncodeFps",
            "broadcastAttemptFps",
            "broadcastSuccessFps",
            "perClientSendFps",
            "clientCount",
            "loopMs",
            "captureMs",
            "capReadMs",
            "preprocessMs",
            "inferenceMs",
            "mappingMs",
            "encodeMs",
            "jsonEncodeMs",
            "broadcastMs",
            "sleepMs",
            "totalPeriodMs",
            "targetIntervalMs",
        ):
            if k in p and p[k] is not None:
                slim[k] = p[k]
        if "frameSeq" in p and p["frameSeq"] is not None:
            slim["frameSeq"] = p["frameSeq"]
        if "broadcastSeq" in p and p["broadcastSeq"] is not None:
            slim["broadcastSeq"] = p["broadcastSeq"]
        out["debug"] = {"performance": slim}
    return out


def _ema_merge_rig(prev: dict | None, new: dict, alpha: float) -> dict:
    """对 rig 树形数值做指数平滑。"""
    if not prev:
        return copy.deepcopy(new)
    a = max(0.0, min(1.0, float(alpha)))
    out: dict = {}
    for k, v in new.items():
        if isinstance(v, dict):
            out[k] = _ema_merge_rig(prev.get(k) if isinstance(prev.get(k), dict) else None, v, alpha)
        elif isinstance(v, (int, float)):
            pv = prev.get(k)
            pv = float(pv) if isinstance(pv, (int, float)) else float(v)
            out[k] = pv + a * (float(v) - pv)
        else:
            out[k] = v
    return out


def _average_blendshape_samples(samples: list[dict[str, float]]) -> dict[str, float]:
    if not samples:
        return {}
    keys = list(samples[0].keys())
    out: dict[str, float] = {}
    n = len(samples)
    for k in keys:
        out[k] = sum(float(s.get(k, 0.0)) for s in samples) / n
    return out


class MediapipeTrackingSession:
    """摄像头 + FaceLandmarker（VIDEO 模式），生成 JSON 字符串载荷。"""

    def __init__(
        self,
        *,
        model_path: Path,
        camera_index: int,
        interval_sec: float,
        mapping_config_path: Path,
        save_mapping_path: Path,
        calibrate_neutral: bool,
        frame_width: int = 640,
        frame_height: int = 480,
        payload_mode: str = "full",
        camera_fps: float = 30.0,
        fourcc: str = "MJPG",
        buffer_size: int = 1,
        camera_backend: str = "auto",
        preview_overlay: PreviewOverlayConfig | None = None,
    ) -> None:
        self._process_interval_sec = max(0.0, float(interval_sec))
        if interval_sec > 1e-12:
            self._interval_ms = max(1, int(round(interval_sec * 1000)))
        else:
            self._interval_ms = 0
        self._last_video_wall: float | None = None
        self._timing_for_next_build: dict[str, float] | None = None
        self._mapping_config_path = mapping_config_path
        self._save_mapping_path = save_mapping_path
        self._calibrate_neutral = bool(calibrate_neutral)
        self._payload_mode = str(payload_mode or "full").lower().strip()
        if self._payload_mode not in ("full", "compact"):
            self._payload_mode = "full"
        self._calib_samples: list[dict[str, float]] = []
        self._calib_gaze_samples: list[tuple[float, float]] = []
        self._calib_done = not bool(calibrate_neutral)
        self._last_smoothed_rig: dict | None = None
        self._gaze_state: dict[str, Any] = {"last_valid": None, "last_emit": {"x": 50.0, "y": 50.0}}
        self._lip_state: dict[str, Any] = create_lip_geometry_state()
        self._jaw_state: dict[str, Any] = create_jaw_geometry_state()
        self._perf_base: dict[str, float] = {}
        self._prev_broadcast_ms: float | None = None
        self._prev_json_encode_ms: float | None = None
        self._prev_loop_ms: float | None = None
        self._prev_fps: float | None = None
        self._perf_log_anchor = time.perf_counter()
        self._perf_log_acc = {
            "capture": 0.0,
            "infer": 0.0,
            "map": 0.0,
            "bc": 0.0,
            "enc": 0.0,
            "loop": 0.0,
            "payload": 0.0,
            "clients_max": 0,
            "cap_read": 0.0,
            "pre": 0.0,
            "sleep": 0.0,
            "period": 0.0,
            "n": 0.0,
        }
        self._frame_seq = 0
        self._broadcast_seq = 0
        self._extras_for_next_frame: dict[str, Any] | None = None
        self._last_broadcast_fps_for_perf = 0.0
        self._win = _FPS_WINDOW_SEC
        self._m_capture = _SlidingFps(self._win)
        self._m_inference = _SlidingFps(self._win)
        self._m_mapping = _SlidingFps(self._win)
        self._m_generated = _SlidingFps(self._win)
        self._m_json = _SlidingFps(self._win)
        self._m_bc_attempt = _SlidingFps(self._win)
        self._m_bc_success = _SlidingFps(self._win)
        self._preview_lock = threading.Lock()
        self._latest_preview_frame: np.ndarray | None = None
        self._preview_overlay = preview_overlay or PreviewOverlayConfig()

        self._config = load_mapping_config(mapping_config_path)

        self._cap, backend_used = _open_video_capture(camera_index, camera_backend)
        if not self._cap.isOpened():
            print(
                f"错误：无法打开摄像头 index={camera_index}。\n"
                "尝试其它设备号，例如: python mediapipe_tracking_server.py --camera 1",
                file=sys.stderr,
            )
            sys.exit(4)
        fw = max(160, int(frame_width))
        fh = max(120, int(frame_height))
        cfps = max(1.0, float(camera_fps))
        bsz = max(1, int(buffer_size))
        try:
            self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, float(fw))
            self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, float(fh))
            self._cap.set(cv2.CAP_PROP_FPS, float(cfps))
            self._cap.set(cv2.CAP_PROP_BUFFERSIZE, float(bsz))
        except Exception:
            pass
        fcc = _parse_fourcc_arg(fourcc)
        if fcc is not None:
            try:
                self._cap.set(cv2.CAP_PROP_FOURCC, fcc)
            except Exception:
                pass
        _print_camera_props(
            self._cap,
            req_w=fw,
            req_h=fh,
            req_fps=cfps,
            fourcc_req=str(fourcc),
            backend_name=backend_used,
            buffer_req=bsz,
        )

        BaseOptions, FaceLandmarker, FaceLandmarkerOptions, RunningMode = (
            _resolve_face_landmarker_api()
        )
        opts_kw = dict(
            base_options=BaseOptions(model_asset_path=str(model_path.resolve())),
            running_mode=RunningMode.VIDEO,
            num_faces=1,
            output_face_blendshapes=True,
            output_facial_transformation_matrixes=True,
        )
        try:
            opts = FaceLandmarkerOptions(**opts_kw, output_face_landmarks=True)
        except TypeError:
            opts = FaceLandmarkerOptions(**opts_kw)
        self._landmarker = FaceLandmarker.create_from_options(opts)
        self._Image, self._ImageFormat = _resolve_mp_image_api()
        self._video_ts_ms = 0

        if self._calibrate_neutral:
            print(
                "[mediapipe] 已启用 --calibrate-neutral：请在摄像头前保持中性表情，"
                f"将连续采集 {_CALIB_FRAMES} 帧 blendshape，并在 gaze（iris）可用时写入 neutral.eyeLookX/Y，"
                "然后写入 neutral 并保存到 --save-mapping。",
                flush=True,
            )

    def publish_preview_frame(self, frame: np.ndarray) -> None:
        """供 MJPEG 预览读取的最新 BGR 帧（与 tracking 同一次 cap.read，不额外开摄像头）。"""
        with self._preview_lock:
            self._latest_preview_frame = frame.copy()

    def _finalize_preview_frame(
        self,
        frame: np.ndarray,
        *,
        result: Any | None = None,
        face_detected: bool = False,
    ) -> None:
        """推理后发布 MJPEG 帧；overlay 在 BGR 副本上绘制，不进入 WebSocket。"""
        out = frame
        if self._preview_overlay.enabled and face_detected and result is not None:
            lm = extract_landmarks(result)
            if lm is not None:
                out = frame.copy()
                draw_preview_landmark_overlay(
                    out, lm, self._preview_overlay, self._config
                )
        self.publish_preview_frame(out)

    def encode_preview_jpeg(self, quality: int = 60) -> bytes | None:
        with self._preview_lock:
            frame = self._latest_preview_frame
            if frame is None:
                return None
            img = frame.copy()
        q = max(1, min(100, int(quality)))
        ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), q])
        if not ok:
            return None
        return buf.tobytes()

    def close(self) -> None:
        self._reset_mouth_geometry_state()
        with self._preview_lock:
            self._latest_preview_frame = None
        try:
            self._cap.release()
        except Exception:
            pass
        closer = getattr(self._landmarker, "close", None)
        if callable(closer):
            try:
                closer()
            except Exception:
                pass

    def _maybe_calibrate(self, result: Any) -> None:
        if self._calib_done or not self._calibrate_neutral:
            return
        blend = extract_debug_blendshapes(result)
        self._calib_samples.append(blend)
        try:
            ginfo = estimate_eye_gaze_from_landmarks(result, self._config)
            if ginfo.get("available"):
                self._calib_gaze_samples.append(
                    (float(ginfo["eyeLookX"]), float(ginfo["eyeLookY"]))
                )
        except Exception:
            pass
        n = len(self._calib_samples)
        if n % 10 == 0 or n == _CALIB_FRAMES:
            print(f"[mediapipe] 中性脸校准采集中… 已采集 {n}/{_CALIB_FRAMES} 帧", flush=True)
        if n < _CALIB_FRAMES:
            return
        avg = _average_blendshape_samples(self._calib_samples)
        neutral = self._config.setdefault("neutral", {})
        for k, v in avg.items():
            neutral[k] = float(v)
        if self._calib_gaze_samples:
            n_g = len(self._calib_gaze_samples)
            ax = sum(t[0] for t in self._calib_gaze_samples) / n_g
            ay = sum(t[1] for t in self._calib_gaze_samples) / n_g
            neutral["eyeLookX"] = float(ax)
            neutral["eyeLookY"] = float(ay)
        save_mapping_config(self._save_mapping_path, self._config)
        self._calib_done = True
        self._calib_samples.clear()
        self._calib_gaze_samples.clear()
        print(
            "[mediapipe] 中性脸校准完成，已写入 neutral 并保存到:",
            str(self._save_mapping_path.resolve()),
            flush=True,
        )

    def _reset_gaze_state(self) -> None:
        self._gaze_state = {"last_valid": None, "last_emit": {"x": 50.0, "y": 50.0}}

    def _reset_mouth_geometry_state(self) -> None:
        reset_lip_geometry_state(self._lip_state)
        reset_jaw_geometry_state(self._jaw_state)

    def finalize_extras_after_wire(
        self,
        *,
        frame_seq: int,
        broadcast_seq: int,
        json_encode_ms: float,
        broadcast_send_ms: float,
        clients: int,
        successful_sends: int,
    ) -> None:
        """序列化 + 广播完成后更新滑窗计数，并写入下一帧 build 可读的 transport 统计。"""
        self._prev_json_encode_ms = float(json_encode_ms)
        self._prev_broadcast_ms = float(broadcast_send_ms)
        self._m_json.tick()
        self._m_bc_attempt.tick()
        for _ in range(max(0, int(successful_sends))):
            self._m_bc_success.tick()
        bs_ok = float(self._m_bc_success.fps())
        self._last_broadcast_fps_for_perf = bs_ok
        cc = max(0, int(clients))
        per_client = bs_ok / max(1, cc) if cc > 0 else 0.0
        self._extras_for_next_frame = {
            "jsonEncodeFps": round(float(self._m_json.fps()), 2),
            "broadcastAttemptFps": round(float(self._m_bc_attempt.fps()), 2),
            "broadcastSuccessFps": round(bs_ok, 2),
            "broadcastFps": round(bs_ok, 2),
            "broadcastFrameSeq": int(frame_seq),
            "perClientSendFps": round(per_client, 2),
            "clientCount": cc,
            "frameSeq": int(frame_seq),
            "broadcastSeq": int(broadcast_seq),
            "encodeMs": round(float(json_encode_ms), 2),
            "jsonEncodeMs": round(float(json_encode_ms), 2),
        }

    def record_post_send_perf(
        self,
        broadcast_send_ms: float,
        loop_ms: float,
        *,
        clients: int = 0,
        payload_bytes: int = 0,
        json_encode_ms: float = 0.0,
        sleep_ms: float = 0.0,
        total_period_ms: float = 0.0,
    ) -> None:
        """记录本帧序列化+广播耗时；每约 2s 打印摘要。fps 不再用 1000/loop_ms（不含 sleep，会虚高）。"""
        self._prev_loop_ms = float(loop_ms)
        self._prev_fps = float(self._m_generated.fps()) if self._m_generated.fps() > 0 else None
        acc = self._perf_log_acc
        acc["n"] += 1.0
        pb = self._perf_base
        acc["capture"] += float(pb.get("captureMs", 0.0))
        acc["cap_read"] += float(pb.get("capReadMs", pb.get("captureMs", 0.0)))
        acc["pre"] += float(pb.get("preprocessMs", 0.0))
        acc["infer"] += float(pb.get("inferenceMs", 0.0))
        acc["map"] += float(pb.get("mappingMs", 0.0))
        acc["bc"] += float(broadcast_send_ms)
        acc["enc"] += float(json_encode_ms)
        acc["loop"] += float(loop_ms)
        acc["payload"] += float(max(0, int(payload_bytes)))
        acc["clients_max"] = max(int(acc.get("clients_max", 0)), int(max(0, clients)))
        acc["sleep"] += float(sleep_ms)
        acc["period"] += float(total_period_ms)
        now = time.perf_counter()
        if now - self._perf_log_anchor < 2.0:
            return
        n = max(1.0, acc["n"])
        cap_fp = self._m_capture.fps()
        inf_fp = self._m_inference.fps()
        map_fp = self._m_mapping.fps()
        gen_fp = self._m_generated.fps()
        enc_fp = self._m_json.fps()
        att_fp = self._m_bc_attempt.fps()
        suc_fp = self._m_bc_success.fps()
        payload_kb = (acc["payload"] / n) / 1024.0
        print(
            f"[PERF] captureFps={cap_fp:.1f} inferFps={inf_fp:.1f} mapFps={map_fp:.1f} genFps={gen_fp:.1f} "
            f"encodeFps={enc_fp:.1f} broadcastAttemptFps={att_fp:.1f} broadcastSuccessFps={suc_fp:.1f} "
            f"clients={int(acc['clients_max'])} payload={payload_kb:.1f}KB "
            f"capRead={acc['cap_read'] / n:.0f}ms sleep={acc['sleep'] / n:.0f}ms period={acc['period'] / n:.0f}ms "
            f"infer={acc['infer'] / n:.0f}ms encode={acc['enc'] / n:.0f}ms send={acc['bc'] / n:.0f}ms loop={acc['loop'] / n:.0f}ms",
            flush=True,
        )
        self._perf_log_anchor = now
        self._perf_log_acc = {
            "capture": 0.0,
            "infer": 0.0,
            "map": 0.0,
            "bc": 0.0,
            "enc": 0.0,
            "loop": 0.0,
            "payload": 0.0,
            "clients_max": 0,
            "cap_read": 0.0,
            "pre": 0.0,
            "sleep": 0.0,
            "period": 0.0,
            "n": 0.0,
        }

    def _build_common_performance_fragment(self) -> dict[str, Any]:
        pb = self._perf_base or {}
        cap_read = float(pb.get("capReadMs", pb.get("captureMs", 0.0)))
        pre_ms = float(pb.get("preprocessMs", 0.0))
        inf_ms = float(pb.get("inferenceMs", 0.0))
        map_ms = float(pb.get("mappingMs", 0.0))
        gf = round(float(self._m_generated.fps()), 2)
        p_perf: dict[str, Any] = {
            "capReadMs": round(cap_read, 2),
            "preprocessMs": round(pre_ms, 2),
            "inferenceMs": round(inf_ms, 2),
            "mappingMs": round(map_ms, 2),
            "captureMs": round(cap_read + pre_ms, 2),
            "captureFps": round(float(self._m_capture.fps()), 2),
            "inferenceFps": round(float(self._m_inference.fps()), 2),
            "mappingFps": round(float(self._m_mapping.fps()), 2),
            "generatedFrameFps": gf,
            "fps": gf,
        }
        tm = self._timing_for_next_build
        if isinstance(tm, dict):
            for key in ("totalPeriodMs", "sleepMs", "targetIntervalMs"):
                if tm.get(key) is not None:
                    p_perf[key] = round(float(tm[key]), 2)
        ex = self._extras_for_next_frame
        if isinstance(ex, dict):
            for key in (
                "jsonEncodeFps",
                "broadcastAttemptFps",
                "broadcastSuccessFps",
                "broadcastFps",
                "broadcastFrameSeq",
                "perClientSendFps",
                "clientCount",
                "encodeMs",
                "jsonEncodeMs",
                "frameSeq",
                "broadcastSeq",
            ):
                if ex.get(key) is not None:
                    p_perf[key] = ex[key]
        if self._prev_broadcast_ms is not None:
            p_perf["broadcastMs"] = round(float(self._prev_broadcast_ms), 2)
        else:
            p_perf["broadcastMs"] = None
        if self._prev_loop_ms is not None:
            p_perf["loopMs"] = round(float(self._prev_loop_ms), 2)
        else:
            p_perf["loopMs"] = None
        return p_perf

    def decorate_frame_performance_after_build(self, d: dict) -> None:
        """无人脸等无 debug.performance 的帧，补上与有人脸一致的 performance 块。"""
        dbg = d.get("debug")
        if isinstance(dbg, dict) and isinstance(dbg.get("performance"), dict):
            return
        d.setdefault("debug", {})["performance"] = self._build_common_performance_fragment()

    def build_frame_dict(self) -> dict:
        now_ms = time.time() * 1000.0
        cap_t0 = time.perf_counter()
        ok, frame = self._cap.read()
        cap_read_ms = (time.perf_counter() - cap_t0) * 1000.0
        self._m_capture.tick()

        if not ok or frame is None:
            self._perf_base = {
                "capReadMs": cap_read_ms,
                "preprocessMs": 0.0,
                "inferenceMs": 0.0,
                "mappingMs": 0.0,
                "captureMs": cap_read_ms,
            }
            self._last_smoothed_rig = None
            self._m_generated.tick()
            if frame is not None:
                self._finalize_preview_frame(frame, face_detected=False)
            return _make_frame_dict(
                timestamp_ms=now_ms,
                face_detected=False,
                quality=0.0,
                rig=create_neutral_rig(),
                debug=None,
            )

        pp_t0 = time.perf_counter()
        rgb = np.ascontiguousarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        preprocess_ms = (time.perf_counter() - pp_t0) * 1000.0
        vw = time.perf_counter()
        if self._interval_ms > 0:
            self._video_ts_ms += self._interval_ms
        else:
            if self._last_video_wall is None:
                self._video_ts_ms += 33
            else:
                self._video_ts_ms += max(1, int((vw - self._last_video_wall) * 1000))
        self._last_video_wall = vw
        mp_image = self._Image(image_format=self._ImageFormat.SRGB, data=rgb)
        inf_t0 = time.perf_counter()
        result = self._landmarker.detect_for_video(mp_image, self._video_ts_ms)
        inference_ms = (time.perf_counter() - inf_t0) * 1000.0
        self._m_inference.tick()

        lm = getattr(result, "face_landmarks", None)
        face_detected = False
        if lm is not None:
            try:
                face_detected = len(lm) > 0
            except TypeError:
                face_detected = bool(lm)

        if not face_detected:
            self._reset_gaze_state()
            self._reset_mouth_geometry_state()
            self._last_smoothed_rig = None
            self._perf_base = {
                "capReadMs": cap_read_ms,
                "preprocessMs": preprocess_ms,
                "inferenceMs": inference_ms,
                "mappingMs": 0.0,
                "captureMs": cap_read_ms + preprocess_ms,
            }
            self._m_generated.tick()
            self._finalize_preview_frame(frame, result=result, face_detected=False)
            return _make_frame_dict(
                timestamp_ms=now_ms,
                face_detected=False,
                quality=0.0,
                rig=create_neutral_rig(),
                debug=None,
            )

        self._maybe_calibrate(result)
        map_t0 = time.perf_counter()
        pack = mediapipe_result_to_rig(
            result,
            self._config,
            self._gaze_state,
            self._lip_state,
            self._jaw_state,
            timestamp_ms=now_ms,
        )
        rig = pack["rig"]
        dbg = pack.get("debug") or {}
        sm = self._config.get("smoothing") or {}
        if bool(sm.get("enabled")):
            alpha = float(sm.get("alpha", 0.35))
            rig = _ema_merge_rig(self._last_smoothed_rig, rig, alpha)
            self._last_smoothed_rig = copy.deepcopy(rig)
        else:
            self._last_smoothed_rig = copy.deepcopy(rig)
        mapping_ms = (time.perf_counter() - map_t0) * 1000.0
        self._m_mapping.tick()
        self._perf_base = {
            "capReadMs": cap_read_ms,
            "preprocessMs": preprocess_ms,
            "inferenceMs": inference_ms,
            "mappingMs": mapping_ms,
            "captureMs": cap_read_ms + preprocess_ms,
        }

        quality = estimate_tracking_quality(result, True)

        if isinstance(dbg, dict):
            self._m_generated.tick()
            dbg["performance"] = self._build_common_performance_fragment()

        self._finalize_preview_frame(frame, result=result, face_detected=True)
        return _make_frame_dict(
            timestamp_ms=now_ms,
            face_detected=True,
            quality=float(quality),
            rig=rig,
            debug=dbg,
        )

    def capture_json_payload(self) -> str:
        """兼容旧调用；推荐 WebSocket 泵使用 build_frame_dict 以附带完整 performance。"""
        return json.dumps(self.build_frame_dict())


class _MjpegPreviewHandler(BaseHTTPRequestHandler):
    """multipart/x-mixed-replace MJPEG；独立线程/连接，不阻塞 WebSocket 泵。"""

    def log_message(self, _format: str, *_args) -> None:
        return

    def do_GET(self) -> None:
        path = (self.path or "").split("?", 1)[0]
        if path != self.server.preview_path:  # type: ignore[attr-defined]
            self.send_error(404, "Not Found")
            return
        self.send_response(200)
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Connection", "close")
        self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
        self.end_headers()
        boundary = b"--frame\r\n"
        interval = float(self.server.frame_interval)  # type: ignore[attr-defined]
        quality = int(self.server.jpeg_quality)  # type: ignore[attr-defined]
        session: MediapipeTrackingSession = self.server.session  # type: ignore[attr-defined]
        try:
            while getattr(self.server, "running", False):  # type: ignore[attr-defined]
                jpeg = session.encode_preview_jpeg(quality)
                if jpeg:
                    try:
                        self.wfile.write(boundary)
                        self.wfile.write(b"Content-Type: image/jpeg\r\n\r\n")
                        self.wfile.write(jpeg)
                        self.wfile.write(b"\r\n")
                        self.wfile.flush()
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        break
                time.sleep(interval)
        except Exception:
            pass


class MjpegPreviewHttpServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def start_mjpeg_preview_server(
    session: MediapipeTrackingSession,
    *,
    host: str,
    port: int,
    path: str = _DEFAULT_PREVIEW_PATH,
    fps: float = 12.0,
    quality: int = 60,
) -> MjpegPreviewHttpServer:
    if not path.startswith("/"):
        path = "/" + path
    frame_interval = 1.0 / max(1e-3, float(fps))
    httpd = MjpegPreviewHttpServer((host, int(port)), _MjpegPreviewHandler)
    httpd.preview_path = path
    httpd.frame_interval = frame_interval
    httpd.jpeg_quality = int(quality)
    httpd.session = session
    httpd.running = True
    thread = threading.Thread(
        target=httpd.serve_forever,
        name="mjpeg-preview",
        daemon=True,
    )
    thread.start()
    print(
        f"[mediapipe_tracking_server] MJPEG preview: http://{host}:{port}{path} "
        f"fps={fps:g} quality={quality}",
        flush=True,
    )
    return httpd


def stop_mjpeg_preview_server(httpd: MjpegPreviewHttpServer | None) -> None:
    if httpd is None:
        return
    httpd.running = False
    with contextlib.suppress(Exception):
        httpd.shutdown()
    with contextlib.suppress(Exception):
        httpd.server_close()


async def run_server(
    *,
    host: str,
    port: int,
    ws_path: str,
    session: MediapipeTrackingSession,
    process_interval_sec: float,
    broadcast_interval_sec: float,
) -> None:
    connections: set = set()
    loop = asyncio.get_running_loop()
    stop = loop.create_future()

    def _shutdown(*_a) -> None:
        if not stop.done():
            stop.set_result(True)

    signal.signal(signal.SIGINT, _shutdown)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, _shutdown)

    async def handler(websocket) -> None:
        try:
            if _connection_path(websocket) != ws_path:
                await websocket.close(code=1008, reason="invalid path")
                return
        except Exception:
            await websocket.close(code=1011, reason="handshake error")
            return

        connections.add(websocket)
        try:
            async for message in websocket:
                if isinstance(message, str):
                    _handle_tracking_control_message(session, message)
        except ConnectionClosed:
            pass
        finally:
            connections.discard(websocket)

    # -------------------------------------------------------------------------
    # 单 asyncio.Task「泵」顺序结构（非 producer/consumer 双队列）：
    #
    #   await run_in_executor(build_frame_dict)
    #        └ 同步在同一线程池 worker：cap.read → detect_for_video → mapping
    #          （mediapipe_result_to_rig，含 gaze guard）
    #   decorate_frame_performance_after_build（无人脸时补 performance）
    #   若满足 broadcast 策略且存在客户端：
    #        frameSeq++ → json.dumps → 各客户端 await ws.send
    #   record_post_send_perf（含本轮 wall loop_ms；与上一帧 transport 合并进下一帧 JSON）
    #
    #   睡眠：
    #     --broadcast-interval > 0 时，两次「实际 send」之间至少间隔该秒数（无客户端时不发）。
    #     否则仅 sleep(max(0, --interval - elapsed))，其中 --interval 为「相邻两次 build
    #     调用」的最小墙钟间隔（默认 0.033s）；旧版把 asyncio.sleep 放在本轮末尾，会同时
    #     限制 MediaPipe 与 WebSocket；且 debug.performance.fps 曾用 1000/loop_ms（不含
    #     sleep）导致「Python 60 / Broadcast 16」的错觉，现已用滑窗 generatedFrameFps 等
    #     与 broadcastSuccessFps 区分。
    # -------------------------------------------------------------------------
    last_bcast_wall = 0.0

    async def pump() -> None:
        nonlocal last_bcast_wall
        proc_iv = max(0.0, float(process_interval_sec))
        b_iv = max(0.0, float(broadcast_interval_sec))
        prev_iter_t0: float | None = None
        last_sleep_ms = 0.0

        while not stop.done():
            t_loop0 = time.perf_counter()
            total_period_ms = (t_loop0 - prev_iter_t0) * 1000.0 if prev_iter_t0 is not None else 0.0
            session._timing_for_next_build = {
                "totalPeriodMs": float(total_period_ms),
                "sleepMs": float(last_sleep_ms),
                "targetIntervalMs": float(proc_iv * 1000.0) if proc_iv > 1e-12 else 0.0,
            }
            prev_iter_t0 = t_loop0

            try:
                d = await loop.run_in_executor(None, session.build_frame_dict)
            except Exception as exc:  # pragma: no cover
                print(f"[mediapipe_tracking_server] 推理异常: {exc}", file=sys.stderr)
                d = _make_frame_dict(
                    timestamp_ms=time.time() * 1000,
                    face_detected=False,
                    quality=0.0,
                    rig=create_neutral_rig(),
                    debug=None,
                )
                session._perf_base = {
                    "capReadMs": 0.0,
                    "preprocessMs": 0.0,
                    "inferenceMs": 0.0,
                    "mappingMs": 0.0,
                    "captureMs": 0.0,
                }

            session.decorate_frame_performance_after_build(d)

            dead: list = []
            seq = int(getattr(session, "_frame_seq", 0))
            bc_seq = int(getattr(session, "_broadcast_seq", 0))
            json_ms = 0.0
            send_ms_total = 0.0
            succ = 0
            clients = len(connections)
            payload = ""
            did_send = False

            mon = time.monotonic()
            can_send = b_iv <= 1e-12 or (mon - last_bcast_wall) >= b_iv - 1e-12

            if can_send and clients > 0:
                try:
                    session._frame_seq += 1
                    seq = int(session._frame_seq)
                    d["frameSeq"] = seq
                    d["serverSentAtMs"] = time.time() * 1000.0
                    if getattr(session, "_payload_mode", "full") == "compact":
                        d = _compact_frame_dict(d)
                    t_j0 = time.perf_counter()
                    payload = json.dumps(d)
                    json_ms = (time.perf_counter() - t_j0) * 1000.0
                    t_send0 = time.perf_counter()
                    for ws in list(connections):
                        try:
                            await ws.send(payload)
                            succ += 1
                        except (ConnectionClosed, BrokenPipeError, ConnectionError):
                            dead.append(ws)
                        except Exception:
                            dead.append(ws)
                    send_ms_total = (time.perf_counter() - t_send0) * 1000.0
                    session._broadcast_seq += 1
                    bc_seq = int(session._broadcast_seq)
                    did_send = True
                    last_bcast_wall = time.monotonic()
                    session.finalize_extras_after_wire(
                        frame_seq=seq,
                        broadcast_seq=bc_seq,
                        json_encode_ms=json_ms,
                        broadcast_send_ms=send_ms_total,
                        clients=clients,
                        successful_sends=succ,
                    )
                except Exception as exc:  # pragma: no cover
                    print(f"[mediapipe_tracking_server] 发送异常: {exc}", file=sys.stderr)

            for ws in dead:
                connections.discard(ws)

            loop_ms = (time.perf_counter() - t_loop0) * 1000.0
            sleep_for_log = last_sleep_ms
            session.record_post_send_perf(
                send_ms_total if did_send else 0.0,
                loop_ms,
                clients=clients,
                payload_bytes=len(payload) if payload else 0,
                json_encode_ms=json_ms if did_send else 0.0,
                sleep_ms=sleep_for_log,
                total_period_ms=total_period_ms,
            )

            elapsed = time.perf_counter() - t_loop0
            last_sleep_ms = 0.0
            if proc_iv > 1e-12:
                t_slp = time.perf_counter()
                await asyncio.sleep(max(0.0, proc_iv - elapsed))
                last_sleep_ms = (time.perf_counter() - t_slp) * 1000.0

    pump_task = asyncio.create_task(pump())
    try:
        async with websockets.serve(handler, host, port):
            print(f"MediaPipe Tracking WS (Ctrl+C exit): ws://{host}:{port}{ws_path}")
            await stop
    finally:
        pump_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await pump_task


def parse_args(argv: list[str] | None) -> argparse.Namespace:
    default_model = _SCRIPT_DIR / "models" / "face_landmarker.task"
    p = argparse.ArgumentParser(description="MediaPipe Face Landmarker → WebSocket RigFrame")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8766)
    p.add_argument("--path", default="/tracking", help="WebSocket path，须与前端 URL 一致")
    p.add_argument("--camera", type=int, default=0)
    p.add_argument("--model", type=str, default=str(default_model), help="face_landmarker.task 路径")
    p.add_argument("--interval", type=float, default=0.033, help="相邻两次 build_frame_dict（含 WS）的最小墙钟间隔（秒），如 0.02 / 0；0 表示不为此 sleep")
    p.add_argument(
        "--broadcast-interval",
        type=float,
        default=0.0,
        help="两次实际 WebSocket send 之间的最小间隔（秒）；0=每帧有客户端则发（仅受 --interval 与摄像头/Mediapipe 耗时限制）",
    )
    p.add_argument(
        "--width",
        type=int,
        default=640,
        help="摄像头请求宽度（像素），如 640 / 320",
    )
    p.add_argument(
        "--height",
        type=int,
        default=480,
        help="摄像头请求高度（像素），如 480 / 240",
    )
    p.add_argument(
        "--mapping",
        type=str,
        default=str(_DEFAULT_MAPPING),
        help="映射 JSON 路径，默认 mediapipe_mapping.default.json",
    )
    p.add_argument(
        "--save-mapping",
        type=str,
        default=str(_DEFAULT_SAVE_MAPPING),
        help="中性脸校准保存路径，默认 models/mediapipe_mapping.json",
    )
    p.add_argument(
        "--calibrate-neutral",
        action="store_true",
        help="启动后采集中性脸 30 帧并更新 neutral 后保存到 --save-mapping",
    )
    p.add_argument(
        "--payload",
        choices=("full", "compact"),
        default="full",
        help="WebSocket 每帧 JSON：full=全部 debug；compact=仅 rig + 轻量 performance（低延迟联调）",
    )
    p.add_argument(
        "--camera-fps",
        type=float,
        default=30.0,
        help="CAP_PROP_FPS 请求值（驱动可能忽略）",
    )
    p.add_argument(
        "--fourcc",
        type=str,
        default="MJPG",
        help="CAP_PROP_FOURCC，4 字符如 MJPG；空字符串则跳过设置",
    )
    p.add_argument(
        "--buffer-size",
        type=int,
        default=1,
        help="CAP_PROP_BUFFERSIZE（低延迟建议 1）",
    )
    p.add_argument(
        "--camera-backend",
        choices=("auto", "dshow", "msmf"),
        default="auto",
        help="OpenCV 采集后端；Windows 下 auto 优先 DSHOW",
    )
    p.add_argument(
        "--preview-mjpeg",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="启用独立 HTTP MJPEG 预览（默认开；与 WebSocket tracking 双通道）",
    )
    p.add_argument(
        "--preview-host",
        default="127.0.0.1",
        help="MJPEG 预览监听地址",
    )
    p.add_argument("--preview-port", type=int, default=8767, help="MJPEG 预览端口")
    p.add_argument(
        "--preview-fps",
        type=float,
        default=12.0,
        help="MJPEG 编码/推送目标帧率（不阻塞 MediaPipe 主循环）",
    )
    p.add_argument(
        "--preview-quality",
        type=int,
        default=60,
        help="JPEG 质量 1–100",
    )
    p.add_argument(
        "--preview-path",
        default=_DEFAULT_PREVIEW_PATH,
        help="MJPEG URL 路径，默认 /preview.mjpg",
    )
    p.add_argument(
        "--preview-landmark-style",
        choices=("minimal", "mesh", "regions", "full"),
        default="minimal",
        help="MJPEG overlay 预设：minimal=少量关键点(默认)；mesh=网格；regions=分区轮廓；full=全部",
    )
    p.add_argument(
        "--preview-draw-landmarks",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="绘制 landmark 点（默认由 --preview-landmark-style 决定）",
    )
    p.add_argument(
        "--preview-draw-mesh",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="绘制 tessellation 网格（默认由 style 决定）",
    )
    p.add_argument(
        "--preview-draw-regions",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="绘制眼/唇/眉/脸廓等区域（默认由 style 决定）",
    )
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    model_path = Path(args.model)
    if not model_path.is_file():
        print(
            "错误：找不到 Face Landmarker 模型文件。\n"
            f"  期望路径: {model_path.resolve()}\n"
            "  请将 Google 提供的 face_landmarker.task 放到:\n"
            f"    {_SCRIPT_DIR / 'models' / 'face_landmarker.task'}\n"
            "  或使用 --model 指定绝对路径。\n"
            "  下载（官方存储桶，文件名以实际为准）:\n"
            "    https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task",
            file=sys.stderr,
        )
        sys.exit(2)

    mapping_path = Path(args.mapping)
    save_mapping_path = Path(args.save_mapping)

    preview_overlay = (
        resolve_preview_overlay_config(
            style=str(args.preview_landmark_style),
            draw_landmarks=args.preview_draw_landmarks,
            draw_mesh=args.preview_draw_mesh,
            draw_regions=args.preview_draw_regions,
        )
        if bool(args.preview_mjpeg)
        else PreviewOverlayConfig()
    )

    session = MediapipeTrackingSession(
        model_path=model_path,
        camera_index=args.camera,
        interval_sec=args.interval,
        mapping_config_path=mapping_path,
        save_mapping_path=save_mapping_path,
        calibrate_neutral=bool(args.calibrate_neutral),
        frame_width=int(args.width),
        frame_height=int(args.height),
        payload_mode=str(args.payload),
        camera_fps=float(args.camera_fps),
        fourcc=str(args.fourcc),
        buffer_size=int(args.buffer_size),
        camera_backend=str(args.camera_backend),
        preview_overlay=preview_overlay,
    )
    print(
        f"[mediapipe_tracking_server] payload={args.payload} "
        f"process_interval={args.interval}s broadcast_interval={args.broadcast_interval}s "
        f"camera_fps={args.camera_fps} fourcc={args.fourcc!r} buffer={args.buffer_size} backend={args.camera_backend}",
        flush=True,
    )
    if bool(args.preview_mjpeg) and preview_overlay.enabled:
        print(
            f"[mediapipe_tracking_server] preview overlay: style={preview_overlay.style} "
            f"landmarks={preview_overlay.draw_landmarks} mesh={preview_overlay.draw_mesh} "
            f"regions={preview_overlay.draw_regions}",
            flush=True,
        )
    preview_httpd: MjpegPreviewHttpServer | None = None
    if bool(args.preview_mjpeg):
        preview_httpd = start_mjpeg_preview_server(
            session,
            host=str(args.preview_host),
            port=int(args.preview_port),
            path=str(args.preview_path),
            fps=float(args.preview_fps),
            quality=int(args.preview_quality),
        )
    try:
        asyncio.run(
            run_server(
                host=args.host,
                port=args.port,
                ws_path=args.path,
                session=session,
                process_interval_sec=float(args.interval),
                broadcast_interval_sec=float(args.broadcast_interval),
            )
        )
    except KeyboardInterrupt:
        pass
    finally:
        stop_mjpeg_preview_server(preview_httpd)
        session.close()


if __name__ == "__main__":
    main()
