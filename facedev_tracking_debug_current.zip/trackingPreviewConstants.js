/** @typedef {'camera' | 'video' | 'motion-track'} TrackingPreviewTabId */
/** @typedef {'preview-only' | 'dry-run' | 'device-drive'} TrackingPreviewDriveMode */

export const TRACKING_PREVIEW_TABS = /** @type {const} */ ({
  CAMERA: "camera",
  VIDEO: "video",
  MOTION_TRACK: "motion-track",
})

export const TRACKING_PREVIEW_TAB_LABELS = {
  [TRACKING_PREVIEW_TABS.CAMERA]: "Camera Preview",
  [TRACKING_PREVIEW_TABS.VIDEO]: "Video Preview",
  [TRACKING_PREVIEW_TABS.MOTION_TRACK]: "Motion Track",
}

export const DRIVE_MODES = /** @type {const} */ ({
  PREVIEW_ONLY: "preview-only",
  DRY_RUN: "dry-run",
  DEVICE_DRIVE: "device-drive",
})

export const DRIVE_MODE_LABELS = {
  [DRIVE_MODES.PREVIEW_ONLY]: "Preview Only",
  [DRIVE_MODES.DRY_RUN]: "Dry Run",
  [DRIVE_MODES.DEVICE_DRIVE]: "Device Drive",
}

export const DEFAULT_WS_CAMERA = "ws://127.0.0.1:8766/tracking"

/** Phase 4.1-D：独立 MJPEG 预览通道（与 WebSocket tracking 端口分离） */
export const DEFAULT_PREVIEW_PORT = 8767
export const CAMERA_PREVIEW_PATH = "/preview.mjpg"
export const DEFAULT_CAMERA_PREVIEW_HTTP = `http://127.0.0.1:${DEFAULT_PREVIEW_PORT}${CAMERA_PREVIEW_PATH}`

/**
 * 由 WebSocket hostname + 固定 preview 端口推导 MJPEG URL。
 * @param {string} [wsUrl]
 * @param {number} [previewPort]
 */
export function buildCameraPreviewMjpegUrl(
  wsUrl = DEFAULT_WS_CAMERA,
  previewPort = DEFAULT_PREVIEW_PORT
) {
  try {
    const u = new URL(wsUrl)
    const host = u.hostname || "127.0.0.1"
    return `http://${host}:${previewPort}${CAMERA_PREVIEW_PATH}`
  } catch {
    return DEFAULT_CAMERA_PREVIEW_HTTP
  }
}

export const DEVICE_DRIVE_QUALITY_MIN = 0.5

/** Device Drive 实机下发默认策略（与表情页 realtime 对齐，避免 200ms 冷却导致卡顿） */
export const DEVICE_DRIVE_DEFAULTS = {
  maxSendFps: 25,
  jawMaxSendFps: 22,
  lipMaxSendFps: 15,
  /** 非嘴/下颌通道：沿用较小门槛 */
  minPwmDeltaUs: 3,
  jawMinPwmDeltaUs: 2,
  lipMinPwmDeltaUs: 8,
  /** 相同命令串去重；抑制唇/下颌细微重复定位 */
  sameCommandCooldownMs: 110,
  lipSameCommandCooldownMs: 120,
  jawSameCommandCooldownMs: 60,
  servoTimeMs: 40,
  dropStaleFrame: true,
}

export const TRACKING_DEVICE_DRIVE_STOP_DEFAULTS = {
  stopReturnNeutralEnabled: true,
  stopReturnNeutralTimeMs: 300,
  stopNeutralHoldMs: 180,
  /** "face-neutral" | "stop-servo" | "both" */
  stopReturnNeutralMode: "face-neutral",
}

export const DEVICE_DRIVE_ARM_CONFIRM_MESSAGE =
  "Device Drive — 实机下发\n\n" +
  "将向已绑定的全部舵机通道下发命令（含左右嘴角 FiveBar）。\n" +
  "请确认串口已连接、机构安全，并已 Start Camera Tracking。\n\n" +
  "无人脸、quality 过低或串口未连接时不会发送。\n\n" +
  "确定 Arm Device Drive？"

export const MOTION_TRACK_VERSION = "facedev.motionTrack.v1"
