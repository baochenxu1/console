import { useCallback, useEffect, useMemo, useRef } from "react"
import { createInitialEliteRig } from "../../../core/faceDofMapper.js"
import { loadFaceRigProfile, normalizeFaceRigProfile } from "../../../core/faceRigProfile.js"
import {
  applyTrackingCalibration,
  createDefaultTrackingCalibration,
} from "../../tracking/index.js"
import { buildTrackingDryRunResult } from "../../trackingPreview/buildTrackingDryRunResult.js"
import {
  createNeutralTrackingStatus,
  EMPTY_DRY_RUN_RESULT,
  resetTrackingPreviewToNeutral,
} from "../../trackingPreview/trackingPreviewNeutral.js"
import {
  DRIVE_MODES,
  DEFAULT_WS_CAMERA,
  TRACKING_PREVIEW_TABS,
} from "../../trackingPreview/trackingPreviewConstants.js"
import { useTrackingAdapterController } from "../useTrackingAdapterController.js"

/**
 * Phase 4.1-C：Camera WebSocket + Stop 回中 + 画面预览框架。
 */
export function useTrackingPreviewCamera({ configs = [], activeTab, driveMode }) {
  const ctrl = useTrackingAdapterController({ defaultWsUrl: DEFAULT_WS_CAMERA })
  const {
    trackingEnabled,
    setTrackingEnabled,
    wsUrlDraft,
    setWsUrlDraft,
    lastFrame,
    status,
    replaceWithWebSocket,
    clearLastFrame,
    sendTrackingControl,
    connectedUrl,
  } = ctrl

  const calibrationRef = useRef(createDefaultTrackingCalibration())
  const prevCalibratedRef = useRef(/** @type {import("../../tracking/trackingTypes.js").RigFrame | null} */ (null))
  const autoLipNeutralSentRef = useRef(false)

  const profile = useMemo(() => normalizeFaceRigProfile(loadFaceRigProfile()), [])
  const cameraActive = activeTab === TRACKING_PREVIEW_TABS.CAMERA
  const trackingLive = Boolean(cameraActive && trackingEnabled)

  const calibratedFrame = useMemo(() => {
    if (!trackingLive || !lastFrame || typeof lastFrame !== "object") {
      return null
    }
    const prev = prevCalibratedRef.current
    const calib = calibrationRef.current
    try {
      return applyTrackingCalibration(lastFrame, prev, calib)
    } catch {
      return lastFrame
    }
  }, [trackingLive, lastFrame])

  useEffect(() => {
    if (calibratedFrame) {
      prevCalibratedRef.current = calibratedFrame
    }
  }, [calibratedFrame])

  const previewRig = useMemo(() => {
    if (!trackingLive) {
      return createInitialEliteRig()
    }
    if (calibratedFrame?.rig && typeof calibratedFrame.rig === "object") {
      return calibratedFrame.rig
    }
    if (lastFrame?.rig && typeof lastFrame.rig === "object") {
      return lastFrame.rig
    }
    return createInitialEliteRig()
  }, [trackingLive, calibratedFrame, lastFrame])

  const mapping = useMemo(() => {
    if (!trackingLive) {
      return null
    }
    return lastFrame?.debug?.mapping ?? null
  }, [trackingLive, lastFrame])

  const lipGeometry = useMemo(() => {
    if (!trackingLive) {
      return null
    }
    return lastFrame?.debug?.lipGeometry ?? null
  }, [trackingLive, lastFrame])

  const jawGeometry = useMemo(() => {
    if (!trackingLive) {
      return null
    }
    return lastFrame?.debug?.jawGeometry ?? null
  }, [trackingLive, lastFrame])

  const dryRunResult = useMemo(() => {
    if (!trackingLive || driveMode !== DRIVE_MODES.DRY_RUN) {
      return { ...EMPTY_DRY_RUN_RESULT }
    }
    return buildTrackingDryRunResult({
      profile,
      rig: previewRig,
      configs,
    })
  }, [trackingLive, driveMode, profile, previewRig, configs])

  const trackingStatus = useMemo(() => {
    if (!trackingLive) {
      return createNeutralTrackingStatus()
    }
    const st = status
    return {
      source: st.source || "camera-mediapipe",
      running: Boolean(st.wsOpen || st.running),
      faceDetected: Boolean(st.faceDetected),
      quality: Number.isFinite(Number(st.quality)) ? Number(st.quality) : 0,
      fps: Number.isFinite(Number(st.fps)) ? Number(st.fps) : 0,
      pythonFps: st.pythonFps != null && Number.isFinite(Number(st.pythonFps)) ? Number(st.pythonFps) : null,
      rxFps: Number.isFinite(Number(st.rxFps)) ? Number(st.rxFps) : 0,
      rx: Number.isFinite(Number(st.receivedFrameCount)) ? Number(st.receivedFrameCount) : 0,
      error: st.error != null ? String(st.error) : "",
      lastAt: Number.isFinite(Number(st.lastFrameAt)) && st.lastFrameAt > 0 ? st.lastFrameAt : null,
      wsConnecting: Boolean(st.wsConnecting),
      wsOpen: Boolean(st.wsOpen),
    }
  }, [trackingLive, status])

  const resetPreviewToNeutral = useCallback(() => {
    return resetTrackingPreviewToNeutral({
      clearLastFrame,
      prevCalibratedRef,
    })
  }, [clearLastFrame])

  const requestLipNeutral = useCallback(() => {
    sendTrackingControl({ action: "resetLipNeutral", reason: "manual" })
  }, [sendTrackingControl])

  useEffect(() => {
    if (!trackingLive) {
      autoLipNeutralSentRef.current = false
      return
    }
    if (autoLipNeutralSentRef.current) {
      return
    }
    autoLipNeutralSentRef.current = true
    sendTrackingControl({
      action: "autoLipNeutralOnStart",
      reason: "startCameraTracking",
    })
  }, [trackingLive, sendTrackingControl])

  const stopCameraTracking = useCallback(() => {
    sendTrackingControl({ action: "resetLipNeutral" })
    setTrackingEnabled(false)
    resetPreviewToNeutral()
  }, [sendTrackingControl, setTrackingEnabled, resetPreviewToNeutral])

  const startCameraTracking = useCallback(() => {
    if (activeTab !== TRACKING_PREVIEW_TABS.CAMERA) {
      return
    }
    const url = String(wsUrlDraft ?? "").trim() || DEFAULT_WS_CAMERA
    if (connectedUrl !== url) {
      replaceWithWebSocket()
    }
    setTrackingEnabled(true)
  }, [activeTab, wsUrlDraft, connectedUrl, replaceWithWebSocket, setTrackingEnabled])

  useEffect(() => {
    if (activeTab !== TRACKING_PREVIEW_TABS.CAMERA && trackingEnabled) {
      setTrackingEnabled(false)
      resetPreviewToNeutral()
    }
  }, [activeTab, trackingEnabled, setTrackingEnabled, resetPreviewToNeutral])

  useEffect(() => {
    return () => {
      setTrackingEnabled(false)
    }
  }, [setTrackingEnabled])

  return {
    ctrl: {
      wsUrlDraft,
      setWsUrlDraft,
      replaceWithWebSocket,
      clearLastFrame,
      lastFrame,
      status,
    },
    profile,
    calibratedFrame,
    previewRig,
    dryRunResult,
    trackingStatus,
    cameraRunning: trackingLive,
    startCameraTracking,
    stopCameraTracking,
    resetPreviewToNeutral,
    mapping,
    lipGeometry,
    jawGeometry,
    requestLipNeutral,
  }
}
