import { createInitialEliteRig } from "../../core/faceDofMapper.js"
import { TRACKING_FRAME_TYPE, createEmptyRigFrame } from "./trackingTypes.js"

function clampSigned100(n) {
  return Math.max(-100, Math.min(100, Number(n) || 0))
}

function clampPct(n) {
  return Math.max(0, Math.min(100, Number(n) ?? 50))
}

function safeGazeNum(v) {
  const n = Number(v)
  if (!Number.isFinite(n)) {
    return 0
  }
  return n
}

/** @param {unknown} jg */
function normalizeJawGeometryDebug(jg) {
  if (!jg || typeof jg !== "object") {
    return undefined
  }
  const o = /** @type {Record<string, unknown>} */ (jg)
  const ns = o.neutralState && typeof o.neutralState === "object" ? o.neutralState : null
  const curve = o.curve && typeof o.curve === "object" ? o.curve : null
  const poseGate = o.poseGate && typeof o.poseGate === "object" ? o.poseGate : null
  return {
    enabled: Boolean(o.enabled),
    neutralReady: Boolean(o.neutralReady),
    semanticOpen: Number.isFinite(Number(o.semanticOpen)) ? Number(o.semanticOpen) : 0,
    rigWrite:
      Number.isFinite(Number(o.rigWrite))
        ? Number(o.rigWrite)
        : Number.isFinite(Number(o.rigWrite?.jaw))
          ? Number(o.rigWrite.jaw)
          : 0,
    smoothSemantic: Number.isFinite(Number(o.smoothSemantic)) ? Number(o.smoothSemantic) : 0,
    raw: Number.isFinite(Number(o.raw)) ? Number(o.raw) : Number.isFinite(Number(curve?.beforeCurve)) ? Number(curve?.beforeCurve) : 0,
    curved: Number.isFinite(Number(o.curved)) ? Number(o.curved) : Number.isFinite(Number(curve?.afterCurve)) ? Number(curve?.afterCurve) : 0,
    skipped: o.skipped != null ? String(o.skipped) : "",
    neutralState:
      ns && typeof ns === "object"
        ? {
            mode: String(ns.mode || "idle"),
            neutralReady: Boolean(ns.neutralReady),
            neutralCount: Number(ns.neutralCount) || 0,
            neutralWarmupCount: Number(ns.neutralWarmupCount) || 0,
          }
        : undefined,
    components: o.components && typeof o.components === "object" ? o.components : undefined,
    gating: o.gating && typeof o.gating === "object" ? o.gating : undefined,
    curve: curve || undefined,
    pose: o.pose && typeof o.pose === "object" ? o.pose : undefined,
    poseGate: poseGate || undefined,
    stabilizer:
      o.stabilizer && typeof o.stabilizer === "object" ? o.stabilizer : undefined,
    signConvention:
      o.signConvention && typeof o.signConvention === "object" ? o.signConvention : undefined,
  }
}

/** @param {unknown} lg */
function lipAxisNum(lg, group, key) {
  if (!lg || typeof lg !== "object") {
    return null
  }
  const o = /** @type {Record<string, unknown>} */ (lg)
  const g = o[group]
  if (g && typeof g === "object") {
    const v = /** @type {Record<string, unknown>} */ (g)[key]
    if (Number.isFinite(Number(v))) {
      return Number(v)
    }
  }
  return null
}

/** @param {unknown} lg */
function normalizeLipGeometryDebug(lg) {
  if (!lg || typeof lg !== "object") {
    return undefined
  }
  const o = /** @type {Record<string, unknown>} */ (lg)
  const pickSmooth = (k) => {
    const fromGroup = lipAxisNum(o, "deltaSmooth", k)
    if (fromGroup != null) {
      return fromGroup
    }
    const flat = o[k]
    if (Number.isFinite(Number(flat))) {
      return Number(flat)
    }
    return 0
  }
  const pickRaw = (k) => {
    const fromGroup = lipAxisNum(o, "deltaRaw", k)
    if (fromGroup != null) {
      return fromGroup
    }
    const legacy = o[`${k}Raw`] ?? o[`${k === "upperL" ? "upperLRaw" : k}`]
    if (k === "upperR" && o.upperRRaw != null) {
      return safeGazeNum(o.upperRRaw)
    }
    if (k === "lowerR" && o.lowerRRaw != null) {
      return safeGazeNum(o.lowerRRaw)
    }
    if (k === "upperL" && o.upperLRaw != null) {
      return safeGazeNum(o.upperLRaw)
    }
    if (k === "lowerL" && o.lowerLRaw != null) {
      return safeGazeNum(o.lowerLRaw)
    }
    return 0
  }
  const axis4 = (group) => ({
    upperL: lipAxisNum(o, group, "upperL") ?? 0,
    upperR: lipAxisNum(o, group, "upperR") ?? 0,
    lowerL: lipAxisNum(o, group, "lowerL") ?? 0,
    lowerR: lipAxisNum(o, group, "lowerR") ?? 0,
  })
  return {
    enabled: Boolean(o.enabled),
    neutralReady: Boolean(o.neutralReady),
    neutralCount:
      typeof o.neutralCount === "number" && Number.isFinite(o.neutralCount) ? o.neutralCount : 0,
    mouthWidth: safeGazeNum(o.mouthWidth),
    deltaSmooth: {
      upperL: pickSmooth("upperL"),
      upperR: pickSmooth("upperR"),
      lowerL: pickSmooth("lowerL"),
      lowerR: pickSmooth("lowerR"),
    },
    deltaRaw: {
      upperL: pickRaw("upperL"),
      upperR: pickRaw("upperR"),
      lowerL: pickRaw("lowerL"),
      lowerR: pickRaw("lowerR"),
    },
    currentY: axis4("currentY"),
    neutralY: axis4("neutralY"),
    rigWrite: axis4("rigWrite"),
    blendshapeTerm: axis4("blendshapeTerm"),
    skipped: o.skipped != null ? String(o.skipped) : "",
    isolation:
      typeof o.isolation === "number" && Number.isFinite(o.isolation) ? o.isolation : undefined,
    crossTalk:
      o.crossTalk && typeof o.crossTalk === "object"
        ? {
            suppressedUpper: Boolean(o.crossTalk.suppressedUpper),
            suppressedLower: Boolean(o.crossTalk.suppressedLower),
          }
        : undefined,
    sourceBreakdown:
      o.sourceBreakdown && typeof o.sourceBreakdown === "object" ? o.sourceBreakdown : undefined,
    signConvention:
      o.signConvention && typeof o.signConvention === "object"
        ? {
            upperOpenPositive: Boolean(o.signConvention.upperOpenPositive),
            lowerOpenNegative: Boolean(o.signConvention.lowerOpenNegative),
            upperSign: safeGazeNum(o.signConvention.upperSign) || 1,
            lowerSign: safeGazeNum(o.signConvention.lowerSign) || 1,
            yAxisTowardChin: Boolean(o.signConvention.yAxisTowardChin),
          }
        : undefined,
    neutralState:
      o.neutralState && typeof o.neutralState === "object"
        ? {
            mode: String(o.neutralState.mode || "idle"),
            neutralReady: Boolean(o.neutralState.neutralReady),
            neutralCount: Number(o.neutralState.neutralCount) || 0,
            neutralWarmupCount: Number(o.neutralState.neutralWarmupCount) || 0,
            stableCount: Number(o.neutralState.stableCount) || 0,
            autoCalibrateRequested: Boolean(o.neutralState.autoCalibrateRequested),
            forceRecalibrate: Boolean(o.neutralState.forceRecalibrate),
            lastCalibratedAt: safeGazeNum(o.neutralState.lastCalibratedAt),
          }
        : undefined,
    driftCorrection:
      o.driftCorrection && typeof o.driftCorrection === "object"
        ? {
            enabled: Boolean(o.driftCorrection.enabled),
            allowed: Boolean(o.driftCorrection.allowed),
            updated: Boolean(o.driftCorrection.updated),
            reason: String(o.driftCorrection.reason || ""),
            stepUpperL: safeGazeNum(o.driftCorrection.stepUpperL),
            stepUpperR: safeGazeNum(o.driftCorrection.stepUpperR),
            stepLowerL: safeGazeNum(o.driftCorrection.stepLowerL),
            stepLowerR: safeGazeNum(o.driftCorrection.stepLowerR),
          }
        : undefined,
    stabilizer:
      o.stabilizer && typeof o.stabilizer === "object"
        ? {
            lockedToZero: o.stabilizer.lockedToZero || {},
            raw: o.stabilizer.raw || {},
            smooth: o.stabilizer.smooth || {},
            velocity: o.stabilizer.velocity || {},
            alpha: o.stabilizer.alpha || {},
          }
        : undefined,
    upperL: pickSmooth("upperL"),
    upperR: pickSmooth("upperR"),
    lowerL: pickSmooth("lowerL"),
    lowerR: pickSmooth("lowerR"),
    upperLRaw: pickRaw("upperL"),
    upperRRaw: pickRaw("upperR"),
    lowerLRaw: pickRaw("lowerL"),
    lowerRRaw: pickRaw("lowerR"),
  }
}

/**
 * 将任意 JSON 中的 rig 片段归一成与 createInitialEliteRig 一致的结构。
 * @param {unknown} raw
 */
export function normalizeEliteRig(raw) {
  const base = createInitialEliteRig()
  if (!raw || typeof raw !== "object") {
    return base
  }
  const o = raw

  return {
    browL: {
      tip: clampSigned100(o.browL?.tip),
      mid: clampSigned100(o.browL?.mid),
      tail: clampSigned100(o.browL?.tail),
    },
    browR: {
      tip: clampSigned100(o.browR?.tip),
      mid: clampSigned100(o.browR?.mid),
      tail: clampSigned100(o.browR?.tail),
    },
    eyeL: {
      up: clampSigned100(o.eyeL?.up),
      lo: clampSigned100(o.eyeL?.lo),
    },
    eyeR: {
      up: clampSigned100(o.eyeR?.up),
      lo: clampSigned100(o.eyeR?.lo),
    },
    sharedRadar: {
      x: clampPct(o.sharedRadar?.x),
      y: clampPct(o.sharedRadar?.y),
    },
    mouth: {
      UL: clampSigned100(o.mouth?.UL),
      UR: clampSigned100(o.mouth?.UR),
      LL: clampSigned100(o.mouth?.LL),
      LR: clampSigned100(o.mouth?.LR),
      sideL: {
        x: clampPct(o.mouth?.sideL?.x),
        y: clampPct(o.mouth?.sideL?.y),
      },
      sideR: {
        x: clampPct(o.mouth?.sideR?.x),
        y: clampPct(o.mouth?.sideR?.y),
      },
    },
    tongue: { val: clampSigned100(o.tongue?.val) },
    jaw: { val: clampSigned100(o.jaw?.val) },
  }
}

/**
 * 校验并归一 WebSocket / 外部 JSON 为 RigFrame；不合法时返回 null。
 * @param {unknown} data
 * @returns {import("./trackingTypes.js").RigFrame | null}
 */
export function normalizeRigFrameMessage(data) {
  if (!data || typeof data !== "object") {
    return null
  }
  if (data.type !== TRACKING_FRAME_TYPE) {
    return null
  }
  const source = typeof data.source === "string" ? data.source : "unknown"
  const timestampMs = Number.isFinite(Number(data.timestampMs)) ? Number(data.timestampMs) : performance.now()
  const frameSeq = Number.isFinite(Number(data.frameSeq)) ? Number(data.frameSeq) : undefined
  const serverSentAtMs =
    data.serverSentAtMs != null && Number.isFinite(Number(data.serverSentAtMs))
      ? Number(data.serverSentAtMs)
      : undefined
  const faceDetected = data.faceDetected !== false
  const quality =
    typeof data.quality === "number" && Number.isFinite(data.quality)
      ? Math.max(0, Math.min(1, data.quality))
      : 0
  const rig = normalizeEliteRig(data.rig)

  /** @type {import("./trackingTypes.js").RigFrame["debug"] | undefined} */
  let debug
  if (data.debug && typeof data.debug === "object") {
    const b = data.debug.blendshapes
    const m = data.debug.mapping
    const blendshapes =
      b && typeof b === "object"
        ? {
            jawOpen: safeBlendNum(b.jawOpen),
            eyeBlinkLeft: safeBlendNum(b.eyeBlinkLeft),
            eyeBlinkRight: safeBlendNum(b.eyeBlinkRight),
            eyeWideLeft: safeBlendNum(b.eyeWideLeft),
            eyeWideRight: safeBlendNum(b.eyeWideRight),
            mouthSmileLeft: safeBlendNum(b.mouthSmileLeft),
            mouthSmileRight: safeBlendNum(b.mouthSmileRight),
            mouthUpperUpLeft: safeBlendNum(b.mouthUpperUpLeft),
            mouthUpperUpRight: safeBlendNum(b.mouthUpperUpRight),
            mouthLowerDownLeft: safeBlendNum(b.mouthLowerDownLeft),
            mouthLowerDownRight: safeBlendNum(b.mouthLowerDownRight),
            mouthPucker: safeBlendNum(b.mouthPucker),
            mouthFunnel: safeBlendNum(b.mouthFunnel),
            mouthClose: safeBlendNum(b.mouthClose),
            browInnerUp: safeBlendNum(b.browInnerUp),
            browOuterUpLeft: safeBlendNum(b.browOuterUpLeft),
            browOuterUpRight: safeBlendNum(b.browOuterUpRight),
          }
        : undefined
    const mapping =
      m && typeof m === "object"
        ? {
            jaw: safeMapNum(m.jaw),
            blinkLeft: safeMapNum(m.blinkLeft),
            blinkRight: safeMapNum(m.blinkRight),
            smileLeft: safeMapNum(m.smileLeft),
            smileRight: safeMapNum(m.smileRight),
            browLeft: safeMapNum(m.browLeft),
            browRight: safeMapNum(m.browRight),
            eyeOpenBiasLeft: safeMapNum(m.eyeOpenBiasLeft),
            eyeOpenBiasRight: safeMapNum(m.eyeOpenBiasRight),
            eyeLUp: safeMapNum(m.eyeLUp),
            eyeLLo: safeMapNum(m.eyeLLo),
            eyeRUp: safeMapNum(m.eyeRUp),
            eyeRLo: safeMapNum(m.eyeRLo),
            browInner: safeMapNum(m.browInner),
            browOuterLeft: safeMapNum(m.browOuterLeft),
            browOuterRight: safeMapNum(m.browOuterRight),
            browLeftTip: safeMapNum(m.browLeftTip),
            browLeftMid: safeMapNum(m.browLeftMid),
            browLeftTail: safeMapNum(m.browLeftTail),
            browRightTip: safeMapNum(m.browRightTip),
            browRightMid: safeMapNum(m.browRightMid),
            browRightTail: safeMapNum(m.browRightTail),
            upperLipLeft: safeMapNum(m.upperLipLeft),
            upperLipRight: safeMapNum(m.upperLipRight),
            lowerLipLeft: safeMapNum(m.lowerLipLeft),
            lowerLipRight: safeMapNum(m.lowerLipRight),
            lipGeoUpperL: safeMapNum(m.lipGeoUpperL),
            lipGeoUpperR: safeMapNum(m.lipGeoUpperR),
            lipGeoLowerL: safeMapNum(m.lipGeoLowerL),
            lipGeoLowerR: safeMapNum(m.lipGeoLowerR),
            mouthPucker: safeMapNum(m.mouthPucker),
            mouthFunnel: safeMapNum(m.mouthFunnel),
            ...(Number.isFinite(Number(m.eyeLookX)) ? { eyeLookX: Number(m.eyeLookX) } : {}),
            ...(Number.isFinite(Number(m.eyeLookY)) ? { eyeLookY: Number(m.eyeLookY) } : {}),
            ...(Number.isFinite(Number(m.sharedRadarX)) ? { sharedRadarX: Number(m.sharedRadarX) } : {}),
            ...(Number.isFinite(Number(m.sharedRadarY)) ? { sharedRadarY: Number(m.sharedRadarY) } : {}),
          }
        : undefined

    const lipGeometry = normalizeLipGeometryDebug(data.debug.lipGeometry)
    const jawGeometry = normalizeJawGeometryDebug(data.debug.jawGeometry)

    const gz = data.debug.gaze
    const gaze =
      gz && typeof gz === "object"
        ? {
            available: Boolean(gz.available),
            eyeLookX: safeGazeNum(gz.eyeLookX),
            eyeLookY: safeGazeNum(gz.eyeLookY),
            leftEyeX: safeGazeNum(gz.leftEyeX),
            leftEyeY: safeGazeNum(gz.leftEyeY),
            rightEyeX: safeGazeNum(gz.rightEyeX),
            rightEyeY: safeGazeNum(gz.rightEyeY),
          }
        : undefined

    const pr = data.debug && typeof data.debug === "object" ? data.debug.performance : null
    /** @type {Record<string, number | null> | undefined} */
    let performance
    if (pr && typeof pr === "object") {
      const num = (k) => {
        const v = pr[k]
        return typeof v === "number" && Number.isFinite(v) ? v : null
      }
      performance = {
        captureMs: num("captureMs"),
        capReadMs: num("capReadMs"),
        preprocessMs: num("preprocessMs"),
        inferenceMs: num("inferenceMs"),
        mappingMs: num("mappingMs"),
        broadcastMs: num("broadcastMs"),
        loopMs: num("loopMs"),
        jsonEncodeMs: num("jsonEncodeMs"),
        encodeMs: num("encodeMs"),
        sleepMs: num("sleepMs"),
        totalPeriodMs: num("totalPeriodMs"),
        targetIntervalMs: num("targetIntervalMs"),
        fps: num("fps"),
        broadcastFps: num("broadcastFps"),
        broadcastFrameSeq: num("broadcastFrameSeq"),
        captureFps: num("captureFps"),
        inferenceFps: num("inferenceFps"),
        mappingFps: num("mappingFps"),
        generatedFrameFps: num("generatedFrameFps"),
        jsonEncodeFps: num("jsonEncodeFps"),
        broadcastAttemptFps: num("broadcastAttemptFps"),
        broadcastSuccessFps: num("broadcastSuccessFps"),
        perClientSendFps: num("perClientSendFps"),
        clientCount: num("clientCount"),
        frameSeq: num("frameSeq"),
        broadcastSeq: num("broadcastSeq"),
      }
    }

    if (blendshapes || mapping || gaze || lipGeometry || jawGeometry || performance) {
      debug = {}
      if (blendshapes) {
        debug.blendshapes = blendshapes
      }
      if (mapping) {
        debug.mapping = mapping
      }
      if (gaze) {
        debug.gaze = gaze
      }
      if (lipGeometry) {
        debug.lipGeometry = lipGeometry
      }
      if (jawGeometry) {
        debug.jawGeometry = jawGeometry
      }
      if (performance) {
        debug.performance = performance
      }
    }
  }

  /** @type {import("./trackingTypes.js").RigFrame} */
  const out = {
    type: TRACKING_FRAME_TYPE,
    source,
    timestampMs,
    faceDetected,
    quality,
    rig,
    ...(debug ? { debug } : {}),
  }
  if (frameSeq !== undefined) {
    out.frameSeq = frameSeq
  }
  if (serverSentAtMs !== undefined) {
    out.serverSentAtMs = serverSentAtMs
  }
  return out
}

function safeBlendNum(v) {
  const n = Number(v)
  if (!Number.isFinite(n)) {
    return 0
  }
  return Math.max(0, Math.min(1, n))
}

function safeMapNum(v) {
  const n = Number(v)
  if (!Number.isFinite(n)) {
    return 0
  }
  return n
}

/** 容错：若无 type 但含 rig，则补上 type（便于测试网关）。 */
export function coerceToRigFrame(data) {
  const direct = normalizeRigFrameMessage(data)
  if (direct) {
    return direct
  }
  if (data && typeof data === "object" && data.rig && typeof data.rig === "object") {
    return normalizeRigFrameMessage({
      ...createEmptyRigFrame(),
      ...data,
      type: TRACKING_FRAME_TYPE,
      rig: data.rig,
    })
  }
  return null
}
