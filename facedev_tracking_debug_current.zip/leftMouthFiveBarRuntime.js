import { getDefaultRightMouthRuntimeParams } from "./rightMouthFiveBarRuntime.js"
import { getMouthCornerLabSide } from "./mouthCornerFiveBarLabConfig.js"
import { loadMouthLabCalibration } from "./mouthCornerFiveBarLab.js"

export const LEFT_MOUTH_RUNTIME_BASELINE_KEY = "facedev.leftMouthFivebar.runtimeBaseline.v1"
export const LEFT_MOUTH_BASELINE_CHANGED_EVENT = "facedev:leftMouthFivebarBaselineChanged"

function notifyBaselineChanged() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent(LEFT_MOUTH_BASELINE_CHANGED_EVENT))
  }
}

/** 正式链路 / Lab 共用：左嘴角 FiveBar runtime。 */
export function getLeftMouthFiveBarRuntime() {
  const side = getMouthCornerLabSide("left")
  const defaults = getDefaultRightMouthRuntimeParams()
  const baseline = loadLeftMouthRuntimeBaseline()

  if (!baseline) {
    const d = side.defaultCalibration
    return {
      enabled: true,
      source: /** @type {const} */ ("default"),
      loaded: false,
      calibration: null,
      params: {
        ...defaults,
        ...d,
        qSignA: d.qSignA,
        qSignB: d.qSignB,
        qGainA: d.qGainA,
        qGainB: d.qGainB,
      },
      runtime: {
        outputMode: "static-target",
        servoTimeMs: 40,
        sendIntervalMs: 40,
      },
      bindingOverride: null,
      version: null,
      savedAt: null,
      servoAId: null,
      servoBId: null,
    }
  }

  const cal = loadMouthLabCalibration("left", baseline.calibration ?? baseline.runtime ?? {})
  const rtSlice = baseline.runtime && typeof baseline.runtime === "object" ? baseline.runtime : {}

  const params = {
    ...defaults,
    Kx: cal.Kx ?? rtSlice.Kx ?? defaults.Kx,
    Ky: cal.Ky ?? rtSlice.Ky ?? defaults.Ky,
    xSign: cal.xSign ?? rtSlice.xSign ?? -1,
    ySign: cal.ySign ?? rtSlice.ySign ?? 1,
    qSignA: cal.qSignA ?? rtSlice.qSignA ?? 1,
    qSignB: cal.qSignB ?? rtSlice.qSignB ?? 1,
    qGainA: cal.qGainA ?? rtSlice.qGainA ?? 4,
    qGainB: cal.qGainB ?? rtSlice.qGainB ?? 4,
    servoSwap: cal.servoSwap ?? rtSlice.servoSwap ?? false,
    padXCenter: defaults.padXCenter,
    padYCenter: defaults.padYCenter,
    maxStepDeg: rtSlice.maxStepDeg ?? 1.0,
    filterAlpha: rtSlice.filterAlpha ?? 0.25,
  }

  return {
    enabled: rtSlice.enabled !== false,
    source: /** @type {const} */ ("runtimeBaseline"),
    loaded: true,
    calibration: cal,
    params,
    runtime: {
      outputMode: rtSlice.runtimeOutputMode || "static-target",
      servoTimeMs: cal.servoTimeMs ?? 40,
      sendIntervalMs: cal.livePadDriveIntervalMs ?? 40,
    },
    bindingOverride: {
      profileBindings: baseline.profileBindings || {},
      servoAId: baseline.servoAId ?? null,
      servoBId: baseline.servoBId ?? null,
    },
    version: baseline.version || LEFT_MOUTH_RUNTIME_BASELINE_KEY,
    savedAt: baseline.savedAt || null,
    servoAId: baseline.servoAId ?? null,
    servoBId: baseline.servoBId ?? null,
  }
}

export function loadLeftMouthRuntimeBaseline() {
  try {
    const raw = localStorage.getItem(LEFT_MOUTH_RUNTIME_BASELINE_KEY)
    if (!raw) {
      return null
    }
    const data = JSON.parse(raw)
    return data && typeof data === "object" ? data : null
  } catch {
    return null
  }
}

export function saveLeftMouthRuntimeBaseline(snapshot) {
  const payload = {
    ...snapshot,
    version: LEFT_MOUTH_RUNTIME_BASELINE_KEY,
    savedAt: snapshot?.savedAt || new Date().toISOString(),
  }
  localStorage.setItem(LEFT_MOUTH_RUNTIME_BASELINE_KEY, JSON.stringify(payload))
  notifyBaselineChanged()
  return payload
}

export function reloadLeftMouthRuntimeBaseline() {
  const data = loadLeftMouthRuntimeBaseline()
  notifyBaselineChanged()
  return data
}

export function hasLeftMouthRuntimeBaseline() {
  return Boolean(loadLeftMouthRuntimeBaseline())
}
