import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { buildServoMovesFromLogicalPose } from "../../../core/faceDofMapper.js"
import { buildMultiServoMoveCommand } from "../../../core/servoProtocol.js"
import { webSerial } from "../../../core/webSerial.js"
import { buildTrackingDryRunResult } from "../../trackingPreview/buildTrackingDryRunResult.js"
import { createRightMouthCornerFivebarState } from "../../kinematics/mouthCornerFivebar.js"
import { buildMapFaceRigToPoseOptionsFromMouthRuntimes } from "../../kinematics/mouthFiveBarRuntimeOptions.js"
import { evaluateDeviceDriveGates } from "../../trackingPreview/evaluateDeviceDriveGates.js"
import { mapTrackingPreviewPose } from "../../trackingPreview/mapTrackingPreviewPose.js"
import {
  DRIVE_MODES,
  DEVICE_DRIVE_DEFAULTS,
} from "../../trackingPreview/trackingPreviewConstants.js"

const FPS_WINDOW_MS = 500
const UI_DIAGNOSTICS_MS = 250

/**
 * @param {number} servoId
 * @param {import("../../core/faceRigProfile.js").FaceRigProfile | object | null | undefined} profile
 */
function bindingRoleForServo(servoId, profile) {
  const bindings = profile?.bindings
  if (!Array.isArray(bindings)) {
    return "other"
  }
  const sid = Number(servoId)
  const b = bindings.find((x) => x.enabled !== false && Number(x.servoId) === sid)
  if (!b) {
    return "other"
  }
  if (b.controlId === "jaw") {
    return "jaw"
  }
  if (b.controlId === "mouth" && ["UL", "UR", "LL", "LR"].includes(String(b.channel || ""))) {
    return "lip"
  }
  return "other"
}

/**
 * 按绑定角色保留上一帧 PWM，抑制 lip/jaw 微小抖动；嘴角 FiveBar 走 other 通道。
 * @param {ReturnType<typeof import("../../core/faceDofMapper.js").buildServoMovesFromLogicalPose>} moves
 */
function applyServoPwmDeadbandByRole(moves, lastPwmMap, profile, defs) {
  return moves.map((m) => {
    const prev = lastPwmMap.get(m.servoId)
    const role = bindingRoleForServo(m.servoId, profile)
    let thr = defs.minPwmDeltaUs
    if (role === "jaw") {
      thr = defs.jawMinPwmDeltaUs
    } else if (role === "lip") {
      thr = defs.lipMinPwmDeltaUs
    }
    if (prev !== undefined && thr > 0 && Math.abs(m.pwm - prev) < thr) {
      return { ...m, pwm: prev }
    }
    return m
  })
}

/**
 * Phase 4.1-F：Camera Tracking → mapFaceRigToPose → WebSerial（全通道）。
 * 热路径仅轻量 mapFaceRigToPose；诊断/UI 预览降频，避免 interval 被 React 重建。
 */
export function useTrackingPreviewDeviceDrive({
  driveMode,
  deviceDriveArmed,
  previewRig,
  profile,
  configs = [],
  trackingStatus,
  cameraRunning,
  onCommandSent,
  onSerialError,
}) {
  const rightFiveBarRef = useRef(createRightMouthCornerFivebarState())
  const leftFiveBarRef = useRef(createRightMouthCornerFivebarState())
  const mapOptsRef = useRef(
    buildMapFaceRigToPoseOptionsFromMouthRuntimes({
      rightState: rightFiveBarRef.current,
      leftState: leftFiveBarRef.current,
    })
  )

  const logicalPoseRef = useRef(/** @type {Record<string, number>} */ ({}))
  const previewRigRef = useRef(previewRig)
  const profileRef = useRef(profile)
  const configsRef = useRef(configs)
  const trackingStatusRef = useRef(trackingStatus)
  const cameraRunningRef = useRef(cameraRunning)
  const deviceDriveArmedRef = useRef(deviceDriveArmed)
  const driveModeRef = useRef(driveMode)

  const serialBusyRef = useRef(false)
  const flushPendingRef = useRef(false)
  const stopInProgressRef = useRef(false)
  const stopTokenRef = useRef(0)
  const lastSentPwmRef = useRef(new Map())
  const lastCommandRef = useRef("")
  const lastSentAtRef = useRef(0)
  const sendCountRef = useRef(0)
  const onCommandSentRef = useRef(onCommandSent)
  const onSerialErrorRef = useRef(onSerialError)

  const [sendFps, setSendFps] = useState(/** @type {number | null} */ (null))
  const [lastSkipReason, setLastSkipReason] = useState("")
  const [uiDryRunResult, setUiDryRunResult] = useState(
    /** @type {ReturnType<typeof buildTrackingDryRunResult> | null} */ (null)
  )

  previewRigRef.current = previewRig
  profileRef.current = profile
  configsRef.current = configs
  trackingStatusRef.current = trackingStatus
  cameraRunningRef.current = cameraRunning
  deviceDriveArmedRef.current = deviceDriveArmed
  driveModeRef.current = driveMode
  onCommandSentRef.current = onCommandSent
  onSerialErrorRef.current = onSerialError

  const deviceDriveMode = driveMode === DRIVE_MODES.DEVICE_DRIVE
  const serialConnected = Boolean(webSerial.getStatus()?.connected)

  // 随 tracking 帧更新姿态（轻量）；不触发 pushToDevice / interval 重建
  useEffect(() => {
    if (!deviceDriveMode) {
      return
    }
    const mapped = mapTrackingPreviewPose({
      profile: profileRef.current,
      rig: previewRigRef.current,
      configs: configsRef.current,
      mapFaceRigToPoseOptions: mapOptsRef.current,
    })
    logicalPoseRef.current = mapped.logicalPose || {}
  }, [deviceDriveMode, previewRig])

  // Mapping 面板用 Dry Run 诊断（降频，避免卡主线程）
  useEffect(() => {
    if (!deviceDriveMode) {
      setUiDryRunResult(null)
      return undefined
    }
    const tick = () => {
      setUiDryRunResult(
        buildTrackingDryRunResult({
          profile: profileRef.current,
          rig: previewRigRef.current,
          configs: configsRef.current,
        })
      )
    }
    tick()
    const id = window.setInterval(tick, UI_DIAGNOSTICS_MS)
    return () => window.clearInterval(id)
  }, [deviceDriveMode, previewRig, profile, configs])

  const gates = useMemo(
    () =>
      evaluateDeviceDriveGates({
        armed: deviceDriveArmed,
        cameraRunning,
        serialConnected,
        faceDetected: Boolean(trackingStatus?.faceDetected),
        quality: Number(trackingStatus?.quality) || 0,
      }),
    [deviceDriveArmed, cameraRunning, serialConnected, trackingStatus]
  )

  const pushToDeviceRef = useRef(
    /** @type {null | (() => Promise<void>)} */ (null)
  )

  const pushToDevice = useCallback(async () => {
    if (stopInProgressRef.current) {
      return
    }
    const tokenAtStart = stopTokenRef.current
    const finish = () => {
      serialBusyRef.current = false
      if (flushPendingRef.current) {
        flushPendingRef.current = false
        queueMicrotask(() => {
          void pushToDeviceRef.current?.()
        })
      }
    }

    if (driveModeRef.current !== DRIVE_MODES.DEVICE_DRIVE || !deviceDriveArmedRef.current) {
      return
    }

    const gate = evaluateDeviceDriveGates({
      armed: deviceDriveArmedRef.current,
      cameraRunning: cameraRunningRef.current,
      serialConnected: Boolean(webSerial.getStatus()?.connected),
      faceDetected: Boolean(trackingStatusRef.current?.faceDetected),
      quality: Number(trackingStatusRef.current?.quality) || 0,
    })

    if (!gate.canSend) {
      setLastSkipReason(gate.note)
      return
    }

    if (serialBusyRef.current) {
      if (DEVICE_DRIVE_DEFAULTS.dropStaleFrame) {
        flushPendingRef.current = true
      }
      return
    }

    serialBusyRef.current = true
    setLastSkipReason("")

    try {
      const logicalPose = logicalPoseRef.current
      if (!logicalPose || typeof logicalPose !== "object") {
        setLastSkipReason("无可映射姿态")
        finish()
        return
      }

      const timeMs = DEVICE_DRIVE_DEFAULTS.servoTimeMs
      const rawMoves = buildServoMovesFromLogicalPose(logicalPose, configsRef.current, timeMs)
      if (!rawMoves.length) {
        setLastSkipReason("无可下发舵机")
        finish()
        return
      }

      const moves = applyServoPwmDeadbandByRole(
        rawMoves,
        lastSentPwmRef.current,
        profileRef.current,
        DEVICE_DRIVE_DEFAULTS
      )
      const roles = new Set(rawMoves.map((m) => bindingRoleForServo(m.servoId, profileRef.current)))

      const command = buildMultiServoMoveCommand(moves)
      const now = Date.now()
      const defs = DEVICE_DRIVE_DEFAULTS
      const hasJaw = roles.has("jaw")
      const hasLip = roles.has("lip")
      let cooldown = defs.sameCommandCooldownMs || 0
      if (hasJaw) {
        cooldown = Math.max(cooldown, defs.jawSameCommandCooldownMs || 0)
      } else if (hasLip) {
        cooldown = Math.max(cooldown, defs.lipSameCommandCooldownMs || 0)
      }
      if (
        cooldown > 0 &&
        command &&
        command === lastCommandRef.current &&
        now - lastSentAtRef.current < cooldown
      ) {
        setLastSkipReason("lip-send-fps-limit")
        finish()
        return
      }

      if (!webSerial.getStatus().connected) {
        setLastSkipReason("串口未连接")
        finish()
        return
      }

      const writeResult = await webSerial.tryWriteText(command, { force: false })
      if (tokenAtStart !== stopTokenRef.current || stopInProgressRef.current) {
        return
      }
      if (!writeResult.ok) {
        if (writeResult.dropped) {
          flushPendingRef.current = true
        } else {
          setLastSkipReason(writeResult.reason || writeResult.error || "写入失败")
        }
        finish()
        return
      }

      lastCommandRef.current = command
      lastSentAtRef.current = now
      for (const m of moves) {
        lastSentPwmRef.current.set(m.servoId, m.pwm)
      }
      sendCountRef.current += 1
      onCommandSentRef.current?.(command)
    } catch (e) {
      const msg = e?.message || String(e)
      setLastSkipReason(msg)
      onSerialErrorRef.current?.(msg)
    } finally {
      finish()
    }
  }, [])

  pushToDeviceRef.current = pushToDevice

  useEffect(() => {
    if (!deviceDriveArmed) {
      stopInProgressRef.current = false
      rightFiveBarRef.current = createRightMouthCornerFivebarState()
      leftFiveBarRef.current = createRightMouthCornerFivebarState()
      lastSentPwmRef.current.clear()
      lastCommandRef.current = ""
    }
  }, [deviceDriveArmed])

  useEffect(() => {
    if (!deviceDriveMode || !deviceDriveArmed) {
      setSendFps(null)
      setLastSkipReason("")
      return undefined
    }

    const targetFps = Math.max(
      1,
      Math.min(
        DEVICE_DRIVE_DEFAULTS.maxSendFps,
        DEVICE_DRIVE_DEFAULTS.jawMaxSendFps || DEVICE_DRIVE_DEFAULTS.maxSendFps
      )
    )
    const intervalMs = Math.max(15, Math.round(1000 / targetFps))
    const timer = window.setInterval(() => {
      void pushToDeviceRef.current?.()
    }, intervalMs)

    return () => window.clearInterval(timer)
  }, [deviceDriveMode, deviceDriveArmed])

  useEffect(() => {
    if (!deviceDriveMode || !deviceDriveArmed) {
      return undefined
    }
    const id = window.setInterval(() => {
      const n = sendCountRef.current
      sendCountRef.current = 0
      setSendFps(Math.round((n / FPS_WINDOW_MS) * 1000))
    }, FPS_WINDOW_MS)
    return () => window.clearInterval(id)
  }, [deviceDriveMode, deviceDriveArmed])

  const bindingDiagnostics = uiDryRunResult?.diagnostics ?? null
  const commandPreview = uiDryRunResult?.commandPreview ?? ""

  const beginStopSequence = useCallback(() => {
    stopInProgressRef.current = true
    stopTokenRef.current += 1
    flushPendingRef.current = false
    logicalPoseRef.current = {}
  }, [])

  const endStopSequence = useCallback(() => {
    stopInProgressRef.current = false
  }, [])

  return {
    bindingDiagnostics,
    commandPreview,
    gates,
    sendFps,
    lastSkipReason,
    armed: deviceDriveArmed,
    uiDryRunResult,
    beginStopSequence,
    endStopSequence,
  }
}
